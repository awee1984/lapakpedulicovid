<?php echo $__env->make('web.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


	<div class="product-area most-popular section" style="padding-bottom:30px;">
    <div class="container" style="margin-top:50px;margin-bottom:30px;">
      <div class="row">
				<div class="col-12">
					<div class="section-title">
						<h2>PRODUK UNTUKMU</h2>
					</div>
				</div>
			</div>
			<?php if($statuscari == 0): ?>
			<div class="row">
        <div class="col-12">
					<div class="alert alert-warning text-center" role="alert">
						Maaf, produk yang kamu cari tidak ada
					</div>
				</div>
			</div>
			<?php endif; ?>
      <div class="row" style="padding-top:20px;">
        <div class="col-12">
          <div class="owl-carousel popular-slider">
						<?php $__currentLoopData = $produk1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produk1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="single-product">
							<div class="product-img">
								<a href="<?php echo e(url('/lihat_produk')); ?>/<?php echo e($produk1->id); ?>">
									<img class="default-img" src="<?php echo e(url('/')); ?>/assets/produk/<?php echo e($produk1->gambar_produk); ?>" alt="#" style="height:300px;width:255px">
									<img class="hover-img" src="<?php echo e(url('/')); ?>/assets/produk/<?php echo e($produk1->gambar_produk); ?>" alt="#" style="height:300px;width:255px"">
									
								</a>
								<div class="button-head">
									<div class="product-action-2">
										<a title="Masukkan ke dalam keranjang" href="<?php echo e(url('/lihat_produk')); ?>/<?php echo e($produk1->id); ?>">Add to Cart</a>
									</div>
								</div>
							</div>
							<div class="product-content">
								<p><?php echo e($produk1->nama_produk); ?></p>
								<div class="product-price">
									<span>Rp. <?php echo e(number_format($produk1->harga_jual)); ?>,-</span>
								</div>
							</div>
            </div>		
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
					</div>
				</div>
      </div>
    </div>
	</div>
	
  <section class="product-area shop-sidebar shop section" style="padding-top:5px;padding-bottom:30px;">
    <div class="container">
      <div class="row">
        <div class="col-lg-12  col-12">
          <div class="shop-sidebar">
            <div class="single-widget category">
              <h3 class="title text-center">Kategori</h3>
              <div class="nav-main">
								<form action="<?php echo e(route('landingpage_user')); ?>">
									<div class="row">
										<div class="col-12 text-center">
											<button  type="submit" class="btn btn-default btn-sm btn-kat" name="all_kategori" >Semua Kategori</button>
										</div>
										
									</div>
									
									<ul class="nav nav-tabs" id="myTab" role="tablist">
										<?php $__currentLoopData = $kategori2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<li class="nav-item" style="margin-top:5px">
											<button type="submit" class="btn btn-default btn-sm btn-kat" name="list_kategori" value="<?php echo e($kategori2->id); ?>"><?php echo e($kategori2->nama_kategori); ?></button>
										</li>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</ul>
								</form>
							</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
	
	<section class="shop-home-list section">
		<div class="container">
			<div class="row">
				
				<?php if($statuscari == 0): ?>
				<div class="col-12">
					<div class="alert alert-warning text-center" role="alert">
						Maaf, produk yang kamu cari tidak ada
					</div>
				</div>
				<?php endif; ?>

				<?php if($statuscari2 == 0): ?>
				<div class="col-12">
					<div class="alert alert-warning text-center" role="alert">
						Maaf, produk yang kamu cari tidak ada
					</div>
				</div>
				<?php endif; ?>
				
				<?php $__currentLoopData = $produk2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produk2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="col-6 col-md-2">
					<div class="single-list">
						<div class="row">
							<div class="col-12 col-md-12">
								<div class="list-image overlay">
									<img src="<?php echo e(url('/')); ?>/assets/produk/<?php echo e($produk2->gambar_produk); ?>" alt="#" style="max-height:180px;min-height:180px;">
									<a href="<?php echo e(url('/lihat_produk')); ?>/<?php echo e($produk2->id); ?>" class="buy"><i class="fa fa-shopping-cart"></i></a>
                  <div class="content" style="padding-top:5px;padding-left:0px;padding-right:0px;">
                    <p class="title" style="font-size:10pt"><strong><?php echo e($produk2->nama_produk); ?></strong></p>
                    <p ><?php echo e($produk2->lapak->nama_lapak); ?></p>
                    <p class="price with-discount text-center" style="padding-top:5px;display:block;">Rp. <?php echo e(number_format($produk2->harga_jual)); ?>,-</p>
                  </div>
								</div>		
							</div>
						</div>
					</div>
        </div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		</div>
	</section>
	

	

  <!-- End Shop Home List  -->
	
<?php echo $__env->make('web.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lapak_peduli\lapak_peduli\resources\views/web/landingpage_user.blade.php ENDPATH**/ ?>