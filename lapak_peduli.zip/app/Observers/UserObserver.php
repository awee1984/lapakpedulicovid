<?php
namespace App\Observers;

use App\Notifications\NewUser;
use App\User;
use App\Superadmin;

class UserObserver
{
    public function created(User $user)
    {
        $author = $user->user;
        $superadmin = Superadmin::all();
        foreach ($superadmin as $user) {
            $user->notify(new NewUser($user,$author));
        }
    }
}