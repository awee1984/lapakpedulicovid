<?php echo $__env->make('dashboard.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div id="content-wrapper">
  <div class="container-fluid">
    <ol class="breadcrumb bg-dark" style="box-shadow:0px 0px 8px #0000001a;">
      <li class="breadcrumb-item">
        <a class="text-light" href="#">Profil Lapak</a>
      </li>
      
    </ol>
    <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#updateprofilModal">
      Update Profil
    </button>
    
    <br><br>
    <div class="row">
      <div class="col-lg-12">
        <?php if(session('status')): ?>
          <div class="alert alert-success">
              <?php echo e(session('status')); ?>

          </div>
        <?php endif; ?>
      </div>
    </div>
    <!-- Profil -->
    <div class="row">
      <div class="col-12">
        <div class="card">
          <div class="row">
            <div class="col-6">
              <div class="card-body">
                <table width="100%">
                  <thead>
                    <tr>
                      <th width="30%">Nama Lapak </th>
                      <th width="2%">: </th>
                      <th width="68%"><?php echo e($datalapak->nama_lapak); ?></th>
                    </tr>
                    <tr>
                      <th width="30%">Kode Lapak </th>
                      <th width="2%">: </th>
                      <th width="68%"><?php echo e($datalapak->kode_lapak); ?></th>
                    </tr>
                    <tr>
                      <th width="30%">Nama Owner </th>
                      <th width="2%">: </th>
                      <th width="68%"><?php echo e($datalapak->nama_owner); ?></th>
                    </tr>
                    <tr>
                      <th width="30%">No Handphone </th>
                      <th width="2%">: </th>
                      <th width="68%"><?php echo e($datalapak->no_kontak); ?></th>
                    </tr>
                    <tr>
                      <th width="30%">Alamat </th>
                      <th width="2%">: </th>
                      <th width="68%"><?php echo e($datalapak->alamat); ?></th>
                    </tr>
                    <tr>
                      <th width="30%">Waktu Buka-Tutup  </th>
                      <th width="2%">: </th>
                      <th width="68%">
                        <?php if($datalapak->waktu_buka): ?>
                        <?php echo e($datalapak->waktu_buka); ?>

                        <?php else: ?> 
                        <span class="text-danger"> Belum diset </span> 
                        <?php endif; ?> 
                        - 
                        <?php if($datalapak->waktu_tutup ): ?>
                        <?php echo e($datalapak->waktu_tutup); ?>

                        <?php else: ?> 
                        <span class="text-danger"> Belum diset </span> 
                        <?php endif; ?> 
                      </th>
                    </tr>
                    <tr>
                      <th width="30%">No Rekening </th>
                      <th width="2%">: </th>
                      <?php if($datalapak->bank_id == 0): ?>
                      <th width="68%"><span class="text-danger"> Belum diset </span> | <span class="text-danger"> Belum diset </span> </th>
                      <?php else: ?> 
                      <th width="68%"><?php echo e($datalapak->bank->nama_bank); ?> | <?php echo e($datalapak->no_rekening); ?> </th>
                      <?php endif; ?>
                    </tr>
                  </thead>
                </table>
              </div>
            </div>
              <div class="card-body">
                <div class="col-6">
                  Gambar Backdrop/Logo
                  <?php if($datalapak->backdrop): ?>
                  <img width="200"  src="<?php echo e(url('/')); ?>/assets/lapak/<?php echo e($datalapak->backdrop); ?>" class="img-responsive">
                  <?php else: ?> 
                  <img width="200"  src="<?php echo e(url('/')); ?>/assets/lapak/lapak_default.jpg" class="img-responsive">
                  <?php endif; ?>
                </div>
              </div>
          </div>
        </div>
      </div>
    </div>

    
    

    <!-- edit produk Modal -->
    <div class="modal fade " id="updateprofilModal" tabindex="-1" role="dialog" aria-labelledby="#updateprofilModalTitle" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="updateprofilModalTitle">Update Profil</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <form action="<?php echo e(url('/profil_lapak')); ?>/<?php echo e($lapak_id); ?>" method="post" enctype="multipart/form-data">
            <?php echo method_field('patch'); ?>
            <?php echo csrf_field(); ?>
            <div class="modal-body">
              <div class="row">
                <div class="col-12">
                  <div class="row">
                    <div class="col-6">
                      <div class="row">
                        <div class="col-12">
                          <div class="form-group">
                            <label for="nama_lapak">Nama Lapak</label>
                            <input type="text" name="nama_lapak" id="nama_lapak" class="form-control" placeholder="Nama Lapak" value="<?php echo e($datalapak->nama_lapak); ?>">
                            <?php if ($errors->has('nama_lapak')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nama_lapak'); ?>
                            <span class="help-block text-danger">Wajib diisi</span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                          </div>
                          <div class="form-group">
                            <label for="nama_owner">Nama Owner</label>
                            <input type="text" name="nama_owner" id="nama_owner" class="form-control" placeholder="Nama Owner" value="<?php echo e($datalapak->nama_owner); ?>">
                            <?php if ($errors->has('nama_owner')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nama_owner'); ?>
                            <span class="help-block text-danger">Wajib diisi</span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                          </div>
                          <div class="form-group">
                            <label for="no_kontak">No Handphone/Whatsapp</label>
                            <input type="text" name="no_kontak" id="no_kontak" class="form-control" placeholder="No Handphone/Whatsapp" value="<?php echo e($datalapak->no_kontak); ?>">
                            <?php if ($errors->has('no_kontak')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('no_kontak'); ?>
                            <span class="help-block text-danger">Wajib diisi</span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                          </div>
                          <div class="form-group">
                            <label for="alamat">Alamat</label>
                            <input type="text" name="alamat" id="alamat" class="form-control" placeholder="Alamat" value="<?php echo e($datalapak->alamat); ?>">
                            <?php if ($errors->has('alamat')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('alamat'); ?>
                            <span class="help-block text-danger">Wajib diisi</span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                          </div>
                        </div>
                      </div>
                      <div class="row">
                        <div class="col-4">
                          <div class="form-group">
                            <label for="waktu_buka">Buka</label>
                            <input type="text" name="waktu_buka" id="waktu_buka" class="form-control" placeholder="mis: 08.00" value="<?php echo e($datalapak->waktu_buka); ?>">
                          </div>
                        </div>
                        <div class="col-4">
                          <div class="form-group">
                            <label for="waktu_tutup">Tutup</label>
                            <input type="text" name="waktu_tutup" id="waktu_tutup" class="form-control" placeholder="mis: 22.00" value="<?php echo e($datalapak->waktu_tutup); ?>">
                          </div>
                        </div>
                      </div>
                      <div class="row">
                        <div class="col-6">
                          <div class="form-group">
                            <label for="bank">Bank</label>
                            <select name="bank" id="bank" class="form-control">
                              <option value="">-- Pilih Bank --</option>
                              <?php $__currentLoopData = $bank; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($datalapak->bank_id == $bank->id): ?>
                                <option value="<?php echo e($bank->id); ?>" selected><?php echo e($bank->nama_bank); ?></option>
                                <?php else: ?>     
                                <option value="<?php echo e($bank->id); ?>"><?php echo e($bank->nama_bank); ?></option>
                                <?php endif; ?>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                          </div>
                        </div>
                        <div class="col-6">
                          <div class="form-group">
                            <label for="no_rekening">No Rekening</label>
                            <input type="text" name="no_rekening" id="no_rekening" class="form-control" placeholder="Nomor Rekening" value="<?php echo e($datalapak->no_rekening); ?>">
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="col-6">
                      <div class="form-group">
                        <label>Gambar Backdrop</label>
                        
                        <input type="file" name="gambar" id="file_backdrop" />
                        <br><br>
                        <img width="300" id="previewing"  src="" class="img-responsive">
                        <div id="message_backdrop"></div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="modal-footer">
              <button type="submit" class="btn btn-success btn-sm">Simpan</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>

  

  <!-- Sticky Footer -->
  <footer class="sticky-footer">
    <div class="container my-auto">
      <div class="copyright text-center my-auto">
        <span>Copyright © Lapak_Peduli_Covid19 2020</span>
      </div>
    </div>
  </footer>
</div>
<?php echo $__env->make('dashboard.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lapak_peduli\lapak_peduli\resources\views/dashboard/profil_lapak.blade.php ENDPATH**/ ?>