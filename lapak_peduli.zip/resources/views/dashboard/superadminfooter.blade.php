<!-- Bootstrap core JavaScript-->
    </div>
  </div>
</div> 
    
<script src="{{url('/')}}/dashboard/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

<!-- Core plugin JavaScript-->
<script src="{{url('/')}}/dashboard/vendor/jquery-easing/jquery.easing.min.js"></script>

<!-- Page level plugin JavaScript-->
{{-- <script src="{{url('/')}}/dashboard/vendor/chart.js/Chart.min.js"></script> --}}
<script src="{{url('/')}}/dashboard/vendor/datatables/jquery.dataTables.js"></script>
<script src="{{url('/')}}/dashboard/vendor/datatables/dataTables.bootstrap4.js"></script>

<!-- Custom scripts for all pages-->
<script src="{{url('/')}}/dashboard/js/sb-admin.min.js"></script>


<!-- Demo scripts for this page-->
<script src="{{url('/')}}/dashboard/js/demo/datatables-demo.js"></script>
{{-- <script src="{{url('/')}}/dashboard/js/demo/chart-area-demo.js"></script> --}}
<script src="{{url('/')}}/assets/myscript.js"></script>

</body>

</html>