@include('web.header')

<body class="js">
	
	<!-- Preloader -->
	<div class="preloader">
		<div class="preloader-inner">
			<div class="preloader-icon">
				<span></span>
				<span></span>
			</div>
		</div>
	</div>
  <!-- End Preloader -->
  <div class="contact-us section">
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-lg-12 col-12">
          <div class="form-main" style="background-color:white;margin-top:50px;">
            <div class="title">
              <h5>Cart</h5>
            </div>
            <div class="row">
              <div class="col-lg-12">
                @if (session('status'))
                  <div class="alert alert-success">
                      {{ session('status') }}
                  </div>
                @endif
              </div>
            </div>
            <div class="row">
              <div class="col-lg-12">
                @if (session('hapus'))
                  <div class="alert alert-danger">
                      {{ session('hapus') }}
                  </div>
                @endif
              </div>
            </div>
            <div class="table-responsive">
              <table class="table">
                <thead style="background-color:#ef0000;color:#fff">
                  <th style="height:60px;padding-left:10px;padding-right:10px;">Kode Produk</th>
                  <th style="height:60px;padding-left:10px;padding-right:10px;">Image</th>
                  <th style="height:60px;padding-left:10px;padding-right:10px;">Nama Produk</th>
                  <th style="height:60px;padding-left:10px;padding-right:10px;">Harga</th>
                  <th style="height:60px;padding-left:10px;padding-right:10px;">Kuantitas</th>
                  <th style="height:60px;padding-left:10px;padding-right:10px;">Total</th>
                  <th style="height:60px;padding-left:10px;padding-right:10px;">Motode Bayar</th>
                  <th style="height:60px;padding-left:10px;padding-right:10px;"><i class="fa fa-edit"></i></th>
                  <th style="height:60px;padding-left:10px;padding-right:10px;"><i class="ti-trash remove-icon"></th>
                </thead>
                <tbody >
                  @foreach ($isicart as $isicart)
                  <tr >
                    <td style="padding-top:20px;padding-left:10px">{{$isicart->produk->kode_produk}}</td>
                    <td style="padding-top:20px;padding-left:10px"><img src="{{url('/')}}/assets/produk/{{$isicart->produk->gambar_produk}}" alt="" width="100px"></td>
                    <td style="padding-top:20px;padding-left:10px">
                      {{$isicart->produk->nama_produk}} <br>
                      Lapak : {{$isicart->lapak->nama_lapak}} <br>
                      Kontak : {{$isicart->lapak->no_kontak}}
                    </td>
                    <td style="padding-top:20px;padding-left:10px">Rp. {{number_format($isicart->produk->harga_jual)}},-</td>
                    <td style="padding-top:20px;padding-left:10px">{{$isicart->qty}}</td>
                    <td style="padding-top:20px;padding-left:10px">Rp. {{number_format($isicart->produk->harga_jual*$isicart->qty)}},-</td>
                    <td style="padding-top:20px;padding-left:10px">{{$isicart->metode_bayar}}</td>
                    <td style="padding-top:20px;padding-left:10px">
                      <a href="{{url('/edit_cart')}}/{{$isicart->id}}" data-toggle="tooltip" data-placement="top" title="Ubah orderan"><i class="fa fa-edit"></i></a>
                    </td>
                    <td style="padding-top:20px;padding-left:10px">
                      <a href="{{url('/hapus_cart')}}/{{$isicart->id}}" data-toggle="tooltip" data-placement="top" title="Hapus orderan"><i class="ti-trash remove-icon"></i></a>
                    </td>
                  </tr>    
                  @endforeach
                  
                </tbody>
              </table>
            </div>
            <form action="{{ route('order')}}" method="post">
            @csrf
              <div class="row ">
                <div class="col-lg-12 col-12 text-primary">
                  Alamat pengantaran diatur default sesuai alamat anda, silahkan ubah jika alamat pengiriman berbeda :
                </div>
                <input type="hidden" id="customer_id" value="{{ Auth::user()->id}}">
                <div class="col-lg-3 col-12">
                  <div class="form-group">
                    <label>Kecamatan</label>
                    <select name="kecamatan" class="form-control" id="kecamatan_pengantaran">
                      <option value="">-- Pilih Kecamatan --</option>
                      @foreach ($listkecamatan as $listkecamatan)
                      @if($kecamatanuser == $listkecamatan->id)
                      <option value="{{$listkecamatan->id}}" selected>{{$listkecamatan->nama_kecamatan}}</option>
                      @else 
                      <option value="{{$listkecamatan->id}}">{{$listkecamatan->nama_kecamatan}}</option>
                      @endif                        
                      @endforeach
                    </select>
                    @error('kecamatan')
                    <span class="help-block text-danger">Wajib diisi</span>
                    @enderror
                  </div>
                </div>
                <div class="col-lg-9 col-12">
                  <div class="form-group">
                    <label >Alamat</label>
                    <input type="text" name="alamat_kirim" class="form-control" value="{{$alamat}}" style="height:42px;font-size:11pt;">
                    @error('alamat_kirim')
                    <span class="help-block text-danger">Wajib diisi</span>
                    @enderror
                  </div>
                </div>
              </div>
              
              @if($pesan)
              <div class="row ">
                <div class="col-lg-12 col-12">
                  {{$pesan}}
                  <div class="row ">
                    <div class="col-lg-3 col-12">
                      <table>
                        <thead id="tampil_data1">
                          @foreach ($jmllapak as $jmllapak)
                          <tr>
                            <td>{{$jmllapak->nama_lapak }}</td><td class="text-right">Rp. {{ number_format($jmllapak->besar_ongkir) }},-</td>
                          </tr>
                          @endforeach
                        </thead>
                        <thead id="tampil_data2"></thead>
                        <tfoot>
                          <th>Total Ongkir</th><th class="text-right" id="totongkir">Rp. {{number_format($totalongkir)}},-</th>
                        </tfoot>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
              @endif
              Jika ongkos kirim tidak ditetapkan oleh pelapak, maka pembayaran ongkos kirim akan dibayarakan ditempat pengantaran, silahkan menghubungi pelapak untuk lebih detail
              <br><br>
              <div class="row justify-content-lg-end">
                <div class="col-lg-4 col-12">
                  <div class="table-responsive">
                    <table class="table">
                      <thead>
                        <tr>
                          <th>Sub Total</th>
                          <th class="text-right" >
                              <input id="jml_transaksi" type="hidden" value="{{$grandtotal}}">
                             Rp. {{number_format($grandtotal)}},-
                          </th>
                        </tr>
                        <tr>
                          <th>Ongkos Kirim</th>
                          @if($ongkir)
                            @if($pesan)
                            <th class="text-right" id="ongkirnya"> Rp. {{number_format($totalongkir)}},-</th>
                            @else 
                            <th class="text-right" id="ongkirnya"> Rp. {{number_format($ongkir->besar_ongkir)}},-</th>
                            @endif
                          @else 
                          <th class="text-right" id="ongkirnya"> Rp. 0,-</th>
                          @endif
                        </tr>
                        <tr>
                          <th>Grand Total</th>
                          @if($ongkir)
                            @if($pesan)
                            <th class="text-right text-danger" id="grand_total_belanja" > <h6>Rp. {{number_format($grandtotal + $totalongkir)}},-</h6> </th>
                            @else 
                            <th class="text-right text-danger" id="grand_total_belanja"  > <h6>Rp. {{number_format($grandtotal + $ongkir->besar_ongkir)}},-</h6> </th>
                            @endif
                          @else 
                          <th class="text-right text-danger" id="grand_total_belanja" > <h6>Rp. {{number_format($grandtotal)}},-</h6> </th>
                          @endif
                        </tr>
                      </thead>
                    </table>
                    
                  </div>
                  <button type="submit" class="btn btn-primary btn-block">Checkout</button>
                </form>
                  <a href="{{route('landingpage_user')}}" class="btn btn-success btn-block text-light text-center">Lanjutkan Belanja</a>
                </div>
              </div>
            
          </div>
        </div>
      </div>
    </div>
  </div>
  

@include('web.footer')