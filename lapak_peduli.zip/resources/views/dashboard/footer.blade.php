    
    
    <!-- Bootstrap core JavaScript-->
    <script src="{{url('/')}}/dashboard/vendor/jquery/jquery.min.js"></script>
    <script src="{{url('/')}}/dashboard/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="{{url('/')}}/dashboard/vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Page level plugin JavaScript-->
    <script src="{{url('/')}}/dashboard/vendor/chart.js/Chart.min.js"></script>
    <script src="{{url('/')}}/dashboard/vendor/datatables/jquery.dataTables.js"></script>
    <script src="{{url('/')}}/dashboard/vendor/datatables/dataTables.bootstrap4.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="{{url('/')}}/dashboard/js/sb-admin.min.js"></script>
    
    
    <!-- Demo scripts for this page-->
    {{-- <script src="{{url('/')}}/dashboard/js/demo/datatables-demo.js"></script>
    <script src="{{url('/')}}/dashboard/js/demo/chart-area-demo.js"></script> --}}
    <script src="{{url('/')}}/assets/myscript.js"></script>

{{-- <script>
  Chart.defaults.global.defaultFontFamily = '-apple-system,system-ui,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif';
  Chart.defaults.global.defaultFontColor = '#292b2c';

  // Area Chart Example
  var ctx = document.getElementById("myAreaChart");
  var myLineChart = new Chart(ctx, {
    type: 'line',
    data: {
      labels: [ {{$transbulanini }}],
      datasets: [{
        label: "Sessions",
        lineTension: 0.3,
        backgroundColor: "rgba(2,117,216,0.2)",
        borderColor: "rgba(2,117,216,1)",
        pointRadius: 5,
        pointBackgroundColor: "rgba(2,117,216,1)",
        pointBorderColor: "rgba(255,255,255,0.8)",
        pointHoverRadius: 5,
        pointHoverBackgroundColor: "rgba(2,117,216,1)",
        pointHitRadius: 50,
        pointBorderWidth: 2,
        data: [10000, 30162, 26263, 18394, 18287, 28682, 31274, 33259, 25849, 24159, 32651, 31984, 38451],
      }],
    },
    options: {
      scales: {
        xAxes: [{
          time: {
            unit: 'date'
          },
          gridLines: {
            display: false
          },
          ticks: {
            maxTicksLimit: 7
          }
        }],
        yAxes: [{
          ticks: {
            min: 0,
            max: 40000,
            maxTicksLimit: 5
          },
          gridLines: {
            color: "rgba(0, 0, 0, .125)",
          }
        }],
      },
      legend: {
        display: false
      }
    }
  });
</script> --}}

<script>
  Echo.private(`lapak.{{Auth::id()}}`)
  // .listen('StatustransNotif', (e) => {
  .listen('TransaksiBaruNotif', (e) => {
      // console.log(e);
      // $("#notif_status_order").show();
    $("#transnotif").text("*");
    $("#transnotif1").text("*");
    // $("#notransnya").text("" + notrans + "");
  });
</script>

<script>
  Echo.private(`lapak.{{Auth::id()}}`)
  // .listen('StatustransNotif', (e) => {
  .listen('BuktiTransferNotif', (e) => {
      // console.log(e);
      // $("#notif_status_order").show();
    $("#transnotif").text("*");
    $("#transnotif1").text("*");
    // $("#notransnya").text("" + notrans + "");
  });
</script>

  </body>

</html>