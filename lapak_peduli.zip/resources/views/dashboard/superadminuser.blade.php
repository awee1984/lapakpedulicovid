@include('dashboard.superadminheader')
<div class="card mb-3" style="box-shadow:0px 0px 8px #0000001a;">
  <div class="card-header">
    <i class="fas fa-barcode"></i>
    Data User</div>
  <div class="card-body">
    <div class="table-responsive">
      <table class="table table-bordered" id="dataTable2" width="100%" cellspacing="0">
        <thead>
          <tr class="text-center">
            <th>No</th>
            <th>Nama User</th>
            <th>Alamat</th>
            <th>No Handphone</th>
            <th>PIN</th>
            <th>Konfirmasi PIN</th>
            {{-- <th>Foto KTP</th> --}}
            <th>Status</th>
            <th width="8%">Opsi</th>
          </tr>
        </thead>
        <tbody>
          @php
              $no = 1;
          @endphp
          @foreach ($user as $user)
          <tr>
            <td>{{ $no++ }}</td>
            <td style="text-transform:capitalize">{{ $user->nama }} </td>
            <td class="text-center">{{ $user->alamat }}</td>
            <td class="text-center">{{ $user->no_kontak }}</td>
            <td class="text-center">{{ $user->pin }}</td>
            <td class="text-center">{{ $user->konfirm_pin }}</td>
            {{-- <td class="text-center"><img src="{{url('/')}}/assets/user/{{$user->foto_selfi}}" alt="" width="300px"></td> --}}
            <td class="text-center" style="text-transform:capitalize">{{ $user->status_user }}</td>
            <td class="text-center" >
              <a href="{{url('/nonaktifkan_user')}}/{{$user->id}}" class="btn btn-danger btn-sm">Non Aktifkan</a>
            </td>
          </tr>    
          @endforeach
        </tbody>
      </table>
    </div>
  </div>
</div>
@include('dashboard.superadminfooter')