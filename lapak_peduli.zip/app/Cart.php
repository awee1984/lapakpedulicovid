<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Cart extends Model
{
    protected $table ='carts';

    protected $fillable = [
        'tanggal_order', 'user_id', 'produk_id', 'qty', 'request_khusus'
    ];

    public function produk()
    {
    	return $this->belongsTo('App\Produk');
    }

    public function lapak()
    {
    	return $this->belongsTo('App\Lapak');
    }
}
