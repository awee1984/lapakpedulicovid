@include('lapak.header')
<body class="login_background js">

  
	
	<!-- Preloader -->
	<div class="preloader">
		<div class="preloader-inner">
			<div class="preloader-icon">
				<span></span>
				<span></span>
			</div>
		</div>
	</div>
	<!-- End Preloader -->
	
  {{-- <audio controls="controls" onloadeddata="var audioPlayer = this; setTimeout(function() { audioPlayer.play(); }, 3000)" hidden>
    <source src="{{url('/')}}/assets/1.mp3" type="audio/mp3" />
  </audio> --}}
	<!-- Header -->
	<header class="header shop" style="background:#ef0000">
		<div class="middle-inner" style="background:#ef0000">
			<div class="container">
				<div class="row row justify-content-between">
					<div class="col-lg-2 col-md-2 col-12">
						<div class="logo">
							<a href="{{ route('index')}}"><img src="{{url('/')}}/assets/images/lapakpeduli.png" alt="logo" width="200px"></a>
            </div>
          </div>
          <div class="col-lg-10 col-md-3 col-12" >
            <ul class="nav justify-content-end">
              <li class="nav-item">
                <p style="color:white">Belum punya akun? <a style="display:inline" href="{{ url('/daftar_lapak')}}">Daftar disini</a></p>
                 
              </li>
            </ul>
          </div>
				</div>
			</div>
		</div>
	</header>
  <!--/ End Header -->
  {{-- <div class="login_background">

  </div> --}}

  <!-- content -->
  <div class="contact-us section" style="padding:10px;">
    <div class="container">
      <div class="row justify-content-end">
        <div class="col-6">
          <div class="form-main" style="background-color:white;margin-top:120px;padding:30px;">
            <div class="title text-center">
              <h5>Masuk ke akun kamu</h5>
            </div>
            <form class="form" method="post" action="{{ route('lapak_login') }}">
              @csrf
              <div class="row">
                <div class="col-lg-12 col-12">
                  <div class="form-group">
                    <label style="font-size:10pt">Email<span>*</span></label>
                    <input style="font-size:10pt" name="email" type="email" placeholder="Masukan email" value="{{old('email')}}">
                  </div>	
                </div>
                <div class="col-lg-12 col-12">
                  <div class="form-group">
                    <label style="font-size:10pt">Password<span>*</span></label>
                    <input style="font-size:10pt" name="password" id="password_masuk" type="password" placeholder="Masukan password" value="{{old('password')}}">
                  </div>	
                </div>
                <div class="form-check" style="margin-left:35px;">
                  <input class="form-check-input" type="checkbox" value="" id="lihat_password">
                  <label class="form-check-label" style="padding-left:0px;" for="lihat_password">
                    Tampilkan Password
                  </label>
                </div>
                <div class="col-lg-12 col-12">
                  <div class="form-group">
                    <button type="submit" class="btn btn-block btn-info btn-md">Masuk</button>
                  </div>	
                </div>
              </div>
            </form>
            <div class="row">
              <div class="col-lg-12">
                @if (session('pesan'))
                  <div class="alert alert-success">
                    {{ session('pesan') }}
                  </div>
                @endif
                @if (session('gagal_login'))
                  <div class="alert alert-danger">
                    {{ session('gagal_login') }}
                  </div>
                @endif
                @if (session('status'))
                  <div class="alert alert-danger">
                    {{ session('status') }}
                  </div>
                @endif
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- end content -->
  
@include('lapak.footer')
  