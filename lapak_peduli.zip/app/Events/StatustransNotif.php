<?php

namespace App\Events;

use Illuminate\Broadcasting\Channel;
use Illuminate\Queue\SerializesModels;
use Illuminate\Broadcasting\PrivateChannel;
use Illuminate\Broadcasting\PresenceChannel;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Contracts\Broadcasting\ShouldBroadcast;
// use App\Message;
use App\User;

class StatustransNotif implements ShouldBroadcast
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    // public $statustransaksi;
    public $user;
    public $message;

    public function __construct(User $user, $message)
    {
        $this->user = $user;
        $this->message = $message;
    }

    public function broadcastWith()
    {
        return  array(
            'nama'      => $this->user->nama,
            'message'   => $this->message
        );
    }

    public function broadcastOn()
    {
        // return new Channel('userbaru');
        // return ['statustransaksi'];
        return new PrivateChannel('user.'.$this->user->id);
    }

    // public function broadcastAs()
    // {
    //     return 'notif_statustransaksi';
    // }
}
