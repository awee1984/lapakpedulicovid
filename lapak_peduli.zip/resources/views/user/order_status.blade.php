@include('web.header')

<body class="js">
	
	<!-- Preloader -->
	<div class="preloader">
		<div class="preloader-inner">
			<div class="preloader-icon">
				<span></span>
				<span></span>
			</div>
		</div>
	</div>
  <!-- End Preloader -->
  <div class="contact-us section">
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-lg-12 col-12">
          <div class="form-main" style="background-color:white;margin-top:50px;">
            <div class="title">
              <h5>Status Transaksi</h5>
            </div>
            
            <div class="row">
              <div class="col-lg-12">
                @if (session('status'))
                  <div class="alert alert-success">
                      {{ session('status') }}
                  </div>
                @endif
              </div>
            </div>

            <div class="row">
              <div class="col-lg-12">
                @if (session('hapus'))
                  <div class="alert alert-danger">
                      {{ session('hapus') }}
                  </div>
                @endif
              </div>
            </div>
            <div class="table-responsive">
              <table class="table" width="100%">
                <thead style="background-color:#ef0000;color:#fff">
                  <th style="height:60px;padding-left:10px;padding-right:10px;vertical-align:middle;" width="30%">Transaksi</th>
                  <th style="height:60px;padding-left:10px;padding-right:10px;vertical-align:middle;" width="10%">Image</th>
                  <th style="height:60px;padding-left:10px;padding-right:10px;vertical-align:middle;" width="20%">Nama Produk</th>
                  <th style="height:60px;padding-left:10px;padding-right:10px;vertical-align:middle;" width="20%">Keterangan</th>
                  <th style="height:60px;padding-left:10px;padding-right:10px;vertical-align:middle;" width="15%">Metode Bayar</th>
                  <th style="height:60px;padding-left:10px;padding-right:10px;vertical-align:middle;" width="10%">Status</th>
                  <th style="height:60px;padding-left:10px;padding-right:10px;vertical-align:middle;" width="5%"><i class="ti-trash remove-icon"></th>
                </thead>
                <tbody >
                  @foreach ($transaksi as $transaksi)
                  <tr >
                    <td style="padding-top:20px;padding-left:10px">
                      Nomor Transaksi : <br>
                      {{$transaksi->no_transaksi}} <br>
                      Tanggal Transaksi : <br>
                      {{date('d-m-Y',strtotime($transaksi->tanggal_transaksi))}}
                    </td>
                    <td style="padding-top:20px;padding-left:10px">
                      <img src="{{url('/')}}/assets/produk/{{$transaksi->produk->gambar_produk}}" alt="" width="100px">
                    </td>
                    <td style="padding-top:20px;padding-left:10px">
                      Kode Produk : <br>
                      {{$transaksi->produk->kode_produk}} <br>
                      Nama Produk : <br>
                      {{$transaksi->produk->nama_produk}} <br>
                      Lapak : <br>
                      {{$transaksi->produk->lapak->nama_lapak }}
                    </td>
                    <td style="padding-top:20px;padding-left:10px">
                      Harga : <br>
                      Rp. {{number_format($transaksi->produk->harga_jual)}},- <br>
                      Kuantitas : <br>
                      {{number_format($transaksi->qty_produk)}} {{$transaksi->produk->satuan}}<br>
                      Total Harga : <br>
                      Rp. {{number_format($transaksi->qty_produk*$transaksi->produk->harga_jual)}},-
                    </td>
                    <td style="padding-top:20px;padding-left:10px">{{$transaksi->metode_bayar}}</td>
                    <td style="padding-top:20px;padding-left:10px">
                      @if($transaksi->status_transaksi == 'konfirm')
                      <span class="text-success">Pesanan anda telah dikirim</span> 
                      @elseif($transaksi->status_transaksi == 'tunggu verifikasi')
                      <span class="text-warning">Bukti Transfer anda sedang divalidasi</span>
                      @elseif($transaksi->status_transaksi == 'cancel')
                      <span class="text-danger">Maaf, pesanan anda dibatalkan, silahkan kontak pelapak</span>
                      @elseif($transaksi->status_transaksi == 'transaksi expired')
                      <span class="text-danger">Transaksi expired</span>
                      @else
                        @if($transaksi->metode_bayar == 'transfer')
                        <span class="text-primary">Silahkan mengirimkan bukti transfer </span>
                        @else 
                        <span class="text-default">Menunggu Konfir dari pelapak</span>
                        @endif  
                      @endif
                      {{-- {{$transaksi->status_transaksi}}</td> --}}
                    <td style="padding-top:20px;padding-left:10px">
                      @if($transaksi->status_transaksi == 'pending' || $transaksi->status_transaksi == 'transaksi expired')
                      <a href="{{url('/cancel_order')}}/{{$transaksi->id}}" data-toggle="tooltip" data-placement="top" title="Cancel Orderan"><i class="ti-trash remove-icon"></i></a>
                      @endif
                    </td>
                  </tr>    
                  @endforeach
                  
                </tbody>
              </table>
            </div>
            {{-- <form action="{{ route('order')}}" method="post">
              @csrf
              <div class="row ">
                <div class="col-lg-12 col-12">
                  Alamat pengantaran :
                </div>
                <div class="col-lg-3 col-12">
                  <div class="form-group">
                    <label>Kecamatan</label>
                    <select name="kecamatan" class="form-control">
                      <option value="">-- Pilih Kecamatan --</option>
                      @foreach ($listkecamatan as $listkecamatan)
                      @if($kecamatanuser == $listkecamatan->id)
                      <option value="{{$listkecamatan->id}}" selected>{{$listkecamatan->nama_kecamatan}}</option>
                      @else 
                      <option value="{{$listkecamatan->id}}">{{$listkecamatan->nama_kecamatan}}</option>
                      @endif                        
                      @endforeach
                    </select>
                    @error('kecamatan')
                    <span class="help-block text-danger">Wajib diisi</span>
                    @enderror
                  </div>
                </div>
                <div class="col-lg-9 col-12">
                  <div class="form-group">
                    <label >Alamat</label>
                    <input type="text" name="alamat_kirim" class="form-control" value="{{$alamat}}" style="height:42px;font-size:11pt;">
                    @error('alamat_kirim')
                    <span class="help-block text-danger">Wajib diisi</span>
                    @enderror
                  </div>
                </div>
              </div>
            
              <div class="row justify-content-lg-end">
                <div class="col-lg-4 col-12">
                  <div class="table-responsive">
                    <table class="table">
                      <thead>
                        <tr>
                          <th>Sub Total</th>
                          <th class="text-right"> Rp. {{number_format($grandtotal)}},-</th>
                        </tr>
                        <tr>
                          <th>Ongkos Kirim</th>
                          <th class="text-right"> Rp. {{number_format($ongkir->besar_ongkir)}},-</th>
                        </tr>
                        <tr>
                          <th>Grand Total</th>
                          <th class="text-right text-danger" > <h6>Rp. {{number_format($grandtotal + $ongkir->besar_ongkir)}},-</h6> </th>
                        </tr>
                      </thead>
                    </table>
                  </div>
                  <button type="submit" class="btn btn-primary btn-block">Checkout</button>
                </div>
              </div>
            </form> --}}
            @if($jmlcount > 0)
            <div class="row">
              <div class="col-lg-12">
                <div class="alert alert-primary">
                    Produk dengan metode pembayaran <b><u>transfer bank</u></b> akan dikirim setelah dilakukan transfer
                </div>
              </div>
            </div>

            <div class="row">
              <div class="col-lg-12">
                <form action="{{ url('/upload_bukti_bayar') }}" method="post" enctype="multipart/form-data">
                @csrf
                  <div class="row">
                    <div class="col-lg-6">
                      <div class="row">
                        <div class="col-10">
                          <div class="form-group">
                            <label for="no_transaksi">Pilih Transaksi yang akan diupload bukti transfernya</label>
                            <select name="no_transaksi" id="notrans_kirim_bukti" class="form-control">
                              <option value="">-- Pilih No Transfer --</option>
                              @foreach ($notransaksi as $notransaksi)
                              <option value="{{$notransaksi}}">{{$notransaksi}}</option>
                              @endforeach
                            </select>
                          </div>
                        </div>
                      </div>
                      <div class="row">
                        <div class="col-10">
                          <div class="form-group">
                            <label for="id_pelapak">Pilih Lapak</label>
                            <select name="id_pelapak" id="id_pelapak" class="form-control">
                              <option value="">-- Pilih Lapak --</option>
                              
                            </select>
                          </div>
                        </div>
                      </div>
                      <div class="row">
                        <div class="col-10">
                          <h5 style="font-size:12pt;font-weight:normal" id="bank"></h5>
                          <br>
                        </div>
                      </div>
                      <div class="row">
                        <div class="col-12">
                          <div class="form-group">
                            <label>Upload Bukti Transfer</label>
                            {{-- <input type="file" name="gambar" id="preview_gambar" /> --}}
                            <input type="file" name="bukti_transfer" id="file_bukti_transfer" />
                            @error('bukti_transfer')
                            <span class="help-block text-danger">Wajib diisi</span>
                            @enderror
                            <br><br>
                          </div>
                        </div>
                      </div>
                      <div class="row" style="display:none" id="tombol_upload">
                        <div class="col-6">
                          <div class="form-group">
                            <button type="submit" class="btn btn-primary btn-block">Upload Bukti Bayar</button>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="col-lg-6">
                      <div class="row">
                        <div class="col-12">
                          <img width="300" id="previewing"  src="" class="img-responsive">
                          <div id="message_transfer"></div>
                        </div>
                      </div>
                    </div>
                  </div>
                </form>
              </div>
            </div>
            @endif

          </div>
        </div>
      </div>
    </div>
  </div>

@include('web.footer')