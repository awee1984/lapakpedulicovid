<?php

return [

    'defaults' => [
        'guard' => 'web',
        'passwords' => 'users',
    ],

    'guards' => [
        'web' => [
            'driver' => 'session',
            'provider' => 'users',
        ],

        'api' => [
            // 'driver' => 'token',
            'driver' => 'passport',
            'provider' => 'users',
            'hash' => false,
        ],

        'user' => [
            'driver' => 'session',
            'provider' => 'users',
        ],

        'lapak' => [
            'driver' => 'session',
            'provider' => 'lapaks',
        ],

        'superadmin' => [
            'driver' => 'session',
            'provider' => 'superadmins',
        ],
    ],

    
    'providers' => [
        'users' => [
            'driver' => 'eloquent',
            'model' => App\User::class,
        ],

        'lapaks' => [
            'driver' => 'eloquent',
            'model' => App\Lapak::class,
        ],
        'superadmins' => [
            'driver' => 'eloquent',
            'model' => App\Superadmin::class,
        ],

        // 'users' => [
        //     'driver' => 'database',
        //     'table' => 'users',
        // ],
    ],

    
    'passwords' => [
        'users' => [
            'provider' => 'users',
            'table' => 'password_resets',
            'expire' => 60,
        ],

        'lapaks' => [
            'provider' => 'lapaks',
            'table' => 'password_reset',
            'expire' => 60,
        ],

        'superadmins' => [
            'provider' => 'superadmins',
            'table' => 'password_reset',
            'expire' => 60,
        ],
    ],

];
