<?php

namespace App\Http\Controllers\Auth;

// use App\Http\Controllers\Controller;
// use Illuminate\Foundation\Auth\AuthenticatesUsers;

use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Http\Request;
use Auth;
use Illuminate\Support\Facades\Config;

class LoginController extends Controller
{
    use AuthenticatesUsers;

    protected $redirectTo = '/';

    // public function __construct()
    // {
    //     $this->middleware('guest')->except('logout');
    // }
    public function __construct()
    {
        $this->middleware('guest')->except('logout');
        $this->middleware('guest:lapak')->except('logout');
        $this->middleware('guest:superadmin')->except('logout');
        // $this->middleware('guest:customer')->except('logout');
    }

    public function showLapakLoginForm()
    {
        return view('lapak.login');
    }

    public function showSuperAdminLoginForm()
    {
        return view('super_login');
    }

    public function showUserLoginForm()
    {
        return view('user.login');
    }

    public function lapakLogin(Request $request)
    {
        $this->validate($request, [
            'email'    => 'required|email',
            'password' => 'required|min:6'
        ]);

        if (Auth::guard('lapak')->attempt(['email' => $request->email, 'password' => $request->password, 'status' => 'aktif'], $request->get('remember'))) {

            return redirect()->intended('/lapak_home');
        }
        return back()->withInput($request->only('email', 'remember'))->with('status','Maaf, Status Lapak anda menunggu aktivasi dari admin');
    }

    public function superAdminLogin(Request $request)
    {
        $this->validate($request, [
            'email'    => 'required|email',
            'password' => 'required|min:6'
        ]);

        if (Auth::guard('superadmin')->attempt(['email' => $request->email, 'password' => $request->password], $request->get('remember'))) {

            return redirect()->intended('/superadmin_home');
        }
        // else{
        //     return redirect()->intended('/');
        // }
        return back()->withInput($request->only('email', 'remember'));
    }

    public function userLogin(Request $request)
    {
        $this->validate($request, [
            'email'    => 'required|email',
            'password' => 'required|min:6'
        ]);

        if (Auth::guard('user')->attempt(['email' => $request->email, 'password' => $request->password, 'status_user' => 'aktif'], $request->get('remember'))) {

            return redirect()->intended('/landingpage_user');
        }
        return back()->withInput($request->only('email', 'remember'));
    }
}
