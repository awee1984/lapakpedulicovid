<?php echo $__env->make('web.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body class="js">
	
	<!-- Preloader -->
	<div class="preloader">
		<div class="preloader-inner">
			<div class="preloader-icon">
				<span></span>
				<span></span>
			</div>
		</div>
	</div>
  <!-- End Preloader -->
  <div class="contact-us section">
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-lg-12 col-12">
          <div class="form-main" style="background-color:white;margin-top:50px;">
            <div class="title">
              <h5>Status Transaksi</h5>
            </div>
            
            <div class="row">
              <div class="col-lg-12">
                <?php if(session('status')): ?>
                  <div class="alert alert-success">
                      <?php echo e(session('status')); ?>

                  </div>
                <?php endif; ?>
              </div>
            </div>

            <div class="row">
              <div class="col-lg-12">
                <?php if(session('hapus')): ?>
                  <div class="alert alert-danger">
                      <?php echo e(session('hapus')); ?>

                  </div>
                <?php endif; ?>
              </div>
            </div>
            <div class="table-responsive">
              <table class="table" width="100%">
                <thead style="background-color:#ef0000;color:#fff">
                  <th style="height:60px;padding-left:10px;padding-right:10px;vertical-align:middle;" width="30%">Transaksi</th>
                  <th style="height:60px;padding-left:10px;padding-right:10px;vertical-align:middle;" width="10%">Image</th>
                  <th style="height:60px;padding-left:10px;padding-right:10px;vertical-align:middle;" width="20%">Nama Produk</th>
                  <th style="height:60px;padding-left:10px;padding-right:10px;vertical-align:middle;" width="20%">Keterangan</th>
                  <th style="height:60px;padding-left:10px;padding-right:10px;vertical-align:middle;" width="15%">Metode Bayar</th>
                  <th style="height:60px;padding-left:10px;padding-right:10px;vertical-align:middle;" width="10%">Status</th>
                  <th style="height:60px;padding-left:10px;padding-right:10px;vertical-align:middle;" width="5%"><i class="ti-trash remove-icon"></th>
                </thead>
                <tbody >
                  <?php $__currentLoopData = $transaksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaksi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr >
                    <td style="padding-top:20px;padding-left:10px">
                      Nomor Transaksi : <br>
                      <?php echo e($transaksi->no_transaksi); ?> <br>
                      Tanggal Transaksi : <br>
                      <?php echo e(date('d-m-Y',strtotime($transaksi->tanggal_transaksi))); ?>

                    </td>
                    <td style="padding-top:20px;padding-left:10px">
                      <img src="<?php echo e(url('/')); ?>/assets/produk/<?php echo e($transaksi->produk->gambar_produk); ?>" alt="" width="100px">
                    </td>
                    <td style="padding-top:20px;padding-left:10px">
                      Kode Produk : <br>
                      <?php echo e($transaksi->produk->kode_produk); ?> <br>
                      Nama Produk : <br>
                      <?php echo e($transaksi->produk->nama_produk); ?> <br>
                      Lapak : <br>
                      <?php echo e($transaksi->produk->lapak->nama_lapak); ?>

                    </td>
                    <td style="padding-top:20px;padding-left:10px">
                      Harga : <br>
                      Rp. <?php echo e(number_format($transaksi->produk->harga_jual)); ?>,- <br>
                      Kuantitas : <br>
                      <?php echo e(number_format($transaksi->qty_produk)); ?> <?php echo e($transaksi->produk->satuan); ?><br>
                      Total Harga : <br>
                      Rp. <?php echo e(number_format($transaksi->qty_produk*$transaksi->produk->harga_jual)); ?>,-
                    </td>
                    <td style="padding-top:20px;padding-left:10px"><?php echo e($transaksi->metode_bayar); ?></td>
                    <td style="padding-top:20px;padding-left:10px">
                      <?php if($transaksi->status_transaksi == 'konfirm'): ?>
                      <span class="text-success">Pesanan anda telah dikirim</span> 
                      <?php elseif($transaksi->status_transaksi == 'tunggu verifikasi'): ?>
                      <span class="text-warning">Bukti Transfer anda sedang divalidasi</span>
                      <?php elseif($transaksi->status_transaksi == 'cancel'): ?>
                      <span class="text-danger">Maaf, pesanan anda dibatalkan, silahkan kontak pelapak</span>
                      <?php elseif($transaksi->status_transaksi == 'transaksi expired'): ?>
                      <span class="text-danger">Transaksi expired</span>
                      <?php else: ?>
                        <?php if($transaksi->metode_bayar == 'transfer'): ?>
                        <span class="text-primary">Silahkan mengirimkan bukti transfer </span>
                        <?php else: ?> 
                        <span class="text-default">Menunggu Konfir dari pelapak</span>
                        <?php endif; ?>  
                      <?php endif; ?>
                      
                    <td style="padding-top:20px;padding-left:10px">
                      <?php if($transaksi->status_transaksi == 'pending' || $transaksi->status_transaksi == 'transaksi expired'): ?>
                      <a href="<?php echo e(url('/cancel_order')); ?>/<?php echo e($transaksi->id); ?>" data-toggle="tooltip" data-placement="top" title="Cancel Orderan"><i class="ti-trash remove-icon"></i></a>
                      <?php endif; ?>
                    </td>
                  </tr>    
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  
                </tbody>
              </table>
            </div>
            
            <?php if($jmlcount > 0): ?>
            <div class="row">
              <div class="col-lg-12">
                <div class="alert alert-primary">
                    Produk dengan metode pembayaran <b><u>transfer bank</u></b> akan dikirim setelah dilakukan transfer
                </div>
              </div>
            </div>

            <div class="row">
              <div class="col-lg-12">
                <form action="<?php echo e(url('/upload_bukti_bayar')); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                  <div class="row">
                    <div class="col-lg-6">
                      <div class="row">
                        <div class="col-10">
                          <div class="form-group">
                            <label for="no_transaksi">Pilih Transaksi yang akan diupload bukti transfernya</label>
                            <select name="no_transaksi" id="notrans_kirim_bukti" class="form-control">
                              <option value="">-- Pilih No Transfer --</option>
                              <?php $__currentLoopData = $notransaksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notransaksi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($notransaksi); ?>"><?php echo e($notransaksi); ?></option>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                          </div>
                        </div>
                      </div>
                      <div class="row">
                        <div class="col-10">
                          <div class="form-group">
                            <label for="id_pelapak">Pilih Lapak</label>
                            <select name="id_pelapak" id="id_pelapak" class="form-control">
                              <option value="">-- Pilih Lapak --</option>
                              
                            </select>
                          </div>
                        </div>
                      </div>
                      <div class="row">
                        <div class="col-10">
                          <h5 style="font-size:12pt;font-weight:normal" id="bank"></h5>
                          <br>
                        </div>
                      </div>
                      <div class="row">
                        <div class="col-12">
                          <div class="form-group">
                            <label>Upload Bukti Transfer</label>
                            
                            <input type="file" name="bukti_transfer" id="file_bukti_transfer" />
                            <?php if ($errors->has('bukti_transfer')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('bukti_transfer'); ?>
                            <span class="help-block text-danger">Wajib diisi</span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            <br><br>
                          </div>
                        </div>
                      </div>
                      <div class="row" style="display:none" id="tombol_upload">
                        <div class="col-6">
                          <div class="form-group">
                            <button type="submit" class="btn btn-primary btn-block">Upload Bukti Bayar</button>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="col-lg-6">
                      <div class="row">
                        <div class="col-12">
                          <img width="300" id="previewing"  src="" class="img-responsive">
                          <div id="message_transfer"></div>
                        </div>
                      </div>
                    </div>
                  </div>
                </form>
              </div>
            </div>
            <?php endif; ?>

          </div>
        </div>
      </div>
    </div>
  </div>

<?php echo $__env->make('web.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lapak_peduli\lapak_peduli\resources\views/user/order_status.blade.php ENDPATH**/ ?>