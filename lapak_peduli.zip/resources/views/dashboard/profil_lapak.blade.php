@include('dashboard.header')
<div id="content-wrapper">
  <div class="container-fluid">
    <ol class="breadcrumb bg-dark" style="box-shadow:0px 0px 8px #0000001a;">
      <li class="breadcrumb-item">
        <a class="text-light" href="#">Profil Lapak</a>
      </li>
      {{-- <li class="breadcrumb-item active text-light">Profil</li> --}}
    </ol>
    <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#updateprofilModal">
      Update Profil
    </button>
    
    <br><br>
    <div class="row">
      <div class="col-lg-12">
        @if (session('status'))
          <div class="alert alert-success">
              {{ session('status') }}
          </div>
        @endif
      </div>
    </div>
    <!-- Profil -->
    <div class="row">
      <div class="col-12">
        <div class="card">
          <div class="row">
            <div class="col-6">
              <div class="card-body">
                <table width="100%">
                  <thead>
                    <tr>
                      <th width="30%">Nama Lapak </th>
                      <th width="2%">: </th>
                      <th width="68%">{{$datalapak->nama_lapak}}</th>
                    </tr>
                    <tr>
                      <th width="30%">Kode Lapak </th>
                      <th width="2%">: </th>
                      <th width="68%">{{$datalapak->kode_lapak}}</th>
                    </tr>
                    <tr>
                      <th width="30%">Nama Owner </th>
                      <th width="2%">: </th>
                      <th width="68%">{{$datalapak->nama_owner}}</th>
                    </tr>
                    <tr>
                      <th width="30%">No Handphone </th>
                      <th width="2%">: </th>
                      <th width="68%">{{$datalapak->no_kontak}}</th>
                    </tr>
                    <tr>
                      <th width="30%">Alamat </th>
                      <th width="2%">: </th>
                      <th width="68%">{{$datalapak->alamat}}</th>
                    </tr>
                    <tr>
                      <th width="30%">Waktu Buka-Tutup  </th>
                      <th width="2%">: </th>
                      <th width="68%">
                        @if($datalapak->waktu_buka)
                        {{$datalapak->waktu_buka}}
                        @else 
                        <span class="text-danger"> Belum diset </span> 
                        @endif 
                        - 
                        @if($datalapak->waktu_tutup )
                        {{$datalapak->waktu_tutup}}
                        @else 
                        <span class="text-danger"> Belum diset </span> 
                        @endif 
                      </th>
                    </tr>
                    <tr>
                      <th width="30%">No Rekening </th>
                      <th width="2%">: </th>
                      @if($datalapak->bank_id == 0)
                      <th width="68%"><span class="text-danger"> Belum diset </span> | <span class="text-danger"> Belum diset </span> </th>
                      @else 
                      <th width="68%">{{$datalapak->bank->nama_bank}} | {{$datalapak->no_rekening}} </th>
                      @endif
                    </tr>
                  </thead>
                </table>
              </div>
            </div>
              <div class="card-body">
                <div class="col-6">
                  Gambar Backdrop/Logo
                  @if ($datalapak->backdrop)
                  <img width="200"  src="{{url('/')}}/assets/lapak/{{$datalapak->backdrop}}" class="img-responsive">
                  @else 
                  <img width="200"  src="{{url('/')}}/assets/lapak/lapak_default.jpg" class="img-responsive">
                  @endif
                </div>
              </div>
          </div>
        </div>
      </div>
    </div>

    
    

    <!-- edit produk Modal -->
    <div class="modal fade " id="updateprofilModal" tabindex="-1" role="dialog" aria-labelledby="#updateprofilModalTitle" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="updateprofilModalTitle">Update Profil</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <form action="{{ url('/profil_lapak') }}/{{$lapak_id}}" method="post" enctype="multipart/form-data">
            @method('patch')
            @csrf
            <div class="modal-body">
              <div class="row">
                <div class="col-12">
                  <div class="row">
                    <div class="col-6">
                      <div class="row">
                        <div class="col-12">
                          <div class="form-group">
                            <label for="nama_lapak">Nama Lapak</label>
                            <input type="text" name="nama_lapak" id="nama_lapak" class="form-control" placeholder="Nama Lapak" value="{{ $datalapak->nama_lapak}}">
                            @error('nama_lapak')
                            <span class="help-block text-danger">Wajib diisi</span>
                            @enderror
                          </div>
                          <div class="form-group">
                            <label for="nama_owner">Nama Owner</label>
                            <input type="text" name="nama_owner" id="nama_owner" class="form-control" placeholder="Nama Owner" value="{{ $datalapak->nama_owner}}">
                            @error('nama_owner')
                            <span class="help-block text-danger">Wajib diisi</span>
                            @enderror
                          </div>
                          <div class="form-group">
                            <label for="no_kontak">No Handphone/Whatsapp</label>
                            <input type="text" name="no_kontak" id="no_kontak" class="form-control" placeholder="No Handphone/Whatsapp" value="{{ $datalapak->no_kontak}}">
                            @error('no_kontak')
                            <span class="help-block text-danger">Wajib diisi</span>
                            @enderror
                          </div>
                          <div class="form-group">
                            <label for="alamat">Alamat</label>
                            <input type="text" name="alamat" id="alamat" class="form-control" placeholder="Alamat" value="{{ $datalapak->alamat}}">
                            @error('alamat')
                            <span class="help-block text-danger">Wajib diisi</span>
                            @enderror
                          </div>
                        </div>
                      </div>
                      <div class="row">
                        <div class="col-4">
                          <div class="form-group">
                            <label for="waktu_buka">Buka</label>
                            <input type="text" name="waktu_buka" id="waktu_buka" class="form-control" placeholder="mis: 08.00" value="{{ $datalapak->waktu_buka}}">
                          </div>
                        </div>
                        <div class="col-4">
                          <div class="form-group">
                            <label for="waktu_tutup">Tutup</label>
                            <input type="text" name="waktu_tutup" id="waktu_tutup" class="form-control" placeholder="mis: 22.00" value="{{ $datalapak->waktu_tutup}}">
                          </div>
                        </div>
                      </div>
                      <div class="row">
                        <div class="col-6">
                          <div class="form-group">
                            <label for="bank">Bank</label>
                            <select name="bank" id="bank" class="form-control">
                              <option value="">-- Pilih Bank --</option>
                              @foreach ($bank as $bank)
                                @if ($datalapak->bank_id == $bank->id)
                                <option value="{{$bank->id}}" selected>{{$bank->nama_bank}}</option>
                                @else     
                                <option value="{{$bank->id}}">{{$bank->nama_bank}}</option>
                                @endif
                              @endforeach
                            </select>
                          </div>
                        </div>
                        <div class="col-6">
                          <div class="form-group">
                            <label for="no_rekening">No Rekening</label>
                            <input type="text" name="no_rekening" id="no_rekening" class="form-control" placeholder="Nomor Rekening" value="{{ $datalapak->no_rekening}}">
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="col-6">
                      <div class="form-group">
                        <label>Gambar Backdrop</label>
                        {{-- <input type="file" name="gambar" id="preview_gambar" /> --}}
                        <input type="file" name="gambar" id="file_backdrop" />
                        <br><br>
                        <img width="300" id="previewing"  src="" class="img-responsive">
                        <div id="message_backdrop"></div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="modal-footer">
              <button type="submit" class="btn btn-success btn-sm">Simpan</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>

  

  <!-- Sticky Footer -->
  <footer class="sticky-footer">
    <div class="container my-auto">
      <div class="copyright text-center my-auto">
        <span>Copyright © Lapak_Peduli_Covid19 2020</span>
      </div>
    </div>
  </footer>
</div>
@include('dashboard.footer')