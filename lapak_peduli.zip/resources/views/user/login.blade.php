<!DOCTYPE html>
<html lang="zxx">
<head>
	<!-- Meta Tag -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name='copyright' content=''>
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<!-- Title Tag  -->
    <title>Lapak Peduli Covid19</title>
	<!-- Favicon -->
	<link rel="icon" type="image/png" href="images/favicon.png">
	<!-- Web Font -->
	<link href="https://fonts.googleapis.com/css?family=Poppins:200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&display=swap" rel="stylesheet">
	
	<!-- StyleSheet -->
	
	<!-- Bootstrap -->
	<link rel="stylesheet" href="{{url('/')}}/assets/css/bootstrap.css">
	<!-- Magnific Popup -->
    <link rel="stylesheet" href="{{url('/')}}/assets/css/magnific-popup.min.css">
	<!-- Font Awesome -->
    <link rel="stylesheet" href="{{url('/')}}/assets/css/font-awesome.css">
	<!-- Fancybox -->
	<link rel="stylesheet" href="{{url('/')}}/assets/css/jquery.fancybox.min.css">
	<!-- Themify Icons -->
    <link rel="stylesheet" href="{{url('/')}}/assets/css/themify-icons.css">
	<!-- Nice Select CSS -->
    <link rel="stylesheet" href="{{url('/')}}/assets/css/niceselect.css">
	<!-- Animate CSS -->
    <link rel="stylesheet" href="{{url('/')}}/assets/css/animate.css">
	<!-- Flex Slider CSS -->
    <link rel="stylesheet" href="{{url('/')}}/assets/css/flex-slider.min.css">
	<!-- Owl Carousel -->
    <link rel="stylesheet" href="{{url('/')}}/assets/css/owl-carousel.css">
	<!-- Slicknav -->
    <link rel="stylesheet" href="{{url('/')}}/assets/css/slicknav.min.css">
	
	<!-- Eshop StyleSheet -->
	<link rel="stylesheet" href="{{url('/')}}/assets/css/reset.css">
	<link rel="stylesheet" href="{{url('/')}}/assets/style.css">
	<link rel="stylesheet" href="{{url('/')}}/assets/mystyle.css">
  <link rel="stylesheet" href="{{url('/')}}/assets/css/responsive.css">

	
	
</head>
<body class="login_background js">
	
	<!-- Preloader -->
	<div class="preloader">
		<div class="preloader-inner">
			<div class="preloader-icon">
				<span></span>
				<span></span>
			</div>
		</div>
	</div>
	<!-- End Preloader -->
	
	
	<!-- Header -->
	<header class="header shop" style="background:#ef0000">
		<div class="middle-inner" style="background:#ef0000">
			<div class="container">
				<div class="row row justify-content-between">
					<div class="col-lg-2 col-md-2 col-12">
						<div class="logo">
							<a href="{{ route('index')}}"><img src="{{url('/')}}/assets/images/lapakpeduli.png" alt="logo" width="200px"></a>
            </div>
          </div>
          <div class="col-lg-10 col-md-3 col-12" >
            <ul class="nav justify-content-end">
              <li class="nav-item">
                <p style="color:white">Belum punya akun? <a style="display:inline" href="{{ url('/daftar_user')}}">Daftar disini</a></p>
                 
              </li>
            </ul>
          </div>
				</div>
			</div>
		</div>
	</header>
  <!--/ End Header -->
  {{-- <div class="login_background">

  </div> --}}

  <!-- content -->
  <div class="contact-us section" style="padding:10px;">
    <div class="container">
      <div class="row justify-content-end">
        <div class="col-lg-6 col-12">
          <div class="form-main" style="background-color:white;margin-top:120px;padding:30px;">
            <div class="title text-center">
              <h5>Masuk ke akun kamu</h5>
            </div>
            <form class="form" method="post" action="{{ route('user_login') }}">
              @csrf
              <div class="row">
                <div class="col-lg-12 col-12">
                  <div class="form-group">
                    <label style="font-size:10pt">Email<span>*</span></label>
                    <input style="font-size:10pt" name="email" type="email" placeholder="Masukan email" value="{{old('email')}}">
                  </div>	
                </div>
                <div class="col-lg-12 col-12">
                  <div class="form-group">
                    <label style="font-size:10pt">Password<span>*</span></label>
                    <input style="font-size:10pt" name="password" id="password_masuk" type="password" placeholder="Masukan password" value="{{old('password')}}">
                  </div>	
                </div>
                <div class="form-check" style="margin-left:35px;">
                  <input class="form-check-input" type="checkbox" value="" id="lihat_password">
                  <label class="form-check-label" style="padding-left:0px;" for="lihat_password">
                    Tampilkan Password
                  </label>
                </div>
                <div class="col-lg-12 col-12">
                  <div class="form-group">
                    <button type="submit" class="btn btn-block btn-info btn-md">Masuk</button>
                  </div>	
                </div>
                
                
                
              </div>
            </form>
            <div class="row">
              <div class="col-lg-12">
                @if (session('pesan'))
                  <div class="alert alert-success">
                    {{ session('pesan') }}
                  </div>
                @endif
                @if (session('gagal_login'))
                  <div class="alert alert-danger">
                    {{ session('gagal_login') }}
                  </div>
                @endif
                @if (session('status'))
                  <div class="alert alert-danger">
                    {{ session('status') }}
                  </div>
                @endif
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- end content -->
  
  <!-- Start Footer Area -->
  {{-- <footer class="footer">
    <div class="copyright">
      <div class="container">
        <div class="inner">
          <div class="row">
            <div class="col-lg-6 col-12">
              <div class="left">
                <p>Copyright © 2020 Komunitas Peduli Covid  -  All Rights Reserved.</p>
              </div>
            </div>
          </div>
        </div>
      </div>  
    </div>
  </footer> --}}
  <!-- /End Footer Area -->

  <!-- Jquery -->
  <script src="{{url('/')}}/assets/js/jquery.min.js"></script>
  <script src="{{url('/')}}/assets/js/jquery-migrate-3.0.0.js"></script>
  <script src="{{url('/')}}/assets/js/jquery-ui.min.js"></script>
  <!-- Popper JS -->
  <script src="{{url('/')}}/assets/js/popper.min.js"></script>
  <!-- Bootstrap JS -->
  <script src="{{url('/')}}/assets/js/bootstrap.min.js"></script>
  <!-- Color JS -->
  <script src="{{url('/')}}/assets/js/colors.js"></script>
  <!-- Slicknav JS -->
  <script src="{{url('/')}}/assets/js/slicknav.min.js"></script>
  <!-- Owl Carousel JS -->
  <script src="{{url('/')}}/assets/js/owl-carousel.js"></script>
  <!-- Magnific Popup JS -->
  <script src="{{url('/')}}/assets/js/magnific-popup.js"></script>
  <!-- Waypoints JS -->
  <script src="{{url('/')}}/assets/js/waypoints.min.js"></script>
  <!-- Countdown JS -->
  <script src="{{url('/')}}/assets/js/finalcountdown.min.js"></script>
  <!-- Nice Select JS -->
  <script src="{{url('/')}}/assets/js/nicesellect.js"></script>
  <!-- Flex Slider JS -->
  <script src="{{url('/')}}/assets/js/flex-slider.js"></script>
  <!-- ScrollUp JS -->
  <script src="{{url('/')}}/assets/js/scrollup.js"></script>
  <!-- Onepage Nav JS -->
  <script src="{{url('/')}}/assets/js/onepage-nav.min.js"></script>
  <!-- Easing JS -->
  <script src="{{url('/')}}/assets/js/easing.js"></script>
  <!-- Active JS -->
  <script src="{{url('/')}}/assets/js/active.js"></script>
  <script src="{{url('/')}}/assets/myscript.js"></script>
</body>
</html>
  