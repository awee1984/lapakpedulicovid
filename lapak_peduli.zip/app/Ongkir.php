<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Ongkir extends Model
{
    protected $table = 'ongkirs';

    public function kecamatan()
    {
    	return $this->belongsTo('App\Kecamatan');
    }
}
