<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;

class LapakpeduliEmail extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        return $this->from('lapak.peduli.covid@gmail.com')
                   ->view('emaildaftar')
                   ->with(
                    [
                        'nama' => 'Admin',
                        'website' => 'www.lapakpeduli.com',
                        'pesan' => 'Terima kasih telah bergabung bersama kami, akun anda telah aktif dan selamat melapak bersama kami. #dirumahaja',
                    ]);
        // return $this->view('view.name');
    }
}
