@include('dashboard.header')
<div id="content-wrapper">
  <div class="container-fluid">
    <ol class="breadcrumb bg-dark" style="box-shadow:0px 0px 8px #0000001a;">
      <li class="breadcrumb-item">
        <a class="text-light" href="#">Produk</a>
      </li>
      <li class="breadcrumb-item active text-light">Daftar Produk</li>
    </ol>
    <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#tambahprodukModal">
      Tambah produk
    </button>
    {{-- <a href="{{ url('/produk_tambah')}}" class="btn btn-primary btn-sm">Tambah Produk</a> --}}
    <br><br>
    <div class="row">
      <div class="col-lg-12">
        @if (session('status'))
        <div class="alert alert-success">
          {{ session('status') }}
        </div>
        @endif
      </div>
    </div>
    <!-- DataTables Example -->
    <div class="card mb-3" style="box-shadow:0px 0px 8px #0000001a;">
      <div class="card-header">
        <i class="fas fa-barcode"></i>
        Data Produk</div>
      <div class="card-body">
        <div class="table-responsive">
          <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
            <thead>
              <tr class="text-center">
                <th>No</th>
                <th>Nama Produk</th>
                <th>Satuan</th>
                <th>Stok</th>
                <th>Harga</th>
                <th>Gambar Produk</th>
                <th>Metode Pembayaran</th>
                <th>Status</th>
                <th width="18%">Opsi</th>
              </tr>
            </thead>
            <tbody>
              @php
              $no = 1;
              @endphp
              @foreach ($produk as $produk)
              <tr>
                <td>{{ $no++ }}</td>
                <td style="text-transform:capitalize">
                  {{ $produk->nama_produk }} <br>
                  ({{ $produk->kategori->nama_kategori }})
                </td>
                <td class="text-center">{{ $produk->satuan }}</td>
                <td class="text-center">{{ $produk->qty }}</td>
                <td class="text-right">{{ number_format($produk->harga_jual) }},-</td>
                <td class="text-center">
                  <img width="200" src="{{ url('assets/produk/'.$produk->gambar_produk) }}" class="img-responsive">
                </td>
                <td>
                  @if($produk->metode_bayar == 0)
                  Transfer Bank
                  @else
                  Transfer & COD
                  @endif
                </td>
                <td class="text-center" style="text-transform:capitalize">{{ $produk->status_produk }}</td>
                <td class="text-center">
                  <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#editprodukModal"
                    data-id="{{ $produk->id }}" data-nama_produk="{{ $produk->nama_produk }}"
                    data-kategori="{{ $produk->kategori_id }}" data-satuan="{{ $produk->satuan }}"
                    data-qty="{{ $produk->qty }}" data-harga_jual="{{ $produk->harga_jual }}"
                    data-gambar_produk="{{ $produk->gambar_produk }}" data-deskripsi="{{ $produk->deskripsi_produk }}"
                    data-metodebayar="{{ $produk->metode_bayar }}">Edit</button>
                  @if($produk->status_produk == 'tersedia')
                  <a href="{{ url('/nonaktifkan_produk')}}/{{$produk->id}}" class="btn btn-danger  btn-sm">Non
                    Aktifkan</a>
                  @else
                  <a href="{{ url('/aktifkan_produk')}}/{{$produk->id}}" class="btn btn-success  btn-sm">Aktifkan</a>
                  @endif
                </td>
              </tr>
              @endforeach
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- tambah produk Modal -->
    <div class="modal fade " id="tambahprodukModal" tabindex="-1" role="dialog"
      aria-labelledby="#tambahprodukModalTitle" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="tambahprodukModalTitle">Tambah Produk</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <form action="{{ url('/produk_tambah') }}" method="post" enctype="multipart/form-data">
            @csrf
            <div class="modal-body">
              <div class="row">
                <div class="col-12">
                  <div class="row">
                    <div class="col-6">
                      <div class="form-group">
                        <select name="kategori_id" class="form-control">
                          <option value="">-- Pilih Kategori --</option>
                          @foreach ($kategori as $kategori)
                          <option style="text-transform:capitalize" value="{{$kategori->id}}">
                            {{$kategori->nama_kategori}}</option>
                          @endforeach
                        </select>
                        @error('kategori_id')
                        <span class="help-block text-danger">Wajib diisi</span>
                        @enderror
                      </div>
                      <div class="form-group">
                        <input type="text" name="nama_produk" class="form-control" placeholder="Nama Produk"
                          value="{{ old('nama_produk')}}">
                        @error('nama_produk')
                        <span class="help-block text-danger">Wajib diisi</span>
                        @enderror
                      </div>
                      <div class="form-group">
                        <input type="text" name="satuan" class="form-control" placeholder="Satuan"
                          value="{{ old('satuan')}}">
                        @error('satuan')
                        <span class="help-block text-danger">Wajib diisi</span>
                        @enderror
                      </div>
                      <div class="form-group">
                        <input type="number" name="stok" class="form-control" placeholder="Jumlah Stok"
                          value="{{ old('stok')}}">
                        @error('stok')
                        <span class="help-block text-danger">Wajib diisi</span>
                        @enderror
                      </div>
                      <div class="form-group">
                        <input type="number" name="harga" class="form-control" placeholder="Harga"
                          value="{{ old('harga')}}">
                        @error('harga')
                        <span class="help-block text-danger">Wajib diisi</span>
                        @enderror
                      </div>

                      <div class="form-group">
                        <textarea name="deskripsi_produk" rows="5" class="form-control" placeholder="Deskripsi produk"
                          value="{{ old('deskripsi_produk')}}"></textarea>
                        @error('deskripsi_produk')
                        <span class="help-block text-danger">Wajib diisi</span>
                        @enderror
                      </div>
                      <div class="form-check">
                        <input class="form-check-input" type="checkbox" name="check_cod" id="check_cod">
                        <label class="form-check-label" for="check_cod">
                          Centang jika melayani COD
                        </label>
                      </div>
                    </div>
                    <div class="col-6">
                      <img width="300" id="previewing" src="{{ url('/')}}/assets/images/produk_default.jpg"
                        class="img-responsive">
                      <br><br>
                      {{-- <input type="file" name="gambar" id="preview_gambar" /> --}}
                      <input type="file" name="gambar_produk" id="gambar_produk" />
                      <div id="pesan_gambar_produk"></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="modal-footer">
              <button type="submit" class="btn btn-success btn-sm">Simpan</button>
            </div>
          </form>
        </div>
      </div>
    </div>

    <!-- edit produk Modal -->
    <div class="modal fade " id="editprodukModal" tabindex="-1" role="dialog" aria-labelledby="#editprodukModalTitle"
      aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="editprodukModalTitle">Edit Produk</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <form action="{{ url('/produk_update') }}" method="post" enctype="multipart/form-data">
            {{-- @method('patch') --}}
            @csrf
            <div class="modal-body">
              <div class="row">
                <div class="col-12">
                  <div class="row">
                    <div class="col-6">
                      <div class="form-group">
                        <input type="hidden" name="produk_id" id="produk_id" value="">
                        <select name="kategori_id_edit" id="kategori" class="form-control"
                          style="text-transform:capitalize">
                          <option value="">-- Pilih Kategori --</option>
                          @foreach ($kategori2 as $kategori2)
                          <option style="text-transform:capitalize" value="{{$kategori2->id}}">
                            {{$kategori2->nama_kategori}}</option>
                          @endforeach
                        </select>
                        @error('kategori_id_edit')
                        <span class="help-block text-danger">Wajib diisi</span>
                        @enderror
                      </div>
                      <div class="form-group">
                        <input type="text" name="nama_produk_edit" id="nama_produk" class="form-control"
                          placeholder="Nama Produk_edit">
                        @error('nama_produk_edit')
                        <span class="help-block text-danger">Wajib diisi</span>
                        @enderror
                      </div>
                      <div class="form-group">
                        <input type="text" name="satuan_edit" id="satuan" class="form-control" placeholder="Satuan">
                        @error('satuan_edit')
                        <span class="help-block text-danger">Wajib diisi</span>
                        @enderror
                      </div>
                      <div class="form-group">
                        <input type="number" name="stok_edit" id="stok" class="form-control" placeholder="Jumlah Stok">
                        @error('stok_edit')
                        <span class="help-block text-danger">Wajib diisi</span>
                        @enderror
                      </div>
                      <div class="form-group">
                        <input type="number" name="harga_edit" id="harga" class="form-control" placeholder="Harga">
                        @error('harga_edit')
                        <span class="help-block text-danger">Wajib diisi</span>
                        @enderror
                      </div>
                      <div class="form-group">
                        <textarea name="deskripsi_produk_edit" id="deskripsi_produk" rows="5" class="form-control"
                          placeholder="Deskripsi produk"></textarea>
                        @error('deskripsi_produk_edit')
                        <span class="help-block text-danger">Wajib diisi</span>
                        @enderror
                      </div>
                      <div class="form-check">
                        <input class="form-check-input" type="checkbox" name="check_cod_edit" id="check_cod_edit"
                          value="0">
                        <label class="form-check-label" for="check_cod_edit">
                          Centang jika melayani COD
                        </label>
                      </div>
                    </div>
                    <div class="col-6">
                      <img width="300" id="previewing_edit" src="" class="img-responsive">
                      <br><br>
                      {{-- <input type="file" name="gambar" id="preview_gambar" /> --}}
                      <input type="file" name="gambar_edit" id="gambar_edit" />
                      <div id="pesan_gambar_edit"></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="modal-footer">
              <button type="submit" class="btn btn-success btn-sm">Simpan</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>



  <!-- Sticky Footer -->
  <footer class="sticky-footer">
    <div class="container my-auto">
      <div class="copyright text-center my-auto">
        <span>Copyright © Lapak_Peduli_Covid19 2020</span>
      </div>
    </div>
  </footer>
</div>
@include('dashboard.footer')