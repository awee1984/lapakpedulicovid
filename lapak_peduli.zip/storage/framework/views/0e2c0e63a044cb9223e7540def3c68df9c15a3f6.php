  <!-- Start Footer Area -->
  
  <!-- /End Footer Area -->

  <!-- Jquery -->
  <script src="<?php echo e(url('/')); ?>/assets/js/jquery.min.js"></script>
  <script src="<?php echo e(url('/')); ?>/assets/js/jquery-migrate-3.0.0.js"></script>
  <script src="<?php echo e(url('/')); ?>/assets/js/jquery-ui.min.js"></script>
  <!-- Popper JS -->
  <script src="<?php echo e(url('/')); ?>/assets/js/popper.min.js"></script>
  <!-- Bootstrap JS -->
  <script src="<?php echo e(url('/')); ?>/assets/js/bootstrap.min.js"></script>
  <!-- Color JS -->
  <script src="<?php echo e(url('/')); ?>/assets/js/colors.js"></script>
  <!-- Slicknav JS -->
  <script src="<?php echo e(url('/')); ?>/assets/js/slicknav.min.js"></script>
  <!-- Owl Carousel JS -->
  <script src="<?php echo e(url('/')); ?>/assets/js/owl-carousel.js"></script>
  <!-- Magnific Popup JS -->
  <script src="<?php echo e(url('/')); ?>/assets/js/magnific-popup.js"></script>
  <!-- Waypoints JS -->
  <script src="<?php echo e(url('/')); ?>/assets/js/waypoints.min.js"></script>
  <!-- Countdown JS -->
  <script src="<?php echo e(url('/')); ?>/assets/js/finalcountdown.min.js"></script>
  <!-- Nice Select JS -->
  <script src="<?php echo e(url('/')); ?>/assets/js/nicesellect.js"></script>
  <!-- Flex Slider JS -->
  <script src="<?php echo e(url('/')); ?>/assets/js/flex-slider.js"></script>
  <!-- ScrollUp JS -->
  <script src="<?php echo e(url('/')); ?>/assets/js/scrollup.js"></script>
  <!-- Onepage Nav JS -->
  <script src="<?php echo e(url('/')); ?>/assets/js/onepage-nav.min.js"></script>
  <!-- Easing JS -->
  <script src="<?php echo e(url('/')); ?>/assets/js/easing.js"></script>
  <!-- Active JS -->
  <script src="<?php echo e(url('/')); ?>/assets/js/active.js"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\lapak_peduli\lapak_peduli\resources\views/member/footer.blade.php ENDPATH**/ ?>