<?php

namespace App\Http\Controllers\Web;

use App\Kategori;
use App\Produk;
use App\Lapak;
use App\Cart;
use App\User;
use App\Kecamatan;
use App\Ongkir;
use App\Transaksi;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use App\Events\TransaksiBaruNotif;
use App\Events\BuktiTransferNotif;
use Illuminate\Support\Carbon;

class LandingpageController extends Controller
{
    public $pathbuktitransfer;

    public function __construct()
    {
        $this->pathbuktitransfer = 'assets/buktitransfer';
    }

    public function index(Request $request)
    {
        // $produk = DB::table('produks')
        //     ->join('lapaks','produks.lapak_id','lapaks.id')
        //     ->get();

        $produk = Produk::where('status_produk','tersedia')->paginate(10);
        $produk2 = Produk::where('status_produk','tersedia')->paginate(2);
        
        $kategori = Kategori::orderBy('nama_kategori')->get();
        $kategori2 = Kategori::orderBy('nama_kategori')->get();
        $term_kategori = '';
        $statuscari = $produk->count();
        $statuscari2 = $produk2->count();
        if($term = request('cari'))
        {
            $term_kategori = request('kategori');
            if($term_kategori == '')
            {
                $produk = DB::table('produks')
                    ->join('lapaks','produks.lapak_id','lapaks.id')
                    ->where('produks.status_produk','tersedia')
                    ->where('produks.nama_produk','LIKE',"%{$term}%")
                    ->orWhere('lapaks.nama_lapak','LIKE',"%{$term}%")
                    ->paginate(5);
                $produk2 = Produk::where('status_produk','tersedia')->where('nama_produk','LIKE',"%{$term}%")->paginate(5);
                $kategori = Kategori::orderBy('nama_kategori')->get();
                $kategori2 = Kategori::orderBy('nama_kategori')->get();
                $statuscari = $produk->count();
            }else{
                $produk = Produk::where('status_produk','tersedia')->where('nama_produk','LIKE',"%{$term}%")->where('kategori_id',$term_kategori)->paginate(5);
                $produk2 = Produk::where('status_produk','tersedia')->where('nama_produk','LIKE',"%{$term}%")->where('kategori_id',$term_kategori)->paginate(5);
                $kategori = Kategori::orderBy('nama_kategori')->get();
                $kategori2 = Kategori::orderBy('nama_kategori')->get();
                $statuscari = $produk->count();
            }
        }

        if($term_listkategori = request('list_kategori'))
        {
            $produk2 = Produk::where('kategori_id',$term_listkategori)->paginate(30);
            $statuscari2 = $produk2->count();
        }

        if ($request->ajax()) {
    		$view = view('web.data_produk',compact('produk','produk2','kategori','kategori2','term_kategori','statuscari','statuscari2'))->render();
            return response()->json(['html'=>$view]);
        }

        return view('web.landingpage',compact('produk','produk2','kategori','kategori2','term_kategori','statuscari','statuscari2'));
    }

    public function landing_user()
    {
        $userlogin = Auth::user()->nama;
        $produk1 = Produk::where('status_produk','tersedia')->get();
        $produk2 = Produk::where('status_produk','tersedia')->get();
        $kategori = Kategori::orderBy('nama_kategori')->get();
        $kategori2 = Kategori::orderBy('nama_kategori')->get();
        $term_kategori = '';
        $statuscari = $produk1->count();
        $statuscari2 = $produk2->count();
        if($term = request('cari'))
        {
            $term_kategori = request('kategori');
            if($term_kategori == '')
            {
                $produk1 = Produk::where('status_produk','tersedia')->where('nama_produk','LIKE',"%{$term}%")->get();
                $produk2 = Produk::where('status_produk','tersedia')->where('nama_produk','LIKE',"%{$term}%")->get();
                $kategori = Kategori::orderBy('nama_kategori')->get();
                $kategori2 = Kategori::orderBy('nama_kategori')->get();
                $statuscari = $produk1->count();
            }else{
                $produk1 = Produk::where('status_produk','tersedia')->where('nama_produk','LIKE',"%{$term}%")->where('kategori_id',$term_kategori)->get();
                $produk2 = Produk::where('status_produk','tersedia')->where('nama_produk','LIKE',"%{$term}%")->where('kategori_id',$term_kategori)->get();
                $kategori = Kategori::orderBy('nama_kategori')->get();
                $kategori2 = Kategori::orderBy('nama_kategori')->get();
                $statuscari = $produk1->count();
            }
        }

        if($term_listkategori = request('list_kategori'))
        {
            $produk2 = Produk::where('kategori_id',$term_listkategori)->get();
            $statuscari2 = $produk2->count();
        }

       
        
        // return ($transexpired);
        return view('web.landingpage_user',compact('produk1','produk2','kategori','kategori2','term_kategori','statuscari','statuscari2','userlogin'));
    }

    public function lihat(Produk $produk)
    {    
        $userlogin = Auth::user()->nama;
        $produk1 = Produk::where('status_produk','tersedia')->get();
        $produk2 = Produk::where('status_produk','tersedia')->get();
        $kategori = Kategori::orderBy('nama_kategori')->get();
        $kategori2 = Kategori::orderBy('nama_kategori')->get();
        $term_kategori = '';
        $statuscari = $produk1->count();
        $statuscari2 = $produk2->count();
        if($term = request('cari'))
        {
            $term_kategori = request('kategori');
            if($term_kategori == '')
            {
                $produk1 = Produk::where('status_produk','tersedia')->where('nama_produk','LIKE',"%{$term}%")->get();
                $produk2 = Produk::where('status_produk','tersedia')->where('nama_produk','LIKE',"%{$term}%")->get();
                $kategori = Kategori::orderBy('nama_kategori')->get();
                $kategori2 = Kategori::orderBy('nama_kategori')->get();
                $statuscari = $produk1->count();
            }else{
                $produk1 = Produk::where('status_produk','tersedia')->where('nama_produk','LIKE',"%{$term}%")->where('kategori_id',$term_kategori)->get();
                $produk2 = Produk::where('status_produk','tersedia')->where('nama_produk','LIKE',"%{$term}%")->where('kategori_id',$term_kategori)->get();
                $kategori = Kategori::orderBy('nama_kategori')->get();
                $kategori2 = Kategori::orderBy('nama_kategori')->get();
                $statuscari = $produk->count();
            }

            return view('web.landingpage_user',compact('produk','produk2','kategori','kategori2','term_kategori','statuscari','statuscari2','userlogin'));
        }

        if($term_listkategori = request('list_kategori'))
        {
            $produk2 = Produk::where('kategori_id',$term_listkategori)->get();
            $statuscari2 = $produk2->count();

            return view('web.landingpage_user',compact('produk','produk2','kategori','kategori2','term_kategori','statuscari','statuscari2','userlogin'));
        }

        // $gambarproduk = Produk::find($id)->first();
        $metodebayar = Produk::find($produk)->first();
        // return ($metodebayar);

        return view('web.lihat_produk',compact('produk1','produk2','kategori','kategori2','term_kategori','statuscari','statuscari2','produk','userlogin','metodebayar'));
    }

    public function masuk_keranjang(Request $request, Produk $produk)
    {
        $stokproduk = Produk::find($produk->id);
        // return ($stokproduk->qty);
        if($request->kuantitas > $stokproduk->qty){
            return back()->with('Opps','Jumlah Stok tidak mencukupi');   
        }

        date_default_timezone_set('Asia/Makassar');
        $tanggal_order = date('Ymd');
        $userid = Auth::user()->id;

        $cart = New Cart;

        $cart->tanggal_order    = $tanggal_order;
        $cart->user_id          = $userid;
        $cart->produk_id        = $produk->id;
        $cart->lapak_id         = $produk->lapak_id;
        $cart->qty              = $request->kuantitas;
        $cart->request_khusus   = $request->request_khusus;
        $cart->metode_bayar     = $request->metodebayar;
        
        $cart->save();

        // mengupdate stok produk
        $produk = Produk::find($produk->id);
        $produk->qty  = $stokproduk->qty - $request->kuantitas;

        $produk->save();

        return redirect ('/cart')->with('status', 'Produk dimasukkan dalam keranjang!');
    }


    public function cart()
    {
        $userlogin = Auth::user()->nama;
        $produk1 = Produk::where('status_produk','tersedia')->get();
        $produk2 = Produk::where('status_produk','tersedia')->get();
        $kategori = Kategori::orderBy('nama_kategori')->get();
        $kategori2 = Kategori::orderBy('nama_kategori')->get();
        $term_kategori = '';
        $statuscari = $produk1->count();
        $statuscari2 = $produk2->count();
        if($term = request('cari'))
        {
            $term_kategori = request('kategori');
            if($term_kategori == '')
            {
                $produk1 = Produk::where('status_produk','tersedia')->where('nama_produk','LIKE',"%{$term}%")->get();
                $produk2 = Produk::where('status_produk','tersedia')->where('nama_produk','LIKE',"%{$term}%")->get();
                $kategori = Kategori::orderBy('nama_kategori')->get();
                $kategori2 = Kategori::orderBy('nama_kategori')->get();
                $statuscari = $produk1->count();
            }else{
                $produk1 = Produk::where('status_produk','tersedia')->where('nama_produk','LIKE',"%{$term}%")->where('kategori_id',$term_kategori)->get();
                $produk2 = Produk::where('status_produk','tersedia')->where('nama_produk','LIKE',"%{$term}%")->where('kategori_id',$term_kategori)->get();
                $kategori = Kategori::orderBy('nama_kategori')->get();
                $kategori2 = Kategori::orderBy('nama_kategori')->get();
                $statuscari = $produk->count();
            }

            return view('web.landingpage_user',compact('produk','produk2','kategori','kategori2','term_kategori','statuscari','statuscari2','userlogin'));
        }

        if($term_listkategori = request('list_kategori'))
        {
            // $userlogin = Auth::user()->nama;
            $produk2 = Produk::where('kategori_id',$term_listkategori)->get();
            $statuscari2 = $produk2->count();

            return view('web.landingpage_user',compact('produk','produk2','kategori','kategori2','term_kategori','statuscari','statuscari2','userlogin'));
        }

        $userid = Auth::user()->id;
        $alamat = Auth::user()->alamat;
        $kecamatanuser = Auth::user()->kecamatan_id;
        // $namakecamatanuser = Auth::user()->kecamatan->nama_kecamatan;
        $listkecamatan = Kecamatan::orderBy('nama_kecamatan')->get();
        
        $isicart = Cart::where('user_id',$userid)->get();
        
        $besarongkir = DB::table('ongkirs')
            ->where('kecamatan_id',$kecamatanuser);
            // ->get();
            
        $jmllapak = DB::table('carts')
            ->join('produks','carts.produk_id','produks.id')
            ->join('lapaks','produks.lapak_id','lapaks.id')
            ->leftJoinSub($besarongkir, 'besarongkir', function ($join) {
                $join->on('lapaks.id', '=', 'besarongkir.lapak_id');
            })
            // ->join('ongkirs','lapaks.id','ongkirs.lapak_id')
            // ->join('users','carts.user_id','users.id')
            ->groupBy('lapaks.id')
            ->get();
        // return ($jmllapak);
        $count = $jmllapak->count();
        if($count > 1){
            $pesan = 'Transaksi akan dilakukan di '.$count.' Lapak yang berbeda, jumlah ongkos kirim akan diakumulasikan';
            $totalongkir = $jmllapak->sum('besar_ongkir');
        }else{
            $pesan = '';
            $totalongkir = '';
        }
        // return ($count);
        $totalharga = DB::table('carts')
            ->join('produks','carts.produk_id','produks.id')
            ->select(DB::raw('carts.qty*produks.harga_jual as totharga'))
            ->where('carts.user_id',$userid)
            ->get();
        
        $grandtotal = $totalharga->sum('totharga');
        
        $ongkir = DB::table('users')
            ->join('carts','users.id','carts.user_id')
            ->join('ongkirs','users.kecamatan_id','ongkirs.kecamatan_id')
            ->where('users.id',$userid)
            ->first();
        // return ($ongkir);

        return view('user.cart',compact('produk1','produk2','kategori','kategori2','term_kategori','statuscari','statuscari2','isicart','grandtotal','userlogin','ongkir','alamat','kecamatanuser','listkecamatan','pesan','jmllapak','totalongkir'));
        // return view('user.cart');
    }

    public function edit_cart(Request $request, Cart $cart)
    {

        $userlogin = Auth::user()->nama;
        $produk1 = Produk::where('status_produk','tersedia')->get();
        $produk2 = Produk::where('status_produk','tersedia')->get();
        $kategori = Kategori::orderBy('nama_kategori')->get();
        $kategori2 = Kategori::orderBy('nama_kategori')->get();
        $term_kategori = '';
        $statuscari = $produk1->count();
        $statuscari2 = $produk2->count();
        if($term = request('cari'))
        {
            $term_kategori = request('kategori');
            if($term_kategori == '')
            {
                $produk1 = Produk::where('status_produk','tersedia')->where('nama_produk','LIKE',"%{$term}%")->get();
                $produk2 = Produk::where('status_produk','tersedia')->where('nama_produk','LIKE',"%{$term}%")->get();
                $kategori = Kategori::orderBy('nama_kategori')->get();
                $kategori2 = Kategori::orderBy('nama_kategori')->get();
                $statuscari = $produk1->count();
            }else{
                $produk1 = Produk::where('status_produk','tersedia')->where('nama_produk','LIKE',"%{$term}%")->where('kategori_id',$term_kategori)->get();
                $produk2 = Produk::where('status_produk','tersedia')->where('nama_produk','LIKE',"%{$term}%")->where('kategori_id',$term_kategori)->get();
                $kategori = Kategori::orderBy('nama_kategori')->get();
                $kategori2 = Kategori::orderBy('nama_kategori')->get();
                $statuscari = $produk->count();
            }

            return view('web.landingpage_user',compact('produk','produk2','kategori','kategori2','term_kategori','statuscari','statuscari2','userlogin'));
        }

        if($term_listkategori = request('list_kategori'))
        {
            $produk2 = Produk::where('kategori_id',$term_listkategori)->get();
            $statuscari2 = $produk2->count();

            return view('web.landingpage_user',compact('produk','produk2','kategori','kategori2','term_kategori','statuscari','statuscari2','userlogin'));
        }

        $produkidx = Cart::find($cart)->first();
        // return ($idx);
        
        $metodebayar = Produk::find($produkidx->produk_id)->first();

        return view('web.edit_cart',compact('produk1','produk2','kategori','kategori2','term_kategori','statuscari','statuscari2','cart','userlogin','metodebayar'));
    }

    public function edit_keranjang(Request $request, $id)
    {
        $Idproduk = Cart::find($id);
        // return ($Idproduk);
        $stokproduk = Produk::find($Idproduk->produk_id);
        $stokawal = $stokproduk->qty + $Idproduk->qty;
        // return ($stokawal);
        if($request->kuantitas > $stokproduk->qty){
            return back()->with('Opps','Jumlah Stok tidak mencukupi');   
        }

        date_default_timezone_set('Asia/Makassar');
        $tanggal_order = date('Ymd');
        $userid = Auth::user()->id;

        $cart = Cart::find($id);

        $cart->qty              = $request->kuantitas;
        $cart->request_khusus   = $request->request_khusus;
        $cart->metode_bayar     = $request->metodebayar;
        
        $cart->save();

        // mengupdate stok produk
        

        $produk = Produk::find($Idproduk->produk_id);
        $produk->qty  = $stokawal - $request->kuantitas;

        $produk->save();

        return redirect ('/cart')->with('status', 'Produk dimasukkan dalam keranjang!');
    }

    public function hapus_cart($cart)
    {
        // ambil sisastok dulu
        $produkIdnya = Cart::find($cart);
        $Stokproduknya = Produk::find($produkIdnya->produk_id);
        // return ($produkIdnya->qty);

        // mengupdate stok produk
        $produk = Produk::find($produkIdnya->produk_id);
        $produk->qty  = $Stokproduknya->qty + $produkIdnya->qty;

        $produk->save();

        Cart::where('id', $cart)->delete();

        return redirect ('/cart')->with('hapus', 'Produk dihapus dari keranjang!');
    }

    public function order(Request $request)
    {
        $request->validate([
            'kecamatan'     => 'required',
            'alamat_kirim'  => 'required',
        ]);
        $thisday = date('Ymd');
        $userid = Auth::user()->id;
        $data_cart = Cart::where('user_id',$userid)->get();
        // return ($data_cart);
        $trans = Transaksi::where('tanggal_transaksi',$thisday)->get();
        $jumlahtrans = $trans->count();
        
        // return ($jumlahtrans);
        if($jumlahtrans < 10){
            $nourut = '00000';
        }elseif($jumlahtrans >=10 && $jumlahtrans < 100){
            $nourut = '0000';
        }elseif($jumlahtrans >=100 && $jumlahtrans < 1000){
            $nourut = '000';
        }elseif($jumlahtrans >=1000 && $jumlahtrans < 10000){
            $nourut = '00';
        }else{
            $nourut = '0';
        }

        $nolast = $jumlahtrans+1;
        $no_transaksi = 'LapakPeduli-'.$thisday.''.$userid.''.$nourut.''.$nolast;

        $nama_customer = User::find($userid);
        // return ($nama_customer->nama);
        // $event_transaksi = [
        //     'no_transaksi'  => $no_transaksi,
        //     'nama_customer' => $nama_customer->nama,
        // ];
        $arraylapak = DB::table('carts')
            ->join('produks','carts.produk_id','produks.id')
            ->join('lapaks','produks.lapak_id','lapaks.id')
            ->select('lapaks.id')
            ->where('user_id',$userid)
            // ->pluck('lapaks.id');
            ->get();
        // $count = count($arraylapak);
            // return ($arraylapak);
        // for ($i=0; $i < $count ; $i++) { 
        //     // $array = $arraylapak[i];
        //     event(new TransaksiBaruNotif(Lapak::find($arraylapak[i]),'cek status transaksimu'));
        // }
        foreach ($arraylapak as $arraylapak) {
            event(new TransaksiBaruNotif(Lapak::find($arraylapak->id),'cek status transaksimu'));
        }
        // return ($array);
        // kirim notifikasi ke pusher
        // event(new TransaksiBaruNotif($event_transaksi));
        // event(new TransaksiBaruNotif(Lapak::find($notransaksi->user_id),'cek status transaksimu'));

        foreach ($data_cart as $data_cart) {

            $transaksi = new Transaksi;
            $transaksi->no_transaksi        = $no_transaksi;
            $transaksi->tanggal_order       = $data_cart->tanggal_order;
            $transaksi->tanggal_transaksi   = $thisday;
            $transaksi->tgl_expired         = $thisday+3;
            $transaksi->user_id             = $userid;
            $transaksi->produk_id           = $data_cart->produk_id;
            $transaksi->lapak_id            = $data_cart->lapak_id;
            $transaksi->qty_produk          = $data_cart->qty;
            $transaksi->kecamatan_id        = $request->kecamatan;
            $transaksi->alamat_pengantaran  = $request->alamat_kirim;
            $transaksi->request_khusus      = $data_cart->request_khusus;
            $transaksi->metode_bayar        = $data_cart->metode_bayar;
            $transaksi->status_transaksi    = 'pending';
            
            $transaksi->save();    
        }

        DB::table('carts')->where('user_id',$userid)->truncate();
        // $cart = Cart::where('user_id',$userid);

        // $cart->delete();
        

        return redirect ('/order_status')->with('status', 'Transaksi berhasil!');
    }

    public function orderstatus()
    {
        $userlogin = Auth::user()->nama;
        $produk1 = Produk::where('status_produk','tersedia')->get();
        $produk2 = Produk::where('status_produk','tersedia')->get();
        $kategori = Kategori::orderBy('nama_kategori')->get();
        $kategori2 = Kategori::orderBy('nama_kategori')->get();
        $term_kategori = '';
        $statuscari = $produk1->count();
        $statuscari2 = $produk2->count();
        if($term = request('cari'))
        {
            $term_kategori = request('kategori');
            if($term_kategori == '')
            {
                $produk1 = Produk::where('status_produk','tersedia')->where('nama_produk','LIKE',"%{$term}%")->get();
                $produk2 = Produk::where('status_produk','tersedia')->where('nama_produk','LIKE',"%{$term}%")->get();
                $kategori = Kategori::orderBy('nama_kategori')->get();
                $kategori2 = Kategori::orderBy('nama_kategori')->get();
                $statuscari = $produk1->count();
            }else{
                $produk1 = Produk::where('status_produk','tersedia')->where('nama_produk','LIKE',"%{$term}%")->where('kategori_id',$term_kategori)->get();
                $produk2 = Produk::where('status_produk','tersedia')->where('nama_produk','LIKE',"%{$term}%")->where('kategori_id',$term_kategori)->get();
                $kategori = Kategori::orderBy('nama_kategori')->get();
                $kategori2 = Kategori::orderBy('nama_kategori')->get();
                $statuscari = $produk->count();
            }

            return view('web.landingpage_user',compact('produk','produk2','kategori','kategori2','term_kategori','statuscari','statuscari2','userlogin'));
        }

        if($term_listkategori = request('list_kategori'))
        {
            // $userlogin = Auth::user()->nama;
            $produk2 = Produk::where('kategori_id',$term_listkategori)->get();
            $statuscari2 = $produk2->count();

            return view('web.landingpage_user',compact('produk','produk2','kategori','kategori2','term_kategori','statuscari','statuscari2','userlogin'));
        }

        $userid = Auth::user()->id;
        $alamat = Auth::user()->alamat;
        $kecamatanuser = Auth::user()->kecamatan_id;
        // $namakecamatanuser = Auth::user()->kecamatan->nama_kecamatan;
        $listkecamatan = Kecamatan::orderBy('nama_kecamatan')->get();
        
        $transaksi = Transaksi::where('user_id',$userid)->orderBy('tanggal_transaksi','desc')->get();

        // untuk transaksi yang memiliki metode bayar transfer
        $transaksi_with_transfer = Transaksi::where('user_id',$userid)
            ->where('metode_bayar','transfer')
            ->where('status_transaksi','pending')
            ->get();
        $jmlcount = $transaksi_with_transfer->count();
            // return ($jmlcount);
        
        $notransaksi = Transaksi::where('user_id',$userid)
            ->groupBy('no_transaksi')    
            ->pluck('no_transaksi');
        
        
        // return ($isicart);
        $totalharga = DB::table('carts')
            ->join('produks','carts.produk_id','produks.id')
            ->select(DB::raw('carts.qty*produks.harga_jual as totharga'))
            ->where('carts.user_id',$userid)
            ->get();
        
        $grandtotal = $totalharga->sum('totharga');
        
        $ongkir = DB::table('users')
            ->join('ongkirs','users.kecamatan_id','ongkirs.kecamatan_id')
            ->where('users.id',$userid)
            ->first();

        // update data transaksi yang expired
        $hariini = date('Ymd');

        Transaksi::where('status_transaksi','pending')
            ->where('user_id',Auth::user()->id)
            ->whereDate('tgl_expired','<=',$hariini)
            ->update([
                'status_transaksi' => 'transaksi expired'
            ]);
            
        return view('user.order_status',compact('produk1','produk2','kategori','kategori2','term_kategori','statuscari','statuscari2','transaksi','grandtotal','userlogin','ongkir','alamat','kecamatanuser','listkecamatan','notransaksi','jmlcount'));
    }

    public function get_pelapak($id)
    {
        $pelapak = DB::table('transaksis')
            ->join('lapaks','transaksis.lapak_id','lapaks.id')
            ->select('transaksis.*','lapaks.id as lapak_id','lapaks.nama_lapak')
            ->where('transaksis.no_transaksi',$id)
            ->get();
        
        return $pelapak;
    }

    public function get_norek($id)
    {
        $norek = DB::table('lapaks')
            ->join('banks','lapaks.bank_id','banks.id')
            // ->select('lapaks.no_rekening','banks.nama_bank')
            ->where('lapaks.id','=',$id)
            ->first();

        if($norek){
            $result = [
                'nama_bank'     => $norek->nama_bank,
                'no_rekening'   => $norek->no_rekening
            ];
        }else{
            $result = [
                'nama_bank'     => 'Data bank belum dientry, hubungi pelapak',
                'no_rekening'   => ' '
            ];
        }
        
        
        return $result;
    }

    public function upload_transfer(Request $request)
    {
        $request->validate([
            'bukti_transfer'     => 'required',
        ]);

        event(new TransaksiBaruNotif(Lapak::find($request->id_pelapak),'cek status'));

        if($request->bukti_transfer){

            // menyimpan data file yang diupload ke variabel $file
            $file = $request->file('bukti_transfer');

            $nama_file = time()."_".$file->getClientOriginalName();
            // isi dengan nama folder tempat kemana file diupload
            $tujuan_upload = $this->pathbuktitransfer;
            $file->move($tujuan_upload,$nama_file);
        }

        // $uploadtransfer = Transaksi::find($request->no_transaksi);
        $userid = Auth::user()->id;
        Transaksi::where('no_transaksi', $request->no_transaksi)
          ->where('lapak_id', $request->id_pelapak)
          ->where('user_id', $userid)
          ->update([
              'bukti_bayar'         => $nama_file,
              'status_transaksi'    => 'tunggu verifikasi'
            ]);

        return redirect ('/order_status')->with('status', 'Upload bukti transfer berhasil!');
    }

    public function cancel($id)
    {
        $idlapak = Transaksi::where('id',$id)->first();
        // return ($idlapak);
        event(new TransaksiBaruNotif(Lapak::find($idlapak->lapak_id),'cek status transaksimu'));

        Transaksi::where('id', $id)->delete();

        return redirect ('/order_status')->with('hapus', 'Transaksi dibatalkan!');
    }

    public function get_ongkir($id, $cust)
    {
        $besarongkir = DB::table('ongkirs')
            ->where('kecamatan_id',$id);
            // ->get();
            
        $jmllapak = DB::table('carts')
            ->join('produks','carts.produk_id','produks.id')
            ->join('lapaks','produks.lapak_id','lapaks.id')
            ->leftJoinSub($besarongkir, 'besarongkir', function ($join) {
                $join->on('lapaks.id', '=', 'besarongkir.lapak_id');
            })
            ->select('lapaks.id','lapaks.nama_lapak','besarongkir.besar_ongkir')
            // ->join('ongkirs','lapaks.id','ongkirs.lapak_id')
            // ->join('users','carts.user_id','users.id')
            ->groupBy('lapaks.id')
            ->get();

        // $ongkir = DB::table('carts')
        //     ->crossJoin('ongkirs','carts.lapak_id','ongkirs.lapak_id')
        //     ->join('lapaks','carts.lapak_id','lapaks.id')
        //     ->select('lapaks.id','lapaks.nama_lapak','ongkirs.besar_ongkir')
        //     ->where('carts.user_id',$cust)
        //     ->where('ongkirs.kecamatan_id',$id)
        //     ->get();

        
        // if($ongkir){
        //     $result = [
        //         'besar_ongkir'   => $ongkir->besar_ongkir,
        //     ];
        // }else{
        //     $result = [
        //         'besar_ongkir'   => 0,
        //     ];
        // }
        
        
        return $jmllapak;
    }
}
