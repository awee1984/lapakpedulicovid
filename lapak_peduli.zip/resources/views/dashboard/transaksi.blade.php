@include('dashboard.header')
<div id="content-wrapper">
  <div class="container-fluid">
    <ol class="breadcrumb bg-dark" style="box-shadow:0px 0px 8px #0000001a;">
      <li class="breadcrumb-item">
        <a class="text-light" href="#">Transaksi</a>
      </li>
      <li class="breadcrumb-item active text-light">Daftar Transaksi</li>
    </ol>
    {{-- <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#tambahtransaksiModal">
      Tambah transaksi
    </button> --}}
    {{-- <a href="{{ url('/transaksi_tambah')}}" class="btn btn-primary btn-sm">Tambah transaksi</a> --}}
    <br><br>
    <div class="row">
      <div class="col-lg-12">
        @if (session('status'))
          <div class="alert alert-success">
              {{ session('status') }}
          </div>
        @endif
      </div>
    </div>
    <!-- DataTables Example -->
    <div class="card mb-3" style="box-shadow:0px 0px 8px #0000001a;">
      <div class="card-header">
        <i class="fas fa-barcode"></i>
        Data transaksi</div>
      <div class="card-body">
        <div class="table-responsive">
          <table class="table table-bordered" id="detail_tabel" width="100%" cellspacing="0">
            <thead>
              <tr class="text-center">
                <th width="2%">No</th>
                {{-- <th width="10%">Image Produk</th> --}}
                <th width="10%" >No Transaksi</th>
                <th >Detail Transaksi</th>
                <th width="10%">Bukti Bayar</th>
                <th width="5%">Status</th>
                <th width="15%">Opsi</th>
              </tr>
            </thead>
            <tbody>
              @php
                  $no = 1;
              @endphp
              @foreach ($transaksi as $transaksi)
              <tr>
                <td>{{ $no++ }}</td>
                <td>{{ $transaksi->no_transaksi }}</td>
                {{-- <td><img src="{{url('/')}}/assets/produk/{{$transaksi->gambar_produk}}" alt="" width="100px"> <br></td> --}}
                <td style="text-transform:capitalize">
                  <span style="font-size:10pt"> Tanggal Transaksi :</span> <strong> {{ date('d-m-Y',strtotime($transaksi->tanggal_transaksi)) }} </strong><br>
                  <span style="font-size:10pt"> Kode Customer :</span> <strong> {{ $transaksi->kode_user }} </strong><br>
                  <span style="font-size:10pt"> Nama Customer :</span> <strong>{{ $transaksi->nama }} </strong><br>
                  <span style="font-size:10pt"> No Kontak :</span> <strong>{{ $transaksi->no_kontak }} </strong><br>
                  <span style="font-size:10pt"> Alamat Pengiriman :</span><strong> {{ $transaksi->alamat_pengantaran }} {{ $transaksi->nama_kecamatan }}</strong> <br>
                  
                  <span style="font-size:10pt"> Metode Bayar : </span> <strong> {{ $transaksi->metode_bayar }} </strong><br>
                  <span style="font-size:10pt"> Besar Transaksi : </span> <strong> Rp. {{ number_format($transaksi->totharga) }},- </strong><br>
                  <span style="font-size:10pt"> Ongkos Kirim : </span> <strong> Rp. {{ number_format($transaksi->besar_ongkir) }},- </strong><br>
                  <span style="font-size:10pt"> Total Transaksi : </span> <strong> Rp. {{ number_format($transaksi->besar_ongkir +$transaksi->totharga) }},- </strong><br><br>
                  
                  <button type="button" class="btn btn-info btn-sm notrans" data-toggle="modal" data-target="#detailTransaksiModal" name="detail" id="tombol_detail_transaksi" value="{{$transaksi->no_transaksi}}">Detail</button>
                

                </td>
                <td class="text-center">
                  @if($transaksi->metode_bayar == 'transfer')
                    @if($transaksi->bukti_bayar)
                    <a target="_BLANK" href="{{ url('assets/buktitransfer/'.$transaksi->bukti_bayar) }}"><img width="100" src="{{ url('assets/buktitransfer/'.$transaksi->bukti_bayar) }}" class="img-responsive"></a> 
                    @else 
                    <span class="text-danger"> Belum ada pembayaran </span>
                    @endif
                  @else 
                  <span class="text-success"> Metode Pembayaran COD </span>
                  @endif
                </td>
                <td class="text-center" style="text-transform:capitalize">{{ $transaksi->status_transaksi }}</td>
                <td class="text-center" >
                  <a href="{{ url('/konfirmasi_orderan')}}/{{$transaksi->no_transaksi}}" class="btn btn-success  btn-sm">Konfirm</a>
                  <a href="{{ url('/cancel_orderan')}}/{{$transaksi->id}}" class="btn btn-danger  btn-sm">Cancel</a>
                  
                </td>
              </tr>    
              @endforeach
            </tbody>
          </table>
        </div>
      </div>
    </div>

    

    {{-- detail transaksi --}}
    <div class="modal fade " id="detailTransaksiModal" tabindex="-1" role="dialog" aria-labelledby="#detailTransaksiModalTitle" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="detailTransaksiModalTitle">Detail Transaksi</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <div class="row">
              <div class="col-12">
                <p>No Transaksi : <span id="labelnotransaksi"></span></p>
                <p>Nama Customer : <span id="labelnamacustomer"></span></p>
                <div class="row">
                  <div class="col-12">
                    <div class="table-responsive">
                      <table id="data_transaksi" class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                          <tr>
                            <th style="vertical-align:middle" class="text-center">Gambar Produk</th>
                            <th style="vertical-align:middle" class="text-center">Detail Produk</th>
                            <th style="vertical-align:middle" class="text-center">Harga</th>
                            <th style="vertical-align:middle" class="text-center">Kuantitas</th>
                            <th style="vertical-align:middle" class="text-center">Total</th>
                          </tr>
                        </thead>
                        <tbody id="show_data">
                        </tbody>
                        <tfoot>
                          <th colspan="4">Total</th>
                          {{-- <th class="text-right"> <span  id="total_transaksi"></span></th> --}}
                          {{-- <th> <span id="tot_kuantitas"></span></th> --}}
                          <th class="text-right"> <span id="grand_total"></span></th>
                        </tfoot>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  

  <!-- Sticky Footer -->
  <footer class="sticky-footer">
    <div class="container my-auto">
      <div class="copyright text-center my-auto">
        <span>Copyright © Lapak_Peduli_Covid19 2020</span>
      </div>
    </div>
  </footer>
</div>
@include('dashboard.footer')