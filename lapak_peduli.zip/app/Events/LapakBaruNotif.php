<?php

namespace App\Events;

use Illuminate\Broadcasting\Channel;
use Illuminate\Queue\SerializesModels;
use Illuminate\Broadcasting\PrivateChannel;
use Illuminate\Broadcasting\PresenceChannel;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Contracts\Broadcasting\ShouldBroadcast;

class LapakBaruNotif implements ShouldBroadcast
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    public $datas;

    public function __construct($datas)
    {
        $this->datas = $datas;
    }

    
    public function broadcastOn()
    {
        // return new Channel('userbaru');
        return ['lapakbaru'];
    }

    public function broadcastAs()
    {
        return 'notif_lapak';
    }
}
