<?php

/*
|--------------------------------------------------------------------------
| Broadcast Channels
|--------------------------------------------------------------------------
|
| Here you may register all of the event broadcasting channels that your
| application supports. The given channel authorization callbacks are
| used to check if an authenticated user can listen to the channel.
|
*/

Broadcast::channel('App.User.{id}', function ($user, $id) {
    return (int) $user->id === (int) $id;
});

// Broadcast::channel('global-notif', function () {
//     return true;
// });

 
// Broadcast::channel('user.{userId}', function ($user, $userId) {
//     return $user->id == $userId;
// });

Broadcast::channel('user.{userId}', function ($user, $userId) {
    return $user->id == $userId;
}, ['guards' => ['web', 'user']]);

Broadcast::channel('lapak.{lapakId}', function ($lapak, $lapakId) {
    return $lapak->id == $lapakId;
}, ['guards' => ['web', 'lapak']]);

Broadcast::channel('bukti_transfer.{lapakId}', function ($lapak, $lapakId) {
    return $lapak->id == $lapakId;
}, ['guards' => ['web', 'lapak']]);
