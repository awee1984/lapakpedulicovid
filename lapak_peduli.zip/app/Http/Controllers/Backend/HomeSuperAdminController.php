<?php

namespace App\Http\Controllers\Backend;

use App\Superadmin;
use App\User;
use App\Lapak;
use App\Produk;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use App\Mail\LapakpeduliEmail;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\DB;

class HomeSuperAdminController extends Controller
{
    public function index()
    {
        $id = Auth::user()->id;
        $lapak = Lapak::where('status','aktif')->get();
        $user = User::where('status_user','aktif')->get();
        $produk = Produk::where('status_produk','tersedia')->get();

        $jumlah_lapak = $lapak->count();
        $jumlah_user = $user->count();
        $jumlah_produk = $produk->count();
        
        return view('dashboard.superadmin',compact('id','lapak','user','jumlah_lapak','jumlah_user','jumlah_produk'));
    }

    public function lapak()
    {
        $id = Auth::user()->id;
        $lapak = Lapak::orderBy('id','desc')->get();
        // $user = User::all();
        // $produk = Produk::where('status_produk','tersedia')->get();

        $jumlah_lapak = $lapak->count();
        // $jumlah_user = $user->count();
        // $jumlah_produk = $produk->count();
        
        return view('dashboard.superadminlapak',compact('id','lapak','jumlah_lapak'));
    }

    public function user()
    {
        $id = Auth::user()->id;
        $user = User::orderBy('id','desc')->get();
        
        $jumlah_user = $user->count();
        
        return view('dashboard.superadminuser',compact('id','user','jumlah_user'));
    }

    // public function aktifkan_lapak($id)
    // {
    //     $datalapak = Lapak::where('id',$id)->first();
    //     $to_name = $datalapak->nama_owner;
    //     $to_email = $datalapak->email;
    //     $nama_lapak = $datalapak->nama_lapak;
    //     $data = array(
    //         'nama_owner'    => $datalapak->nama_owner, 
    //         'nama_lapak'    => $datalapak->nama_lapak, 
    //         'link' => 'http://localhost:8000/login_lapak/',
    //     );
            
    //     Mail::send('emaildaftar', $data, function($pesan) use ($to_name, $to_email) {
    //         $pesan->to($to_email, $to_name)->subject('Aktivasi akun');
    //         $pesan->from(env('MAIL_USERNAME','lapak.peduli.covid@gmail.com'),'Lapak Peduli Covid19');
    //     });
        
    //     // Mail::to($emaillapak->email)->send(new LapakpeduliEmail());

    //     $lapak = Lapak::find($id);

    //     $lapak->status  = 'aktif';
        
    //     $lapak->save();

    //     return redirect ('/superadmin_home')->with('status', 'Update status berhasil!');
    // }

    public function nonaktifkan_lapak($id)
    {
        $datalapak = Lapak::where('id',$id)->first();
        // return ($emaillapak->email);
        $to_name = $datalapak->nama_owner;
        $to_email = $datalapak->email;
        $nama_lapak = $datalapak->nama_lapak;
        $data = array(
            'nama_owner'    => $datalapak->nama_owner, 
            'nama_lapak'    => $datalapak->nama_lapak, 
            // 'link' => 'http://localhost:8000/login_lapak/',
        );
            
        Mail::send('emailblokir', $data, function($pesan) use ($to_name, $to_email) {
            $pesan->to($to_email, $to_name)->subject('Penonaktifan akun');
            $pesan->from(env('MAIL_USERNAME','lapak.peduli.covid@gmail.com'),'Lapak Peduli Covid19');
        });
        
        // Mail::to($emaillapak->email)->send(new LapakpeduliEmail());

        $lapak = Lapak::find($id);

        $lapak->status  = 'menunggu aktivasi';
        
        $lapak->save();

        return redirect ('/superadmin_home')->with('status', 'Update status berhasil!');
    }

    // public function aktifkan_user($id)
    // {
    //     $datauser = User::where('id',$id)->first();
    //     $to_name = $datauser->nama;
    //     $to_email = $datauser->email;
    //     $data = array(
    //         'nama'    => $datauser->nama, 
    //         'link' => 'http://localhost:8000/login_user/',
    //     );
            
    //     Mail::send('emailuserdaftar', $data, function($pesan) use ($to_name, $to_email) {
    //         $pesan->to($to_email, $to_name)->subject('Aktivasi akun');
    //         $pesan->from(env('MAIL_USERNAME','lapak.peduli.covid@gmail.com'),'Lapak Peduli Covid19');
    //     });
        
        
    //     $user = User::find($id);

    //     $user->status_user  = 'aktif';
        
    //     $user->save();

    //     // $superadmin = Superadmin::first();
    //     // $superadmin->unreadNotifications->markAsRead();

    //     return redirect ('/superadmin_home')->with('status', 'Update status berhasil!');
    // }

    public function nonaktifkan_user($id)
    {
        $datauser = Lapak::where('id',$id)->first();
        // return ($emaillapak->email);
        $to_name = $datauser->nama;
        $to_email = $datauser->email;
        $data = array(
            'nama'    => $datauser->nama, 
            // 'link' => 'http://localhost:8000/login_lapak/',
        );
            
        Mail::send('emailuserblokir', $data, function($pesan) use ($to_name, $to_email) {
            $pesan->to($to_email, $to_name)->subject('Penonaktifan akun');
            $pesan->from(env('MAIL_USERNAME','lapak.peduli.covid@gmail.com'),'Lapak Peduli Covid19');
        });
        
        // Mail::to($emaillapak->email)->send(new LapakpeduliEmail());

        $user = User::find($id);

        $user->status_user  = 'menunggu aktivasi';
        
        $user->save();

        return redirect ('/superadmin_home')->with('status', 'Update status berhasil!');
    }

}
