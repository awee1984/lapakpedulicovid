@include('web.header')


	<div class="product-area most-popular section" style="padding-bottom:30px;">
    <div class="container" style="margin-top:50px;margin-bottom:30px;">
      <div class="row">
				<div class="col-12">
					<div class="section-title">
						<h2>PRODUK UNTUKMU</h2>
					</div>
				</div>
			</div>
			@if($statuscari == 0)
			<div class="row">
        <div class="col-12">
					<div class="alert alert-warning text-center" role="alert">
						Maaf, produk yang kamu cari tidak ada
					</div>
				</div>
			</div>
			@endif
      <div class="row" style="padding-top:20px;">
        <div class="col-12">
          <div class="owl-carousel popular-slider">
						@foreach ($produk1 as $produk1)
						<div class="single-product">
							<div class="product-img">
								<a href="{{url('/lihat_produk')}}/{{$produk1->id}}">
									<img class="default-img" src="{{url('/')}}/assets/produk/{{$produk1->gambar_produk}}" alt="#" style="height:300px;width:255px">
									<img class="hover-img" src="{{url('/')}}/assets/produk/{{$produk1->gambar_produk}}" alt="#" style="height:300px;width:255px"">
									{{-- <span class="out-of-stock">Hot</span> --}}
								</a>
								<div class="button-head">
									<div class="product-action-2">
										<a title="Masukkan ke dalam keranjang" href="{{url('/lihat_produk')}}/{{$produk1->id}}">Add to Cart</a>
									</div>
								</div>
							</div>
							<div class="product-content">
								<p>{{$produk1->nama_produk}}</p>
								<div class="product-price">
									<span>Rp. {{ number_format($produk1->harga_jual)}},-</span>
								</div>
							</div>
            </div>		
						@endforeach 
					</div>
				</div>
      </div>
    </div>
	</div>
	
  <section class="product-area shop-sidebar shop section" style="padding-top:5px;padding-bottom:30px;">
    <div class="container">
      <div class="row">
        <div class="col-lg-12  col-12">
          <div class="shop-sidebar">
            <div class="single-widget category">
              <h3 class="title text-center">Kategori</h3>
              <div class="nav-main">
								<form action="{{ route('landingpage_user')}}">
									<div class="row">
										<div class="col-12 text-center">
											<button  type="submit" class="btn btn-default btn-sm btn-kat" name="all_kategori" >Semua Kategori</button>
										</div>
										
									</div>
									
									<ul class="nav nav-tabs" id="myTab" role="tablist">
										@foreach ($kategori2 as $kategori2)
										<li class="nav-item" style="margin-top:5px">
											<button type="submit" class="btn btn-default btn-sm btn-kat" name="list_kategori" value="{{$kategori2->id}}">{{$kategori2->nama_kategori}}</button>
										</li>
										@endforeach
									</ul>
								</form>
							</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
	
	<section class="shop-home-list section">
		<div class="container">
			<div class="row">
				
				@if($statuscari == 0)
				<div class="col-12">
					<div class="alert alert-warning text-center" role="alert">
						Maaf, produk yang kamu cari tidak ada
					</div>
				</div>
				@endif

				@if($statuscari2 == 0)
				<div class="col-12">
					<div class="alert alert-warning text-center" role="alert">
						Maaf, produk yang kamu cari tidak ada
					</div>
				</div>
				@endif
				
				@foreach ($produk2 as $produk2)
				<div class="col-6 col-md-2">
					<div class="single-list">
						<div class="row">
							<div class="col-12 col-md-12">
								<div class="list-image overlay">
									<img src="{{url('/')}}/assets/produk/{{$produk2->gambar_produk}}" alt="#" style="max-height:180px;min-height:180px;">
									<a href="{{url('/lihat_produk')}}/{{$produk2->id}}" class="buy"><i class="fa fa-shopping-cart"></i></a>
                  <div class="content" style="padding-top:5px;padding-left:0px;padding-right:0px;">
                    <p class="title" style="font-size:10pt"><strong>{{$produk2->nama_produk}}</strong></p>
                    <p >{{$produk2->lapak->nama_lapak}}</p>
                    <p class="price with-discount text-center" style="padding-top:5px;display:block;">Rp. {{number_format($produk2->harga_jual)}},-</p>
                  </div>
								</div>		
							</div>
						</div>
					</div>
        </div>
				@endforeach
			</div>
		</div>
	</section>
	

	

  <!-- End Shop Home List  -->
	
@include('web.footer')