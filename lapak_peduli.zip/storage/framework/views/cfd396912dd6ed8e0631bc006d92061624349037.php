<?php echo $__env->make('dashboard.superadminheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="row">
  <div class="col-lg-12">
    <?php if(session('status')): ?>
      <div class="alert alert-success">
          <?php echo e(session('status')); ?>

      </div>
    <?php endif; ?>
  </div>
</div>

<div class="card mb-3" style="box-shadow:0px 0px 8px #0000001a;">
  <div class="card-header">
    <i class="fas fa-barcode"></i>
    Data lapak</div>
  <div class="card-body">
    <div class="table-responsive">
      <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
        <thead>
          <tr class="text-center">
            <th>No</th>
            <th>Nama Lapak</th>
            <th>Nama Owner</th>
            <th>Email</th>
            <th>Alamat</th>
            <th>No Handphone</th>
            <th>Status</th>
            <th width="8%">Opsi</th>
          </tr>
        </thead>
        <tbody>
          <?php
              $no = 1;
          ?>
          <?php $__currentLoopData = $lapak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lapak): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($no++); ?></td>
            <td style="text-transform:capitalize"><?php echo e($lapak->nama_lapak); ?> </td>
            <td class="text-center"><?php echo e($lapak->nama_owner); ?></td>
            <td class="text-center"><?php echo e($lapak->email); ?></td>
            <td class="text-center"><?php echo e($lapak->alamat); ?></td>
            <td class="text-center"><?php echo e($lapak->no_kontak); ?></td>
            <td class="text-center" style="text-transform:capitalize"><?php echo e($lapak->status); ?></td>
            <td class="text-center" >
              <a href="<?php echo e(url('/nonaktifkan_lapak')); ?>/<?php echo e($lapak->id); ?>" class="btn btn-danger btn-sm">Non Aktifkan</a>
            </td>
          </tr>    
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<?php echo $__env->make('dashboard.superadminfooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lapak_peduli\lapak_peduli\resources\views/dashboard/superadminlapak.blade.php ENDPATH**/ ?>