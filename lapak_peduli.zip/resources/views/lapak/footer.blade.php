  <!-- Start Footer Area -->
  {{-- <footer class="footer">
    <div class="copyright">
      <div class="container">
        <div class="inner">
          <div class="row">
            <div class="col-lg-6 col-12">
              <div class="left">
                <p>Copyright © 2020 Komunitas Peduli Covid  -  All Rights Reserved.</p>
              </div>
            </div>
          </div>
        </div>
      </div>  
    </div>
  </footer> --}}
  <!-- /End Footer Area -->

  <!-- Jquery -->
  <script src="{{url('/')}}/assets/js/jquery.min.js"></script>
  <script src="{{url('/')}}/assets/js/jquery-migrate-3.0.0.js"></script>
  <script src="{{url('/')}}/assets/js/jquery-ui.min.js"></script>
  <!-- Popper JS -->
  <script src="{{url('/')}}/assets/js/popper.min.js"></script>
  <!-- Bootstrap JS -->
  <script src="{{url('/')}}/assets/js/bootstrap.min.js"></script>
  <!-- Color JS -->
  <script src="{{url('/')}}/assets/js/colors.js"></script>
  <!-- Slicknav JS -->
  <script src="{{url('/')}}/assets/js/slicknav.min.js"></script>
  <!-- Owl Carousel JS -->
  <script src="{{url('/')}}/assets/js/owl-carousel.js"></script>
  <!-- Magnific Popup JS -->
  <script src="{{url('/')}}/assets/js/magnific-popup.js"></script>
  <!-- Waypoints JS -->
  <script src="{{url('/')}}/assets/js/waypoints.min.js"></script>
  <!-- Countdown JS -->
  <script src="{{url('/')}}/assets/js/finalcountdown.min.js"></script>
  <!-- Nice Select JS -->
  <script src="{{url('/')}}/assets/js/nicesellect.js"></script>
  <!-- Flex Slider JS -->
  <script src="{{url('/')}}/assets/js/flex-slider.js"></script>
  <!-- ScrollUp JS -->
  <script src="{{url('/')}}/assets/js/scrollup.js"></script>
  <!-- Onepage Nav JS -->
  <script src="{{url('/')}}/assets/js/onepage-nav.min.js"></script>
  <!-- Easing JS -->
  <script src="{{url('/')}}/assets/js/easing.js"></script>
  <!-- Active JS -->
  <script src="{{url('/')}}/assets/js/active.js"></script>
  <script src="{{url('/')}}/assets/myscript.js"></script>

  @include('sweetalert::alert')
</body>
</html>