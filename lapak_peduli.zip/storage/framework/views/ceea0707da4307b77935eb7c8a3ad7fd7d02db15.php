<?php echo $__env->make('web.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="contact-us section">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-lg-10 col-12">
        <div class="form-main" style="background-color:white;margin-top:50px;">
          <div class="title">
            <h5>Detail Produk</h5>
          </div>
          <form class="form" action="<?php echo e(url('/to_cart_edit')); ?>/<?php echo e($cart->id); ?>" method="post" enctype="multipart/form-data">
          <?php echo method_field('patch'); ?>
          <?php echo csrf_field(); ?>
            <div class="row">
              <div class="col-lg-4 col-12">
                <img src="<?php echo e(url('/')); ?>/assets/produk/<?php echo e($cart->produk->gambar_produk); ?>" alt="#" width="300">  	
              </div>
              <div class="col-lg-8 col-12">
                <h6 style="margin-top:10px;">Kode Produk : <?php echo e($cart->produk->kode_produk); ?></h6>
                <h5 style="margin-top:10px;" class="text-danger">Rp. <?php echo e(number_format($cart->produk->harga_jual)); ?>,-</h5>
                <p  style="text-transform:capitalize;margin-top:10px"><?php echo e($cart->produk->deskripsi_produk); ?></p>
                <div class="row" style="margin-top:10px;">
                  <div class="col-lg-3 col-4">
                    <p class="mb-2">Kuantitas</p>
                    <div class="input-group">
                      <div class="input-group-prepend"  >
                        <button class="btn btn-outline-secondary text-center" type="button" id="tombol_kurang"  style="width:30px;height:30px;padding:0px;color:#000" >-</button>
                      </div>
                      <input type="text" min="1" class="form-control text-center" placeholder="1"  style="width:30px;height:30px;padding:0px;background-color:white" value="<?php echo e($cart->qty); ?>" id="kuantitas" name="kuantitas" readonly>
                      
                      <div class="input-group-append">
                        <button class="btn btn-outline-secondary"  type="button" id="tombol_tambah" style="width:30px;height:30px;padding:0px;color:#000">+</button>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="row" style="margin-top:10px;">
                  <div class="col-lg-12">
                    <?php if(session('Opps')): ?>
                      <div class="alert alert-danger">
                          <?php echo e(session('Opps')); ?>

                      </div>
                    <?php endif; ?>
                    <p  style="text-transform:capitalize;margin-top:10px" >Jumlah Stok tersedia <span id="sisastok"><?php echo e($cart->produk->qty); ?></span> </p>
                    
                  </div>
                </div>
              
                <div class="row" style="margin-top:10px;">
                  <div class="col-lg-12">
                    <p class="mb-2">Request khusus</p>
                    <textarea name="request_khusus" id="request"  rows="2"><?php echo e($cart->produk->request_khusus); ?></textarea>
                  </div>
                </div>

                <div class="row" style="margin-top:10px;">
                  <div class="col-lg-12">
                    <p class="mb-2">Pilih metode pembayaran</p>
                    <?php if($metodebayar->metode_bayar == 0): ?>
                    <div class="form-check form-check-inline" style="margin-left:20px;">
                      <input class="form-check-input" type="radio" name="metodebayar" id="inlineRadio1" value="transfer" checked>
                      <label class="form-check-label" for="inlineRadio1">Transfer</label>
                    </div>
                    <?php else: ?> 
                    <div class="form-check form-check-inline" style="margin-left:20px;">
                      <input class="form-check-input" type="radio" name="metodebayar" id="inlineRadio1" value="transfer" checked>
                      <label class="form-check-label" for="inlineRadio1">Transfer</label>
                    </div>
                    <div class="form-check form-check-inline"  style="margin-left:20px;">
                      <input class="form-check-input" type="radio" name="metodebayar" id="inlineRadio2" value="cod">
                      <label class="form-check-label" for="inlineRadio2">COD</label>
                    </div>
                    <?php endif; ?>
                  </div>
                </div>
                
                <div class="row" style="margin-top:10px;">
                  <div class="col-lg-12">
                    <button type="submit" class="btn btn-warning btn-sm"><i class="fa fa-cart-plus fa-fw"></i>Masukkan ke Cart Belanja</button>
                  </div>
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>

<?php echo $__env->make('web.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lapak_peduli\lapak_peduli\resources\views/web/edit_cart.blade.php ENDPATH**/ ?>