@include('dashboard.header')
<div id="content-wrapper">
  <div class="container-fluid">
    <ol class="breadcrumb bg-dark" style="box-shadow:0px 0px 8px #0000001a;">
      <li class="breadcrumb-item">
        <a class="text-light" href="#">Ongkos Kirim</a>
      </li>
      <li class="breadcrumb-item active text-light">List ongkos kirim</li>
    </ol>
    <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#tambahongkirModal">
      Tambah Ongkos Kirim
    </button>
    {{-- <a href="{{ url('/produk_tambah')}}" class="btn btn-primary btn-sm">Tambah Produk</a> --}}
    <br><br>
    <div class="row">
      <div class="col-lg-12">
        @if (session('status'))
          <div class="alert alert-success">
              {{ session('status') }}
          </div>
        @endif
      </div>
    </div>
    <div class="alert alert-primary alert-dismissible fade show" role="alert">
      Tidak perlu dientry jika ongkos kirim dibayarkan pada saat pengantaran barang, ongkos kirim tidak akan diakumulasikan dengan total belanja produk
      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
      </button>
    </div>
    <!-- DataTables Example -->
    <div class="card mb-3" style="box-shadow:0px 0px 8px #0000001a;">
      <div class="card-header">
        <i class="fas fa-barcode"></i>
        Data Ongkos Kirim</div>
      <div class="card-body">
        <div class="table-responsive">
          <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
            <thead>
              <tr class="text-center">
                <th>No</th>
                <th>Ke Kecamatan</th>
                <th>Besaran Ongkos Kirim</th>
                <th width="7%">Opsi</th>
              </tr>
            </thead>
            <tbody>
              @php
                  $no = 1;
              @endphp
              @foreach ($ongkir as $ongkir)
              <tr>
                <td>{{ $no++ }}</td>
                <td style="text-transform:capitalize">{{ $ongkir->kecamatan->nama_kecamatan }}</td>
                <td class="text-right">{{ number_format($ongkir->besar_ongkir) }}</td>
                <td class="text-center" >
                  <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#editongkirModal" data-id="{{ $ongkir->id }}" data-kecamatan_id="{{ $ongkir->kecamatan_id }}" data-besar_ongkir="{{ $ongkir->besar_ongkir }}">Edit</button>
                </td>
              </tr>    
              @endforeach
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- tambah produk Modal -->
    <div class="modal fade " id="tambahongkirModal" tabindex="-1" role="dialog" aria-labelledby="#tambahongkirModalTitle" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="tambahongkirModalTitle">Tambah Ongkos Kirim</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <form action="{{ url('/ongkir_tambah') }}" method="post" enctype="multipart/form-data">
            @csrf
            <div class="modal-body">
              <div class="row">
                <div class="col-12">
                  <div class="form-group">
                    <select name="kecamatan_id" class="form-control" style="text-transform:capitalize">
                      <option value="">-- Pilih Kecamatan --</option>    
                      @foreach ($kecamatan as $kecamatan)
                      <option style="text-transform:capitalize" value="{{$kecamatan->id}}">{{$kecamatan->nama_kecamatan}}</option>    
                      @endforeach
                    </select>
                    @error('kecamatan_id')
                    <span class="help-block text-danger">Wajib diisi</span>
                    @enderror
                  </div>
                  <div class="form-group">
                    <input type="number" name="besar_ongkir" class="form-control" placeholder="Besaran ongkos kirim" value="{{ old('besar_ongkir')}}">
                    @error('besar_ongkir')
                    <span class="help-block text-danger">Wajib diisi</span>
                    @enderror
                    
                  </div>
                </div>
              </div>
            </div>
            <div class="modal-footer">
              <button type="submit" class="btn btn-success btn-sm">Simpan</button>
            </div>
          </form>
        </div>
      </div>
    </div>

    <!-- edit produk Modal -->
    <div class="modal fade " id="editongkirModal" tabindex="-1" role="dialog" aria-labelledby="#editongkirModalTitle" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="editongkirModalTitle">Edit Ongkos Kirim</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <form action="{{ url('/ongkir_update') }}" method="post" enctype="multipart/form-data">
            {{-- @method('patch') --}}
            @csrf
            <div class="modal-body">
              <div class="row">
                <div class="col-12">
                  <div class="form-group">
                    <input type="hidden" name="ongkir_id" id="ongkir_id" value="">
                    <select name="kecamatan_id_edit" id="kecamatan" class="form-control" style="text-transform:capitalize" >
                      <option value="">-- Pilih Kecamatan --</option>    
                      @foreach ($kecamatan2 as $kecamatan2)
                      <option style="text-transform:capitalize" value="{{$kecamatan2->id}}">{{$kecamatan2->nama_kecamatan}}</option>    
                      @endforeach
                    </select>
                    @error('kecamatan_id_edit')
                    <span class="help-block text-danger">Wajib diisi</span>
                    @enderror
                  </div>
                  <div class="form-group">
                    <input type="number" name="besar_ongkir_edit" id="besar_ongkir" class="form-control" placeholder="Besar Ongkos kirim" >
                    @error('besar_ongkir_edit')
                    <span class="help-block text-danger">Wajib diisi</span>
                    @enderror
                  </div>
                </div>
              </div>
            </div>
            <div class="modal-footer">
              <button type="submit" class="btn btn-success btn-sm">Simpan</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>

  

  <!-- Sticky Footer -->
  <footer class="sticky-footer">
    <div class="container my-auto">
      <div class="copyright text-center my-auto">
        <span>Copyright © Lapak_Peduli_Covid19 2020</span>
      </div>
    </div>
  </footer>
</div>
@include('dashboard.footer')