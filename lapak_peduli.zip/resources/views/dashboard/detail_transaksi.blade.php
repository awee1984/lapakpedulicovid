<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
   <h4 class="modal-title">Daftar Kabupaten</h4>
</div>
<div class="modal-body">
  
      <table class="table table-striped table-bordered small">
          <tr>
              <th>NO</th>
              <th>KODE</th>
              <th>NAMA PROVINSI</th>
          </tr>
          
      </table>

</div>
<div class="modal-footer">
  <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-close"></i> Tutup</button>
</div>