@include('dashboard.superadminheader')
<div class="row">
  <div class="col-lg-12">
    @if (session('status'))
      <div class="alert alert-success">
          {{ session('status') }}
      </div>
    @endif
  </div>
</div>

<div class="card mb-3" style="box-shadow:0px 0px 8px #0000001a;">
  <div class="card-header">
    <i class="fas fa-barcode"></i>
    Data lapak</div>
  <div class="card-body">
    <div class="table-responsive">
      <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
        <thead>
          <tr class="text-center">
            <th>No</th>
            <th>Nama Lapak</th>
            <th>Nama Owner</th>
            <th>Email</th>
            <th>Alamat</th>
            <th>No Handphone</th>
            <th>Status</th>
            <th width="8%">Opsi</th>
          </tr>
        </thead>
        <tbody>
          @php
              $no = 1;
          @endphp
          @foreach ($lapak as $lapak)
          <tr>
            <td>{{ $no++ }}</td>
            <td style="text-transform:capitalize">{{ $lapak->nama_lapak }} </td>
            <td class="text-center">{{ $lapak->nama_owner }}</td>
            <td class="text-center">{{ $lapak->email }}</td>
            <td class="text-center">{{ $lapak->alamat }}</td>
            <td class="text-center">{{ $lapak->no_kontak }}</td>
            <td class="text-center" style="text-transform:capitalize">{{ $lapak->status }}</td>
            <td class="text-center" >
              <a href="{{url('/nonaktifkan_lapak')}}/{{$lapak->id}}" class="btn btn-danger btn-sm">Non Aktifkan</a>
            </td>
          </tr>    
          @endforeach
        </tbody>
      </table>
    </div>
  </div>
</div>

@include('dashboard.superadminfooter')