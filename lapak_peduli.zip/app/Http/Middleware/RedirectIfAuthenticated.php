<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\Auth;

class RedirectIfAuthenticated
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @param  string|null  $guard
     * @return mixed
     */
    public function handle($request, Closure $next, $guard = null)
    {
        if($guard == 'lapak'){
            if (Auth::guard($guard)->check()) {
                return redirect('/lapak_home');
            }
        }else{
            if (Auth::guard($guard)->check()) {
                return redirect('/');
            }
        }

        if($guard == 'user'){
            if (Auth::guard($guard)->check()) {
                return redirect('/landingpage_user');
            }
        }else{
            if (Auth::guard($guard)->check()) {
                return redirect('/');
            }
        }
        

        return $next($request);
    }
}
