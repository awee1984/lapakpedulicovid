<?php echo $__env->make('member.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body class="login_background js">
	
	<!-- Preloader -->
	<div class="preloader">
		<div class="preloader-inner">
			<div class="preloader-icon">
				<span></span>
				<span></span>
			</div>
		</div>
	</div>
	<!-- End Preloader -->
	
	
	<!-- Header -->
	<header class="header shop" style="background:#ef0000">
		<div class="middle-inner" style="background:#ef0000">
			<div class="container">
				<div class="row row justify-content-between">
					<div class="col-lg-2 col-md-2 col-12">
						<div class="logo">
							<a href="index.html"><img src="<?php echo e(url('/')); ?>/assets/images/lapakpeduli.png" alt="logo" width="200px"></a>
            </div>
          </div>
          <div class="col-lg-10 col-md-3 col-12" >
            <ul class="nav justify-content-end">
              <li class="nav-item">
                <p style="color:white">Belum punya akun? <a style="display:inline" href="<?php echo e(url('/daftar_lapak')); ?>">Daftar disini</a></p>
                 
              </li>
            </ul>
          </div>
				</div>
			</div>
		</div>
	</header>
  <!--/ End Header -->
  

  <!-- content -->
  <div class="contact-us section">
    <div class="container">
      <div class="row justify-content-end">
        <div class="col-6">
          <div class="form-main" style="background-color:white;margin-top:50px;">
            <div class="title text-center">
              <h5>Masuk ke akun kamu</h5>
            </div>
            <form class="form" method="post" action="mail/mail.php">
              <div class="row">
                <div class="col-lg-12 col-12">
                  <div class="form-group">
                    <label style="font-size:10pt">Email<span>*</span></label>
                    <input style="font-size:10pt" name="email" type="email" placeholder="Masukan email">
                  </div>	
                </div>
                <div class="col-lg-12 col-12">
                  <div class="form-group">
                    <label style="font-size:10pt">Password<span>*</span></label>
                    <input style="font-size:10pt" name="password" type="password" placeholder="Masukan kata sandi">
                  </div>	
                </div>
                <div class="col-lg-12 col-12">
                  <div class="form-group">
                    <button type="submit" class="btn btn-block btn-info btn-md">Masuk</button>
                  </div>	
                </div>
                
                
                
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- end content -->
  
<?php echo $__env->make('member.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php /**PATH C:\xampp\htdocs\lapak_peduli\lapak_peduli\resources\views/member/login.blade.php ENDPATH**/ ?>