<?php echo $__env->make('dashboard.superadminheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="card mb-3" style="box-shadow:0px 0px 8px #0000001a;">
  <div class="card-header">
    <i class="fas fa-barcode"></i>
    Data User</div>
  <div class="card-body">
    <div class="table-responsive">
      <table class="table table-bordered" id="dataTable2" width="100%" cellspacing="0">
        <thead>
          <tr class="text-center">
            <th>No</th>
            <th>Nama User</th>
            <th>Alamat</th>
            <th>No Handphone</th>
            <th>PIN</th>
            <th>Konfirmasi PIN</th>
            
            <th>Status</th>
            <th width="8%">Opsi</th>
          </tr>
        </thead>
        <tbody>
          <?php
              $no = 1;
          ?>
          <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($no++); ?></td>
            <td style="text-transform:capitalize"><?php echo e($user->nama); ?> </td>
            <td class="text-center"><?php echo e($user->alamat); ?></td>
            <td class="text-center"><?php echo e($user->no_kontak); ?></td>
            <td class="text-center"><?php echo e($user->pin); ?></td>
            <td class="text-center"><?php echo e($user->konfirm_pin); ?></td>
            
            <td class="text-center" style="text-transform:capitalize"><?php echo e($user->status_user); ?></td>
            <td class="text-center" >
              <a href="<?php echo e(url('/nonaktifkan_user')); ?>/<?php echo e($user->id); ?>" class="btn btn-danger btn-sm">Non Aktifkan</a>
            </td>
          </tr>    
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<?php echo $__env->make('dashboard.superadminfooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lapak_peduli\lapak_peduli\resources\views/dashboard/superadminuser.blade.php ENDPATH**/ ?>