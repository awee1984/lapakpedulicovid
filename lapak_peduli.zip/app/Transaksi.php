<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Transaksi extends Model
{
    protected $table = 'transaksis';

    public function produk()
    {
    	return $this->belongsTo('App\Produk');
    }

    public function lapak()
    {
    	return $this->belongsTo('App\Lapak');
    }

    public function user()
    {
    	return $this->belongsTo('App\User');
    }
}
