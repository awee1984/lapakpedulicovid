<?php echo $__env->make('dashboard.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div id="content-wrapper">
  <div class="container-fluid">
    <ol class="breadcrumb bg-dark" style="box-shadow:0px 0px 8px #0000001a;">
      <li class="breadcrumb-item">
        <a class="text-light" href="#">Produk</a>
      </li>
      <li class="breadcrumb-item active text-light">Tambah Produk</li>
    </ol>
    <a href="<?php echo e(url('/lapak_produk')); ?>" class="btn btn-primary btn-sm">Kembali</a>
    <br><br>
    <!-- DataTables Example -->
    <div class="card mb-3" style="box-shadow:0px 0px 8px #0000001a;">
      <div class="card-header">
        <i class="fas fa-plus"></i>
        Tambah Produk</div>
      <div class="card-body">
        
      </div>
    </div>
  </div>
  <!-- Sticky Footer -->
  <footer class="sticky-footer">
    <div class="container my-auto">
      <div class="copyright text-center my-auto">
        <span>Copyright © Lapak_Peduli_Covid19 2020</span>
      </div>
    </div>
  </footer>
</div>
<?php echo $__env->make('dashboard.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lapak_peduli\lapak_peduli\resources\views/dashboard/produk_tambah.blade.php ENDPATH**/ ?>