@include('web.header')

<div class="contact-us section">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-lg-10 col-12">
        <div class="form-main" style="background-color:white;margin-top:50px;">
          <div class="title">
            <h5>Detail Produk</h5>
          </div>
          <form class="form" action="{{ url('/to_cart_edit')}}/{{$cart->id}}" method="post" enctype="multipart/form-data">
          @method('patch')
          @csrf
            <div class="row">
              <div class="col-lg-4 col-12">
                <img src="{{url('/')}}/assets/produk/{{$cart->produk->gambar_produk}}" alt="#" width="300">  	
              </div>
              <div class="col-lg-8 col-12">
                <h6 style="margin-top:10px;">Kode Produk : {{$cart->produk->kode_produk}}</h6>
                <h5 style="margin-top:10px;" class="text-danger">Rp. {{number_format($cart->produk->harga_jual)}},-</h5>
                <p  style="text-transform:capitalize;margin-top:10px">{{$cart->produk->deskripsi_produk}}</p>
                <div class="row" style="margin-top:10px;">
                  <div class="col-lg-3 col-4">
                    <p class="mb-2">Kuantitas</p>
                    <div class="input-group">
                      <div class="input-group-prepend"  >
                        <button class="btn btn-outline-secondary text-center" type="button" id="tombol_kurang"  style="width:30px;height:30px;padding:0px;color:#000" >-</button>
                      </div>
                      <input type="text" min="1" class="form-control text-center" placeholder="1"  style="width:30px;height:30px;padding:0px;background-color:white" value="{{$cart->qty}}" id="kuantitas" name="kuantitas" readonly>
                      
                      <div class="input-group-append">
                        <button class="btn btn-outline-secondary"  type="button" id="tombol_tambah" style="width:30px;height:30px;padding:0px;color:#000">+</button>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="row" style="margin-top:10px;">
                  <div class="col-lg-12">
                    @if (session('Opps'))
                      <div class="alert alert-danger">
                          {{ session('Opps') }}
                      </div>
                    @endif
                    <p  style="text-transform:capitalize;margin-top:10px" >Jumlah Stok tersedia <span id="sisastok">{{$cart->produk->qty}}</span> </p>
                    {{-- <p  style="text-transform:capitalize;margin-top:10px">Jumlah Stok tersedia {{$cart->produk->qty}}</p> --}}
                  </div>
                </div>
              
                <div class="row" style="margin-top:10px;">
                  <div class="col-lg-12">
                    <p class="mb-2">Request khusus</p>
                    <textarea name="request_khusus" id="request"  rows="2">{{$cart->produk->request_khusus}}</textarea>
                  </div>
                </div>

                <div class="row" style="margin-top:10px;">
                  <div class="col-lg-12">
                    <p class="mb-2">Pilih metode pembayaran</p>
                    @if($metodebayar->metode_bayar == 0)
                    <div class="form-check form-check-inline" style="margin-left:20px;">
                      <input class="form-check-input" type="radio" name="metodebayar" id="inlineRadio1" value="transfer" checked>
                      <label class="form-check-label" for="inlineRadio1">Transfer</label>
                    </div>
                    @else 
                    <div class="form-check form-check-inline" style="margin-left:20px;">
                      <input class="form-check-input" type="radio" name="metodebayar" id="inlineRadio1" value="transfer" checked>
                      <label class="form-check-label" for="inlineRadio1">Transfer</label>
                    </div>
                    <div class="form-check form-check-inline"  style="margin-left:20px;">
                      <input class="form-check-input" type="radio" name="metodebayar" id="inlineRadio2" value="cod">
                      <label class="form-check-label" for="inlineRadio2">COD</label>
                    </div>
                    @endif
                  </div>
                </div>
                
                <div class="row" style="margin-top:10px;">
                  <div class="col-lg-12">
                    <button type="submit" class="btn btn-warning btn-sm"><i class="fa fa-cart-plus fa-fw"></i>Masukkan ke Cart Belanja</button>
                  </div>
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>

@include('web.footer')