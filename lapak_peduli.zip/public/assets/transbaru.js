$(document).ready(function () {
    Echo.private(`lapak.{{Auth::id()}}`)
        // .listen('StatustransNotif', (e) => {
        .listen('TransaksiBaruNotif', (e) => {
            console.log(e);
            // $("#notif_status_order").show();
            $("#transnotif").text("*");
            $("#transnotif1").text("*");
            // $("#notransnya").text("" + notrans + "");
        });
});
