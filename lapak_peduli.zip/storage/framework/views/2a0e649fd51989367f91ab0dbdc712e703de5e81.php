<?php echo $__env->make('dashboard.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div id="content-wrapper">
  <div class="container-fluid">
    <ol class="breadcrumb bg-dark" style="box-shadow:0px 0px 8px #0000001a;">
      <li class="breadcrumb-item">
        <a class="text-light" href="#">Transaksi</a>
      </li>
      <li class="breadcrumb-item active text-light">Daftar Transaksi</li>
    </ol>
    
    
    <br><br>
    <div class="row">
      <div class="col-lg-12">
        <?php if(session('status')): ?>
          <div class="alert alert-success">
              <?php echo e(session('status')); ?>

          </div>
        <?php endif; ?>
      </div>
    </div>
    <!-- DataTables Example -->
    <div class="card mb-3" style="box-shadow:0px 0px 8px #0000001a;">
      <div class="card-header">
        <i class="fas fa-barcode"></i>
        Data transaksi</div>
      <div class="card-body">
        <div class="table-responsive">
          <table class="table table-bordered" id="detail_tabel" width="100%" cellspacing="0">
            <thead>
              <tr class="text-center">
                <th width="2%">No</th>
                
                <th width="10%" >No Transaksi</th>
                <th >Detail Transaksi</th>
                <th width="10%">Bukti Bayar</th>
                <th width="5%">Status</th>
                <th width="15%">Opsi</th>
              </tr>
            </thead>
            <tbody>
              <?php
                  $no = 1;
              ?>
              <?php $__currentLoopData = $transaksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaksi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($no++); ?></td>
                <td><?php echo e($transaksi->no_transaksi); ?></td>
                
                <td style="text-transform:capitalize">
                  <span style="font-size:10pt"> Tanggal Transaksi :</span> <strong> <?php echo e(date('d-m-Y',strtotime($transaksi->tanggal_transaksi))); ?> </strong><br>
                  <span style="font-size:10pt"> Kode Customer :</span> <strong> <?php echo e($transaksi->kode_user); ?> </strong><br>
                  <span style="font-size:10pt"> Nama Customer :</span> <strong><?php echo e($transaksi->nama); ?> </strong><br>
                  <span style="font-size:10pt"> No Kontak :</span> <strong><?php echo e($transaksi->no_kontak); ?> </strong><br>
                  <span style="font-size:10pt"> Alamat Pengiriman :</span><strong> <?php echo e($transaksi->alamat_pengantaran); ?> <?php echo e($transaksi->nama_kecamatan); ?></strong> <br>
                  
                  <span style="font-size:10pt"> Metode Bayar : </span> <strong> <?php echo e($transaksi->metode_bayar); ?> </strong><br>
                  <span style="font-size:10pt"> Besar Transaksi : </span> <strong> Rp. <?php echo e(number_format($transaksi->totharga)); ?>,- </strong><br>
                  <span style="font-size:10pt"> Ongkos Kirim : </span> <strong> Rp. <?php echo e(number_format($transaksi->besar_ongkir)); ?>,- </strong><br>
                  <span style="font-size:10pt"> Total Transaksi : </span> <strong> Rp. <?php echo e(number_format($transaksi->besar_ongkir +$transaksi->totharga)); ?>,- </strong><br><br>
                  
                  <button type="button" class="btn btn-info btn-sm notrans" data-toggle="modal" data-target="#detailTransaksiModal" name="detail" id="tombol_detail_transaksi" value="<?php echo e($transaksi->no_transaksi); ?>">Detail</button>
                

                </td>
                <td class="text-center">
                  <?php if($transaksi->metode_bayar == 'transfer'): ?>
                    <?php if($transaksi->bukti_bayar): ?>
                    <a target="_BLANK" href="<?php echo e(url('assets/buktitransfer/'.$transaksi->bukti_bayar)); ?>"><img width="100" src="<?php echo e(url('assets/buktitransfer/'.$transaksi->bukti_bayar)); ?>" class="img-responsive"></a> 
                    <?php else: ?> 
                    <span class="text-danger"> Belum ada pembayaran </span>
                    <?php endif; ?>
                  <?php else: ?> 
                  <span class="text-success"> Metode Pembayaran COD </span>
                  <?php endif; ?>
                </td>
                <td class="text-center" style="text-transform:capitalize"><?php echo e($transaksi->status_transaksi); ?></td>
                <td class="text-center" >
                  <a href="<?php echo e(url('/konfirmasi_orderan')); ?>/<?php echo e($transaksi->no_transaksi); ?>" class="btn btn-success  btn-sm">Konfirm</a>
                  <a href="<?php echo e(url('/cancel_orderan')); ?>/<?php echo e($transaksi->id); ?>" class="btn btn-danger  btn-sm">Cancel</a>
                  
                </td>
              </tr>    
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>

    

    
    <div class="modal fade " id="detailTransaksiModal" tabindex="-1" role="dialog" aria-labelledby="#detailTransaksiModalTitle" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="detailTransaksiModalTitle">Detail Transaksi</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <div class="row">
              <div class="col-12">
                <p>No Transaksi : <span id="labelnotransaksi"></span></p>
                <p>Nama Customer : <span id="labelnamacustomer"></span></p>
                <div class="row">
                  <div class="col-12">
                    <div class="table-responsive">
                      <table id="data_transaksi" class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                          <tr>
                            <th style="vertical-align:middle" class="text-center">Gambar Produk</th>
                            <th style="vertical-align:middle" class="text-center">Detail Produk</th>
                            <th style="vertical-align:middle" class="text-center">Harga</th>
                            <th style="vertical-align:middle" class="text-center">Kuantitas</th>
                            <th style="vertical-align:middle" class="text-center">Total</th>
                          </tr>
                        </thead>
                        <tbody id="show_data">
                        </tbody>
                        <tfoot>
                          <th colspan="4">Total</th>
                          
                          
                          <th class="text-right"> <span id="grand_total"></span></th>
                        </tfoot>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  

  <!-- Sticky Footer -->
  <footer class="sticky-footer">
    <div class="container my-auto">
      <div class="copyright text-center my-auto">
        <span>Copyright © Lapak_Peduli_Covid19 2020</span>
      </div>
    </div>
  </footer>
</div>
<?php echo $__env->make('dashboard.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lapak_peduli\lapak_peduli\resources\views/dashboard/transaksi.blade.php ENDPATH**/ ?>