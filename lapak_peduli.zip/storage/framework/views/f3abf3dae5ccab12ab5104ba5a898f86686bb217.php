<?php echo $__env->make('lapak.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body class="js">
	
	<!-- Preloader -->
	<div class="preloader">
		<div class="preloader-inner">
			<div class="preloader-icon">
				<span></span>
				<span></span>
			</div>
		</div>
	</div>
	<!-- End Preloader -->
	
	
	<!-- Header -->
	<header class="header shop" style="background:#ef0000">
		<div class="middle-inner" style="background:#ef0000">
			<div class="container">
				<div class="row row justify-content-between">
					<div class="col-lg-2 col-md-2 col-12">
						<div class="logo">
							<a href="<?php echo e(route('index')); ?>"><img src="<?php echo e(url('/')); ?>/assets/images/lapakpeduli.png" alt="logo" width="200px"></a>
            </div>
          </div>
        </div>
			</div>
		</div>
	</header>
  <!--/ End Header -->
  
  <!-- content -->
  <div class="contact-us section">
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-lg-6 col-12">
          <div class="form-main" style="background-color:white;margin-top:50px;">
            <div class="title text-center">
              <h5>Daftarkan lapak</h5>
            </div>
            <form class="form" action="<?php echo e(url('/daftar_lapak')); ?>" method="post">
            <?php echo csrf_field(); ?>
              <div class="row">
                <div class="col-lg-12 col-12">
                  <div class="form-group">
                    <label style="font-size:10pt">Nama Lapak<span>*</span></label>
                    <input style="font-size:10pt" name="nama_lapak" type="text" placeholder="Nama Lapak" value="<?php echo e(old('nama_lapak')); ?>">
                    <?php if ($errors->has('nama_lapak')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nama_lapak'); ?>
                    <span class="help-block text-danger">Wajib diisi</span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                  </div>	
                </div>
                <div class="col-lg-12 col-12">
                  <div class="form-group">
                    <label style="font-size:10pt">Nama Pemilik<span>*</span></label>
                    <input style="font-size:10pt" name="nama_owner" type="text" placeholder="Nama Pemilik" value="<?php echo e(old('nama_owner')); ?>">
                    <?php if ($errors->has('nama_owner')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nama_owner'); ?>
                    <span class="help-block text-danger">Wajib diisi</span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                  </div>	
                </div>
                <div class="col-lg-12 col-12">
                  <div class="form-group">
                    <label style="font-size:10pt">Nomor Handphone<span>*</span></label>
                    <input style="font-size:10pt" name="no_kontak" type="text" placeholder="Nomor Handphone" value="<?php echo e(old('no_kontak')); ?>">
                    <?php if ($errors->has('no_kontak')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('no_kontak'); ?>
                    <span class="help-block text-danger">Wajib diisi</span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                  </div>	
                </div>
                <div class="col-lg-12 col-12">
                  <div class="form-group">
                    <label style="font-size:10pt">Alamat<span>*</span></label>
                    <input style="font-size:10pt" name="alamat" type="text" placeholder="Alamat" value="<?php echo e(old('alamat')); ?>">
                    <?php if ($errors->has('alamat')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('alamat'); ?>
                    <span class="help-block text-danger">Wajib diisi</span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                  </div>	
                </div>
                <div class="col-lg-12 col-12">
                  <div class="form-group">
                    <label style="font-size:10pt">Email<span>*</span></label>
                    <input style="font-size:10pt" name="email" type="email" placeholder="Email" value="<?php echo e(old('email')); ?>">
                    <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                    <span class="help-block text-danger">Wajib diisi</span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                  </div>	
                </div>
                <div class="col-lg-12 col-12">
                  <div class="form-group">
                    <label style="font-size:10pt">Password<span>*</span></label>
                    <input style="font-size:10pt" name="password" type="password" id="password" placeholder="Masukan kata sandi">
                    <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                    <span class="help-block text-danger">Wajib diisi</span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                  </div>	
                </div>
                <div class="form-check" style="margin-left:35px;">
                  <input class="form-check-input" type="checkbox" value="" id="check_password">
                  <label class="form-check-label" style="padding-left:0px;" for="check_password">
                    Tampilkan 
                  </label>
                </div>
                <div class="col-lg-12 col-12">
                  <div class="form-group">
                    <label style="font-size:10pt">Konfirmasi Password<span>*</span></label>
                    <input style="font-size:10pt" name="konfirmpassword" type="password" id="konfirmpassword" placeholder="Masukan kata sandi">
                    <?php if ($errors->has('konfirmpassword')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('konfirmpassword'); ?>
                    <span class="help-block text-danger">Wajib diisi</span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                  </div>	
                </div>
                <div class="form-check" style="margin-left:35px;">
                  <input class="form-check-input" type="checkbox" value="" id="check_konfirm_password">
                  <label class="form-check-label" style="padding-left:0px;" for="check_konfirm_password">
                    Tampilkan 
                  </label>
                </div>
                <div class="col-lg-12 col-12">
                  <div class="form-group">
                    <button type="submit" class="btn btn-block btn-warning btn-md">Daftar</button>
                  </div>	
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- end content -->
  
<?php echo $__env->make('lapak.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php /**PATH C:\xampp\htdocs\lapak_peduli\lapak_peduli\resources\views/lapak/daftar.blade.php ENDPATH**/ ?>