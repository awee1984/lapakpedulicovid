<?php

namespace App\Http\Controllers\Backend;

// use App\User;
use App\Lapak;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;
use Alert;


class LapakController extends Controller
{
    
    // public function masuk(Request $request)
    // {
    //     $validator = Validator::make($request->all(), [
    //         'email'             => 'required',
    //         'password'          => 'required',
    //     ]);

    //     if ($validator->fails()) {
    //         alert()->warning('Opss','Pastikan semua bidang wajib (*) terisi!');
    //         return back()->withInput();
    //     }
    // }

    public function index()
    {
        $lapak = \Auth::user()->nama;

        return view('dashboard.lapak',compact('lapak'));
    }

    
}
