<!DOCTYPE html>
<html lang="zxx">
<head>
	<!-- Meta Tag -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name='copyright' content=''>
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<!-- Title Tag  -->
    <title>Lapak Peduli Covid19</title>
	<!-- Favicon -->
	<link rel="icon" type="image/png" href="images/favicon.png">
	<!-- Web Font -->
	<link href="https://fonts.googleapis.com/css?family=Poppins:200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&display=swap" rel="stylesheet">
	
	<!-- StyleSheet -->
	
	<!-- Bootstrap -->
	<link rel="stylesheet" href="{{url('/')}}/assets/css/bootstrap.css">
	<!-- Magnific Popup -->
    <link rel="stylesheet" href="{{url('/')}}/assets/css/magnific-popup.min.css">
	<!-- Font Awesome -->
    <link rel="stylesheet" href="{{url('/')}}/assets/css/font-awesome.css">
	<!-- Fancybox -->
	<link rel="stylesheet" href="{{url('/')}}/assets/css/jquery.fancybox.min.css">
	<!-- Themify Icons -->
    <link rel="stylesheet" href="{{url('/')}}/assets/css/themify-icons.css">
	<!-- Nice Select CSS -->
    <link rel="stylesheet" href="{{url('/')}}/assets/css/niceselect.css">
	<!-- Animate CSS -->
    <link rel="stylesheet" href="{{url('/')}}/assets/css/animate.css">
	<!-- Flex Slider CSS -->
    <link rel="stylesheet" href="{{url('/')}}/assets/css/flex-slider.min.css">
	<!-- Owl Carousel -->
    <link rel="stylesheet" href="{{url('/')}}/assets/css/owl-carousel.css">
	<!-- Slicknav -->
    <link rel="stylesheet" href="{{url('/')}}/assets/css/slicknav.min.css">
	
	<!-- Eshop StyleSheet -->
	<link rel="stylesheet" href="{{url('/')}}/assets/css/reset.css">
	<link rel="stylesheet" href="{{url('/')}}/assets/style.css">
		<link rel="stylesheet" href="{{url('/')}}/assets/css/responsive.css">
		<style type="text/css">
  		.ajax-load{
  			background: #e1e1e1;
		    padding: 10px 0px;
		    width: 100%;
  		}
  	</style>

	
	
</head>
<body class="js">
	
	<!-- Preloader -->
	<div class="preloader">
		<div class="preloader-inner">
			<div class="preloader-icon">
				<span></span>
				<span></span>
			</div>
		</div>
	</div>
	<!-- End Preloader -->
	
	
	<!-- Header -->
	<header class="header shop" style="background:#ef0000">
		
		<div class="middle-inner" style="background:#ef0000">
			<div class="container">
				<div class="row">
					<div class="col-lg-2 col-md-2 col-12">
						<!-- Logo -->
						<div class="logo">
							<a href="{{ route('index')}}"><img src="{{url('/')}}/assets/images/lapakpeduli.png" alt="logo" width="200px"></a>
						</div>
						<!--/ End Logo -->
						<!-- Search Form -->
						<div class="search-top">
							<div class="top-search"><a href="#0"><i class="ti-search"></i></a></div>
							<!-- Search Form -->
							<div class="search-top">
								<form class="search-form" action="{{ route('index')}}" >
									<input type="text"  name="cari" value="{{ request('cari') }}" placeholder="coba cari Masker ">
									<button type="submit"><i class="ti-search"></i></button>
								</form>
							</div>
							<!--/ End Search Form -->
						</div>
						<!--/ End Search Form -->
						<div class="mobile-nav"></div>
					</div>
					<div class="col-lg-7 col-md-7 col-12">
						<div class="search-bar-top">
							<form action="{{ route('index')}}" >
								<div class="search-bar">
									<select name="kategori" >
										<option value="">Semua Kategori</option>
										@foreach ($kategori as $kategori)
											@if($term_kategori == $kategori->id)
											<option value="{{$kategori->id}}" style="text-transform:capitalize" selected>{{$kategori->nama_kategori}}</option>
											@else		
											<option value="{{$kategori->id}}" style="text-transform:capitalize">{{$kategori->nama_kategori}}</option>	
											@endif	
										@endforeach
									</select>
								
									<input name="cari" placeholder="coba cari Masker " type="search" value="{{ request('cari') }}">
									<button type="submit" class="btnn"><i class="ti-search"></i></button>
								</div>
							</form>
						</div>
					</div>
					<div class="col-lg-3 col-md-3 col-12" >
            <ul class="nav justify-content-end">
              <li class="nav-item">
                <a style="font-size:11pt;padding-left:0px;padding-right:8px"  class="nav-link active" href="{{ url('/login_lapak')}}">Login Lapak</a>
              </li>
              <li class="nav-item">
                <a style="font-size:11pt;padding-left:0px;padding-right:8px" class="nav-link" href="{{ url('/login_user')}}">Login Customer</a>
              </li>
            </ul>
          </div>
				</div>
			</div>
		</div>
	</header>
	<!--/ End Header -->

	<div class="product-area most-popular section" style="padding-bottom:30px;">
    <div class="container" style="margin-top:50px;margin-bottom:30px;">
      <div class="row">
				<div class="col-12">
					<div class="section-title">
						<h2>PRODUK UNTUKMU</h2>
					</div>
				</div>
			</div>
			@if($statuscari == 0)
			<div class="row">
        <div class="col-12">
					<div class="alert alert-warning text-center" role="alert">
						Maaf, produk yang kamu cari tidak ada
					</div>
				</div>
			</div>
			@endif
      <div class="row" style="padding-top:20px;">
        <div class="col-12">
          <div class="owl-carousel popular-slider">
						@foreach ($produk as $produk)
						<div class="single-product">
							<div class="product-img">
								<a href="{{route('login_user')}}">
									<img class="default-img" src="{{url('/')}}/assets/produk/{{$produk->gambar_produk}}" alt="{{route('login_user')}}" style="height:300px;width:255px">
									<img class="hover-img" src="{{url('/')}}/assets/produk/{{$produk->gambar_produk}}" alt="{{route('login_user')}}" style="height:300px;width:255px"">
									{{-- <span class="out-of-stock">Hot</span> --}}
								</a>
								<div class="button-head">
									<div class="product-action-2">
										<a title="Masukkan ke dalam keranjang" href="{{route('login_user')}}">Add to Cart</a>
									</div>
								</div>
							</div>
							<div class="product-content">
								<p>{{$produk->nama_produk}}</p>
								<div class="product-price">
									<span>Rp. {{ number_format($produk->harga_jual)}},-</span>
								</div>
							</div>
            </div>		
						@endforeach 
					</div>
				</div>
      </div>
    </div>
	</div>
	
  <section class="product-area shop-sidebar shop section" style="padding-top:5px;padding-bottom:30px;">
    <div class="container">
      <div class="row">
        <div class="col-lg-12 col-md-12 col-12">
          <div class="shop-sidebar">
            <div class="single-widget category">
              <h3 class="title text-center">Kategori</h3>
              <div class="nav-main">
								<form action="{{ route('index')}}">
									<div class="row">
										<div class="col-12 text-center">
											<button  type="submit" class="btn btn-default btn-sm btn-kat" name="all_kategori" >Semua Kategori</button>
										</div>
										
									</div>
									
									<ul class="nav nav-tabs" id="myTab" role="tablist">
										@foreach ($kategori2 as $kategori2)
										<li class="nav-item" style="margin-top:5px">
											<button type="submit" class="btn btn-default btn-sm btn-kat" name="list_kategori" value="{{$kategori2->id}}">{{$kategori2->nama_kategori}}</button>
										</li>
										@endforeach
									</ul>
								</form>
							</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
	@if($statuscari == 0)
	<div class="col-12">
		<div class="alert alert-warning text-center" role="alert">
			Maaf, produk yang kamu cari tidak ada
		</div>
	</div>
	@endif

	@if($statuscari2 == 0)
	<div class="col-12">
		<div class="alert alert-warning text-center" role="alert">
			Maaf, produk yang kamu cari tidak ada
		</div>
	</div>
	@endif
	<div id="post-data">
		@include('web.data_produk')
	</div>

	{{-- <section class="shop-home-list section">
		<div class="container">
			<div class="row">
				
				@if($statuscari == 0)
				<div class="col-12">
					<div class="alert alert-warning text-center" role="alert">
						Maaf, produk yang kamu cari tidak ada
					</div>
				</div>
				@endif

				@if($statuscari2 == 0)
				<div class="col-12">
					<div class="alert alert-warning text-center" role="alert">
						Maaf, produk yang kamu cari tidak ada
					</div>
				</div>
				@endif
				
				@foreach ($produk2 as $produk2)
				<div class="col-6 col-md-2">
					<div class="single-list">
						<div class="row">
							<div class="col-12 col-md-12">
								<div class="list-image overlay">
									<img src="{{url('/')}}/assets/produk/{{$produk2->gambar_produk}}" alt="#" style="max-height:180px;min-height:180px;">
                  <a href="{{route('login_user')}}" class="buy"><i class="fa fa-shopping-cart"></i></a>
                  <div class="content" style="padding-top:5px;padding-left:0px;padding-right:0px;">
                    <p class="title" style="font-size:10pt"><strong>{{$produk2->nama_produk}}</strong></p>
                    <p >{{$produk2->lapak->nama_lapak}}</p>
                    <p class="price with-discount text-center" style="padding-top:5px;display:block;">Rp. {{number_format($produk2->harga_jual)}},-</p>
                  </div>
								</div>		
							</div>
						</div>
					</div>
        </div>
				@endforeach
			</div>
		</div>
	</section> --}}
	<div class="text-center">
		<button id="load_produk" class="btn btn-default btn-rounded btn-sm" style="height: 40px;vertical-align: middle;margin-bottom: 20px;color: red;padding-top: 10px;border-radius: 45px;">Lihat produk lainnya</button>
	</div>
	<div class="ajax-load text-center" style="display:none;padding-top:0px;padding-bottom:0px;">
		<p><img src="http://demo.itsolutionstuff.com/plugin/loader.gif">Memuat lebih banyak produk</p>
	</div>
  <!-- End Shop Home List  -->
  
  
	
	<!-- Start Cowndown Area -->
	{{-- <section class="cown-down">
		<div class="section-inner ">
			<div class="container-fluid">
				<div class="row">
					<div class="col-lg-6 col-12 padding-right">
						<div class="image">
							<img src="https://via.placeholder.com/750x590" alt="#">
						</div>	
					</div>	
					<div class="col-lg-6 col-12 padding-left">
						<div class="content">
							<div class="heading-block">
								<p class="small-title">Deal of day</p>
								<h3 class="title">Beatutyful dress for women</h3>
								<p class="text">Suspendisse massa leo, vestibulum cursus nulla sit amet, frungilla placerat lorem. Cars fermentum, sapien. </p>
								<h1 class="price">$1200 <s>$1890</s></h1>
								<div class="coming-time">
									<div class="clearfix" data-countdown="2021/02/30"></div>
								</div>
							</div>
						</div>	
					</div>	
				</div>
			</div>
		</div>
	</section> --}}
	<!-- /End Cowndown Area -->
	
	<!-- Start Shop Blog  -->
	{{-- <section class="shop-blog section">
		<div class="container">
			<div class="row">
				<div class="col-12">
					<div class="section-title">
						<h2>From Our Blog</h2>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-lg-4 col-md-6 col-12">
					<!-- Start Single Blog  -->
					<div class="shop-single-blog">
						<img src="https://via.placeholder.com/370x300" alt="#">
						<div class="content">
							<p class="date">22 July , 2020. Monday</p>
							<a href="#" class="title">Sed adipiscing ornare.</a>
							<a href="#" class="more-btn">Continue Reading</a>
						</div>
					</div>
					<!-- End Single Blog  -->
				</div>
				<div class="col-lg-4 col-md-6 col-12">
					<!-- Start Single Blog  -->
					<div class="shop-single-blog">
						<img src="https://via.placeholder.com/370x300" alt="#">
						<div class="content">
							<p class="date">22 July, 2020. Monday</p>
							<a href="#" class="title">Man’s Fashion Winter Sale</a>
							<a href="#" class="more-btn">Continue Reading</a>
						</div>
					</div>
					<!-- End Single Blog  -->
				</div>
				<div class="col-lg-4 col-md-6 col-12">
					<!-- Start Single Blog  -->
					<div class="shop-single-blog">
						<img src="https://via.placeholder.com/370x300" alt="#">
						<div class="content">
							<p class="date">22 July, 2020. Monday</p>
							<a href="#" class="title">Women Fashion Festive</a>
							<a href="#" class="more-btn">Continue Reading</a>
						</div>
					</div>
					<!-- End Single Blog  -->
				</div>
			</div>
		</div>
	</section> --}}
	<!-- End Shop Blog  -->
	
	<!-- Start Shop Services Area -->
	{{-- <section class="shop-services section home">
		<div class="container">
			<div class="row">
				<div class="col-lg-3 col-md-6 col-12">
					<!-- Start Single Service -->
					<div class="single-service">
						<i class="ti-rocket"></i>
						<h4>Free shiping</h4>
						<p>Orders over $100</p>
					</div>
					<!-- End Single Service -->
				</div>
				<div class="col-lg-3 col-md-6 col-12">
					<!-- Start Single Service -->
					<div class="single-service">
						<i class="ti-reload"></i>
						<h4>Free Return</h4>
						<p>Within 30 days returns</p>
					</div>
					<!-- End Single Service -->
				</div>
				<div class="col-lg-3 col-md-6 col-12">
					<!-- Start Single Service -->
					<div class="single-service">
						<i class="ti-lock"></i>
						<h4>Sucure Payment</h4>
						<p>100% secure payment</p>
					</div>
					<!-- End Single Service -->
				</div>
				<div class="col-lg-3 col-md-6 col-12">
					<!-- Start Single Service -->
					<div class="single-service">
						<i class="ti-tag"></i>
						<h4>Best Peice</h4>
						<p>Guaranteed price</p>
					</div>
					<!-- End Single Service -->
				</div>
			</div>
		</div>
	</section> --}}
	<!-- End Shop Services Area -->
	
	
	<!-- Modal -->
    {{-- <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span class="ti-close" aria-hidden="true"></span></button>
                    </div>
                    <div class="modal-body">
                        <div class="row no-gutters">
                            <div class="col-lg-6 col-md-12 col-sm-12 col-xs-12">
                                <!-- Product Slider -->
									<div class="product-gallery">
										<div class="quickview-slider-active">
											<div class="single-slider">
												<img src="https://via.placeholder.com/569x528" alt="#">
											</div>
											<div class="single-slider">
												<img src="https://via.placeholder.com/569x528" alt="#">
											</div>
											<div class="single-slider">
												<img src="https://via.placeholder.com/569x528" alt="#">
											</div>
											<div class="single-slider">
												<img src="https://via.placeholder.com/569x528" alt="#">
											</div>
										</div>
									</div>
								<!-- End Product slider -->
                            </div>
                            <div class="col-lg-6 col-md-12 col-sm-12 col-xs-12">
                                <div class="quickview-content">
                                    <h2>Flared Shift Dress</h2>
                                    <div class="quickview-ratting-review">
                                        <div class="quickview-ratting-wrap">
                                            <div class="quickview-ratting">
                                                <i class="yellow fa fa-star"></i>
                                                <i class="yellow fa fa-star"></i>
                                                <i class="yellow fa fa-star"></i>
                                                <i class="yellow fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                            </div>
                                            <a href="#"> (1 customer review)</a>
                                        </div>
                                        <div class="quickview-stock">
                                            <span><i class="fa fa-check-circle-o"></i> in stock</span>
                                        </div>
                                    </div>
                                    <h3>$29.00</h3>
                                    <div class="quickview-peragraph">
                                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Mollitia iste laborum ad impedit pariatur esse optio tempora sint ullam autem deleniti nam in quos qui nemo ipsum numquam.</p>
                                    </div>
									<div class="size">
										<div class="row">
											<div class="col-lg-6 col-12">
												<h5 class="title">Size</h5>
												<select>
													<option selected="selected">s</option>
													<option>m</option>
													<option>l</option>
													<option>xl</option>
												</select>
											</div>
											<div class="col-lg-6 col-12">
												<h5 class="title">Color</h5>
												<select>
													<option selected="selected">orange</option>
													<option>purple</option>
													<option>black</option>
													<option>pink</option>
												</select>
											</div>
										</div>
									</div>
                                    <div class="quantity">
										<!-- Input Order -->
										<div class="input-group">
											<div class="button minus">
												<button type="button" class="btn btn-primary btn-number" disabled="disabled" data-type="minus" data-field="quant[1]">
													<i class="ti-minus"></i>
												</button>
											</div>
											<input type="text" name="quant[1]" class="input-number"  data-min="1" data-max="1000" value="1">
											<div class="button plus">
												<button type="button" class="btn btn-primary btn-number" data-type="plus" data-field="quant[1]">
													<i class="ti-plus"></i>
												</button>
											</div>
										</div>
										<!--/ End Input Order -->
									</div>
									<div class="add-to-cart">
										<a href="#" class="btn">Add to cart</a>
										<a href="#" class="btn min"><i class="ti-heart"></i></a>
										<a href="#" class="btn min"><i class="fa fa-compress"></i></a>
									</div>
                                    <div class="default-social">
										<h4 class="share-now">Share:</h4>
                                        <ul>
                                            <li><a class="facebook" href="#"><i class="fa fa-facebook"></i></a></li>
                                            <li><a class="twitter" href="#"><i class="fa fa-twitter"></i></a></li>
                                            <li><a class="youtube" href="#"><i class="fa fa-pinterest-p"></i></a></li>
                                            <li><a class="dribbble" href="#"><i class="fa fa-google-plus"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    </div> --}}
    <!-- Modal end -->
	
	<!-- Start Footer Area -->
	<footer class="footer">
		<div class="copyright">
			<div class="container">
				<div class="inner">
					<div class="row">
						<div class="col-lg-6 col-12">
							<div class="left">
								<p>Copyright © 2020 Komunitas Peduli Covid  -  All Rights Reserved.</p>
							</div>
						</div>
						<div class="col-lg-6 col-12">
							{{-- <div class="right">
								<img src="images/payments.png" alt="#">
							</div> --}}
						</div>
					</div>
				</div>
			</div>
		</div>
	</footer>
	<!-- /End Footer Area -->
 
	<!-- Jquery -->
		<script src="{{url('/')}}/assets/js/jquery.min.js"></script>
		<script type="text/javascript">
			var page = 1;
			$(window).scroll(function() {
					if($(window).scrollTop() + $(window).height() >= $(document).height()) {
							page++;
							loadMoreData(page);
					}
			});
		</script>
		<script>
			function loadMoreData(page){
				$.ajax(
							{
									url: '?page=' + page,
									type: "get",
									beforeSend: function()
									{
											$('.ajax-load').show();
									}
							})
							.done(function(data)
							{
									if(data.html == " "){
											$('.ajax-load').html("No more records found");
											return;
									}
									$('.ajax-load').hide();
									$("#post-data").append(data.html);
							})
							.fail(function(jqXHR, ajaxOptions, thrownError)
							{
										alert('server not responding...');
							});
			}
		</script>
		<script>
			$('#load_produk').click(function(){
				loadMoreData(page);
			});
		</script>
    <script src="{{url('/')}}/assets/js/jquery-migrate-3.0.0.js"></script>
	<script src="{{url('/')}}/assets/js/jquery-ui.min.js"></script>
	<!-- Popper JS -->
	<script src="{{url('/')}}/assets/js/popper.min.js"></script>
	<!-- Bootstrap JS -->
	<script src="{{url('/')}}/assets/js/bootstrap.min.js"></script>
	<!-- Color JS -->
	<script src="{{url('/')}}/assets/js/colors.js"></script>
	<!-- Slicknav JS -->
	<script src="{{url('/')}}/assets/js/slicknav.min.js"></script>
	<!-- Owl Carousel JS -->
	<script src="{{url('/')}}/assets/js/owl-carousel.js"></script>
	<!-- Magnific Popup JS -->
	<script src="{{url('/')}}/assets/js/magnific-popup.js"></script>
	<!-- Waypoints JS -->
	<script src="{{url('/')}}/assets/js/waypoints.min.js"></script>
	<!-- Countdown JS -->
	<script src="{{url('/')}}/assets/js/finalcountdown.min.js"></script>
	<!-- Nice Select JS -->
	<script src="{{url('/')}}/assets/js/nicesellect.js"></script>
	<!-- Flex Slider JS -->
	<script src="{{url('/')}}/assets/js/flex-slider.js"></script>
	<!-- ScrollUp JS -->
	<script src="{{url('/')}}/assets/js/scrollup.js"></script>
	<!-- Onepage Nav JS -->
	<script src="{{url('/')}}/assets/js/onepage-nav.min.js"></script>
	<!-- Easing JS -->
	<script src="{{url('/')}}/assets/js/easing.js"></script>
	<!-- Active JS -->
	<script src="{{url('/')}}/assets/js/active.js"></script>

	

</body>
</html>