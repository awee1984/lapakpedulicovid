<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Lapak Pedul | Login - Super Admin</title>

    <!-- Bootstrap core CSS-->
    <link href="{{url('/')}}/dashboard/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom fonts for this template-->
    <link href="{{url('/')}}/dashboard/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

    <!-- Custom styles for this template-->
    <link href="{{url('/')}}/dashboard/css/sb-admin.css" rel="stylesheet">

  </head>

  <body class="bg-dark">

    <div class="container" style="margin-top:150px;" >
      <div class="card card-login mx-auto mt-5">
        <div class="card-header">Login Super Admin</div>
        <div class="card-body">
          <form method="post" action="{{ route('superAdmin_login')}}">
          @csrf
            <div class="form-group">
              <label>Email</label>
              <input type="email"  class="form-control" name="email">
            </div>
            <div class="form-group">
              <label>Password</label>
              <input type="password"  class="form-control" name="password">
            </div>
            <div class="form-group">
              <button type="submit" class="btn btn-danger btn-block"> Login </button>
            </div>
          </form>
          
        </div>
      </div>
    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="{{url('/')}}/dashboard/vendor/jquery/jquery.min.js"></script>
    <script src="{{url('/')}}/dashboard/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="{{url('/')}}/dashboard/vendor/jquery-easing/jquery.easing.min.js"></script>

  </body>

</html>
