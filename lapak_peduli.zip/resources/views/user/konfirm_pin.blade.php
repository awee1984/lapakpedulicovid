<!DOCTYPE html>
<html lang="zxx">
<head>
	<!-- Meta Tag -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name='copyright' content=''>
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<!-- Title Tag  -->
    <title>Lapak Peduli Covid19</title>
	<!-- Favicon -->
	<link rel="icon" type="image/png" href="images/favicon.png">
	<!-- Web Font -->
	<link href="https://fonts.googleapis.com/css?family=Poppins:200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&display=swap" rel="stylesheet">
	
	<!-- StyleSheet -->
	
	<!-- Bootstrap -->
	<link rel="stylesheet" href="{{url('/')}}/assets/css/bootstrap.css">
	<!-- Magnific Popup -->
    <link rel="stylesheet" href="{{url('/')}}/assets/css/magnific-popup.min.css">
	<!-- Font Awesome -->
    <link rel="stylesheet" href="{{url('/')}}/assets/css/font-awesome.css">
	<!-- Fancybox -->
	<link rel="stylesheet" href="{{url('/')}}/assets/css/jquery.fancybox.min.css">
	<!-- Themify Icons -->
    <link rel="stylesheet" href="{{url('/')}}/assets/css/themify-icons.css">
	<!-- Nice Select CSS -->
    <link rel="stylesheet" href="{{url('/')}}/assets/css/niceselect.css">
	<!-- Animate CSS -->
    <link rel="stylesheet" href="{{url('/')}}/assets/css/animate.css">
	<!-- Flex Slider CSS -->
    <link rel="stylesheet" href="{{url('/')}}/assets/css/flex-slider.min.css">
	<!-- Owl Carousel -->
    <link rel="stylesheet" href="{{url('/')}}/assets/css/owl-carousel.css">
	<!-- Slicknav -->
    <link rel="stylesheet" href="{{url('/')}}/assets/css/slicknav.min.css">
	
	<!-- Eshop StyleSheet -->
	<link rel="stylesheet" href="{{url('/')}}/assets/css/reset.css">
	<link rel="stylesheet" href="{{url('/')}}/assets/style.css">
	<link rel="stylesheet" href="{{url('/')}}/assets/mystyle.css">
  <link rel="stylesheet" href="{{url('/')}}/assets/css/responsive.css">

	
	
</head>
<body class="js">
	
	<!-- Preloader -->
	<div class="preloader">
		<div class="preloader-inner">
			<div class="preloader-icon">
				<span></span>
				<span></span>
			</div>
		</div>
	</div>
	<!-- End Preloader -->
	
	
	<!-- Header -->
	<header class="header shop" style="background:#ef0000">
		<div class="middle-inner" style="background:#ef0000">
			<div class="container">
				<div class="row row justify-content-between">
					<div class="col-lg-2 col-md-2 col-12">
						<div class="logo">
							<a href="{{ route('index')}}"><img src="{{url('/')}}/assets/images/lapakpeduli.png" alt="logo" width="200px"></a>
            </div>
          </div>
        </div>
			</div>
		</div>
	</header>
  <!--/ End Header -->
  
  <!-- content -->
  <div class="contact-us section">
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-lg-6 col-12">
          <div class="form-main" style="background-color:white;margin-top:50px;">
            <div class="title text-center">
              <h5>Konfirmasi PIN registrasi</h5>
            </div>
            <form class="form" action="{{ url('/entry_pin')}}" method="post" enctype="multipart/form-data">
            @csrf
              <div class="row">
                <div class="col-lg-12 col-12">
                  <table>
                    <thead>
                      <tr>
                        <td width="30%">Kode Customer  </td><td width="2%">:</td><td><strong>{{$customer->kode_user}}</strong></td>
                      </tr>
                      <tr>
                        <td width="30%">Nama Customer  </td><td width="2%">:</td><td><strong>{{$customer->nama}}</strong></td>
                      </tr>
                      <tr>
                        <td width="30%">Email :</td><td width="2%">:</td><td><strong>{{$customer->email}}</strong></td>
                      </tr>
                    </thead>
                  </table>
                  <input name="kode_user" type="hidden" value="{{$customer->kode_user}}" readonly>
                  <input name="nama" type="hidden" value="{{$customer->nama}}" readonly>
                  <input name="email" type="hidden" value="{{$customer->email}}" readonly>
                  
                </div>
                <div class="col-lg-12 col-12 text-center">
                  <p>Masukan PIN</p>
                  <div class="form-group">
                    <input class="text-center" style="font-size:20pt;color:red" placeholder="_____" name="pin" type="text" value="{{old('pin')}}">
                  </div>
                </div>
                
                
                
                
                
                <div class="col-lg-12 col-12">
                  <div class="form-group">
                    <button type="submit" id="pendaftaran_user" class="btn btn-block btn-warning btn-md">Submit</button>
                  </div>	
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- end content -->
  
  <!-- Start Footer Area -->
  {{-- <footer class="footer">
    <div class="copyright">
      <div class="container">
        <div class="inner">
          <div class="row">
            <div class="col-lg-6 col-12">
              <div class="left">
                <p>Copyright © 2020 Komunitas Peduli Covid  -  All Rights Reserved.</p>
              </div>
            </div>
          </div>
        </div>
      </div>  
    </div>
  </footer> --}}
  <!-- /End Footer Area -->

  <!-- Jquery -->
  <script src="{{url('/')}}/assets/js/jquery.min.js"></script>
  <script src="{{url('/')}}/assets/js/jquery-migrate-3.0.0.js"></script>
  <script src="{{url('/')}}/assets/js/jquery-ui.min.js"></script>
  <!-- Popper JS -->
  <script src="{{url('/')}}/assets/js/popper.min.js"></script>
  <!-- Bootstrap JS -->
  <script src="{{url('/')}}/assets/js/bootstrap.min.js"></script>
  <!-- Color JS -->
  <script src="{{url('/')}}/assets/js/colors.js"></script>
  <!-- Slicknav JS -->
  <script src="{{url('/')}}/assets/js/slicknav.min.js"></script>
  <!-- Owl Carousel JS -->
  <script src="{{url('/')}}/assets/js/owl-carousel.js"></script>
  <!-- Magnific Popup JS -->
  <script src="{{url('/')}}/assets/js/magnific-popup.js"></script>
  <!-- Waypoints JS -->
  <script src="{{url('/')}}/assets/js/waypoints.min.js"></script>
  <!-- Countdown JS -->
  <script src="{{url('/')}}/assets/js/finalcountdown.min.js"></script>
  <!-- Nice Select JS -->
  <script src="{{url('/')}}/assets/js/nicesellect.js"></script>
  <!-- Flex Slider JS -->
  <script src="{{url('/')}}/assets/js/flex-slider.js"></script>
  <!-- ScrollUp JS -->
  <script src="{{url('/')}}/assets/js/scrollup.js"></script>
  <!-- Onepage Nav JS -->
  <script src="{{url('/')}}/assets/js/onepage-nav.min.js"></script>
  <!-- Easing JS -->
  <script src="{{url('/')}}/assets/js/easing.js"></script>
  <!-- Active JS -->
  <script src="{{url('/')}}/assets/js/active.js"></script>
  <script src="{{url('/')}}/assets/myscript.js"></script>
</body>
</html>
  