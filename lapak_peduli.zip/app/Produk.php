<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Produk extends Model
{
    protected $table = 'produks';


    public function lapak()
    {
    	return $this->belongsTo('App\Lapak');
    }

    public function kategori()
    {
    	return $this->belongsTo('App\Kategori');
    }

    public function cart()
    {
    	return $this->hasOne('App\Cart');
    }

    public function transaksi()
    {
    	return $this->hasOne('App\Transaksi');
    }


}
