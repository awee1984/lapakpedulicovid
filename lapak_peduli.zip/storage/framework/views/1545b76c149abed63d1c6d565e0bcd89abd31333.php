<?php echo $__env->make('web.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body class="js">
	
	<!-- Preloader -->
	<div class="preloader">
		<div class="preloader-inner">
			<div class="preloader-icon">
				<span></span>
				<span></span>
			</div>
		</div>
	</div>
  <!-- End Preloader -->
  <div class="contact-us section">
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-lg-12 col-12">
          <div class="form-main" style="background-color:white;margin-top:50px;">
            <div class="title">
              <h5>Cart</h5>
            </div>
            <div class="row">
              <div class="col-lg-12">
                <?php if(session('status')): ?>
                  <div class="alert alert-success">
                      <?php echo e(session('status')); ?>

                  </div>
                <?php endif; ?>
              </div>
            </div>
            <div class="row">
              <div class="col-lg-12">
                <?php if(session('hapus')): ?>
                  <div class="alert alert-danger">
                      <?php echo e(session('hapus')); ?>

                  </div>
                <?php endif; ?>
              </div>
            </div>
            <div class="table-responsive">
              <table class="table">
                <thead style="background-color:#ef0000;color:#fff">
                  <th style="height:60px;padding-left:10px;padding-right:10px;">Kode Produk</th>
                  <th style="height:60px;padding-left:10px;padding-right:10px;">Image</th>
                  <th style="height:60px;padding-left:10px;padding-right:10px;">Nama Produk</th>
                  <th style="height:60px;padding-left:10px;padding-right:10px;">Harga</th>
                  <th style="height:60px;padding-left:10px;padding-right:10px;">Kuantitas</th>
                  <th style="height:60px;padding-left:10px;padding-right:10px;">Total</th>
                  <th style="height:60px;padding-left:10px;padding-right:10px;">Motode Bayar</th>
                  <th style="height:60px;padding-left:10px;padding-right:10px;"><i class="fa fa-edit"></i></th>
                  <th style="height:60px;padding-left:10px;padding-right:10px;"><i class="ti-trash remove-icon"></th>
                </thead>
                <tbody >
                  <?php $__currentLoopData = $isicart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $isicart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr >
                    <td style="padding-top:20px;padding-left:10px"><?php echo e($isicart->produk->kode_produk); ?></td>
                    <td style="padding-top:20px;padding-left:10px"><img src="<?php echo e(url('/')); ?>/assets/produk/<?php echo e($isicart->produk->gambar_produk); ?>" alt="" width="100px"></td>
                    <td style="padding-top:20px;padding-left:10px">
                      <?php echo e($isicart->produk->nama_produk); ?> <br>
                      Lapak : <?php echo e($isicart->lapak->nama_lapak); ?> <br>
                      Kontak : <?php echo e($isicart->lapak->no_kontak); ?>

                    </td>
                    <td style="padding-top:20px;padding-left:10px">Rp. <?php echo e(number_format($isicart->produk->harga_jual)); ?>,-</td>
                    <td style="padding-top:20px;padding-left:10px"><?php echo e($isicart->qty); ?></td>
                    <td style="padding-top:20px;padding-left:10px">Rp. <?php echo e(number_format($isicart->produk->harga_jual*$isicart->qty)); ?>,-</td>
                    <td style="padding-top:20px;padding-left:10px"><?php echo e($isicart->metode_bayar); ?></td>
                    <td style="padding-top:20px;padding-left:10px">
                      <a href="<?php echo e(url('/edit_cart')); ?>/<?php echo e($isicart->id); ?>" data-toggle="tooltip" data-placement="top" title="Ubah orderan"><i class="fa fa-edit"></i></a>
                    </td>
                    <td style="padding-top:20px;padding-left:10px">
                      <a href="<?php echo e(url('/hapus_cart')); ?>/<?php echo e($isicart->id); ?>" data-toggle="tooltip" data-placement="top" title="Hapus orderan"><i class="ti-trash remove-icon"></i></a>
                    </td>
                  </tr>    
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  
                </tbody>
              </table>
            </div>
            <form action="<?php echo e(route('order')); ?>" method="post">
            <?php echo csrf_field(); ?>
              <div class="row ">
                <div class="col-lg-12 col-12 text-primary">
                  Alamat pengantaran diatur default sesuai alamat anda, silahkan ubah jika alamat pengiriman berbeda :
                </div>
                <input type="hidden" id="customer_id" value="<?php echo e(Auth::user()->id); ?>">
                <div class="col-lg-3 col-12">
                  <div class="form-group">
                    <label>Kecamatan</label>
                    <select name="kecamatan" class="form-control" id="kecamatan_pengantaran">
                      <option value="">-- Pilih Kecamatan --</option>
                      <?php $__currentLoopData = $listkecamatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listkecamatan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php if($kecamatanuser == $listkecamatan->id): ?>
                      <option value="<?php echo e($listkecamatan->id); ?>" selected><?php echo e($listkecamatan->nama_kecamatan); ?></option>
                      <?php else: ?> 
                      <option value="<?php echo e($listkecamatan->id); ?>"><?php echo e($listkecamatan->nama_kecamatan); ?></option>
                      <?php endif; ?>                        
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php if ($errors->has('kecamatan')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('kecamatan'); ?>
                    <span class="help-block text-danger">Wajib diisi</span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                  </div>
                </div>
                <div class="col-lg-9 col-12">
                  <div class="form-group">
                    <label >Alamat</label>
                    <input type="text" name="alamat_kirim" class="form-control" value="<?php echo e($alamat); ?>" style="height:42px;font-size:11pt;">
                    <?php if ($errors->has('alamat_kirim')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('alamat_kirim'); ?>
                    <span class="help-block text-danger">Wajib diisi</span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                  </div>
                </div>
              </div>
              
              <?php if($pesan): ?>
              <div class="row ">
                <div class="col-lg-12 col-12">
                  <?php echo e($pesan); ?>

                  <div class="row ">
                    <div class="col-lg-3 col-12">
                      <table>
                        <thead id="tampil_data1">
                          <?php $__currentLoopData = $jmllapak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jmllapak): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                            <td><?php echo e($jmllapak->nama_lapak); ?></td><td class="text-right">Rp. <?php echo e(number_format($jmllapak->besar_ongkir)); ?>,-</td>
                          </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </thead>
                        <thead id="tampil_data2"></thead>
                        <tfoot>
                          <th>Total Ongkir</th><th class="text-right" id="totongkir">Rp. <?php echo e(number_format($totalongkir)); ?>,-</th>
                        </tfoot>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
              <?php endif; ?>
              Jika ongkos kirim tidak ditetapkan oleh pelapak, maka pembayaran ongkos kirim akan dibayarakan ditempat pengantaran, silahkan menghubungi pelapak untuk lebih detail
              <br><br>
              <div class="row justify-content-lg-end">
                <div class="col-lg-4 col-12">
                  <div class="table-responsive">
                    <table class="table">
                      <thead>
                        <tr>
                          <th>Sub Total</th>
                          <th class="text-right" >
                              <input id="jml_transaksi" type="hidden" value="<?php echo e($grandtotal); ?>">
                             Rp. <?php echo e(number_format($grandtotal)); ?>,-
                          </th>
                        </tr>
                        <tr>
                          <th>Ongkos Kirim</th>
                          <?php if($ongkir): ?>
                            <?php if($pesan): ?>
                            <th class="text-right" id="ongkirnya"> Rp. <?php echo e(number_format($totalongkir)); ?>,-</th>
                            <?php else: ?> 
                            <th class="text-right" id="ongkirnya"> Rp. <?php echo e(number_format($ongkir->besar_ongkir)); ?>,-</th>
                            <?php endif; ?>
                          <?php else: ?> 
                          <th class="text-right" id="ongkirnya"> Rp. 0,-</th>
                          <?php endif; ?>
                        </tr>
                        <tr>
                          <th>Grand Total</th>
                          <?php if($ongkir): ?>
                            <?php if($pesan): ?>
                            <th class="text-right text-danger" id="grand_total_belanja" > <h6>Rp. <?php echo e(number_format($grandtotal + $totalongkir)); ?>,-</h6> </th>
                            <?php else: ?> 
                            <th class="text-right text-danger" id="grand_total_belanja"  > <h6>Rp. <?php echo e(number_format($grandtotal + $ongkir->besar_ongkir)); ?>,-</h6> </th>
                            <?php endif; ?>
                          <?php else: ?> 
                          <th class="text-right text-danger" id="grand_total_belanja" > <h6>Rp. <?php echo e(number_format($grandtotal)); ?>,-</h6> </th>
                          <?php endif; ?>
                        </tr>
                      </thead>
                    </table>
                    
                  </div>
                  <button type="submit" class="btn btn-primary btn-block">Checkout</button>
                </form>
                  <a href="<?php echo e(route('landingpage_user')); ?>" class="btn btn-success btn-block text-light text-center">Lanjutkan Belanja</a>
                </div>
              </div>
            
          </div>
        </div>
      </div>
    </div>
  </div>
  

<?php echo $__env->make('web.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lapak_peduli\lapak_peduli\resources\views/user/cart.blade.php ENDPATH**/ ?>