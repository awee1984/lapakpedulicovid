<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTransaksisTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('transaksis', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('no_transaksi');
            $table->date('tanggal_transaksi');
            $table->integer('user_id');
            $table->integer('produk_id');
            $table->integer('qty_produk');
            $table->integer('harga');
            $table->integer('total_harga');
            $table->integer('ongkir');
            $table->integer('kecamatan_id');
            $table->string('alamat_pengantaran');
            $table->string('status_transaksi');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('transaksis');
    }
}
