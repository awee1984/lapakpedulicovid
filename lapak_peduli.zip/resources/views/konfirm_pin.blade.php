<!doctype html>
<html>
<head>
  <meta name="viewport" content="width=device-width" />
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
  <title>Email PIN Konfirmasi </title>
  <link href="https://fonts.googleapis.com/css?family=Poppins:200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="{{url('/')}}/assets/css/bootstrap.css">
</head>
<body >
  <div>
    <p>Yang terhormat {{$nama}},</p> 
    <p>Terima kasih telah bergabung bersama kami di Lapak Peduli Covid19, untuk mengaktivasi akun anda silahkan masukkan kode PIN berikut <strong><u>{{$pin}}</u></strong> dalam form registrasi anda </p>
    <p>atau silahkan klik tautan berikut https://www.lapakpeduli.com/pin_registrasi//{{ $email }}</p> 
    <p>Hormat kami admin Lapak Peduli Covid 19 </p> 
    <h5>#dirumahaja </h5> 

  </div>

</body>
</html>