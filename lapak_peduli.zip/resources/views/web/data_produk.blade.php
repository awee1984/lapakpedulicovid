<section class="shop-home-list section" style="padding-bottom:0px;">
  <div class="container">
    <div class="row">
      
      
      
      @foreach ($produk2 as $produk2)
      <div class="col-6 col-md-2">
        <div class="single-list">
          <div class="row">
            <div class="col-12 col-md-12">
              <div class="list-image overlay">
                <img src="{{url('/')}}/assets/produk/{{$produk2->gambar_produk}}" alt="#" style="max-height:180px;min-height:180px;">
                <a href="{{route('login_user')}}" class="buy"><i class="fa fa-shopping-cart"></i></a>
                <div class="content" style="padding-top:5px;padding-left:0px;padding-right:0px;">
                  <p class="title" style="font-size:10pt"><strong>{{$produk2->nama_produk}}</strong></p>
                  <p >{{$produk2->lapak->nama_lapak}}</p>
                  <p class="price with-discount text-center" style="padding-top:5px;display:block;">Rp. {{number_format($produk2->harga_jual)}},-</p>
                </div>
              </div>		
            </div>
          </div>
        </div>
      </div>
      @endforeach
    </div>
  </div>
</section>