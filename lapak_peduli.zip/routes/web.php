<?php



// Route web
Route::get('/', 'Web\LandingpageController@index')->name('index');



// Auth::routes();
Auth::routes(['register'=> false, 'reset'=>false]);

Route::get('/dirumahaja', 'Auth\LoginController@showSuperAdminLoginForm')->name('superadmin');
Route::post('/dirumahaja_login', 'Auth\LoginController@superAdminLogin')->name('superAdmin_login');

Route::get('/daftar_lapak', 'PendaftaranController@daftarform')->name('daftar_lapak');
Route::post('/daftar_lapak', 'PendaftaranController@daftar_lapak');
Route::get('/login_lapak', 'Auth\LoginController@showLapakLoginForm')->name('login_lapak');
Route::post('/lapak_login', 'Auth\LoginController@lapakLogin')->name('lapak_login');

Route::get('/daftar_user', 'PendaftaranController@daftarUserform')->name('daftar_user');
Route::post('/daftar_user', 'PendaftaranController@daftar_user');
Route::get('/pin_registrasi/{email}', 'PendaftaranController@pin_registrasi');
Route::get('/lapak_pin_registrasi/{email}', 'PendaftaranController@lapak_pin_registrasi');
Route::post('/entry_pin', 'PendaftaranController@entrypin');
Route::post('/entry_pin_lapak', 'PendaftaranController@entrypin_lapak');
Route::get('/login_user', 'Auth\LoginController@showUserLoginForm')->name('login_user');
Route::post('/user_login', 'Auth\LoginController@userLogin')->name('user_login');

Route::group(['middleware' => 'auth:superadmin'], function () {
    Route::get('/superadmin_home', 'Backend\HomeSuperAdminController@index');
    Route::get('/aktifkan_lapak/{id}', 'Backend\HomeSuperAdminController@aktifkan_lapak');
    Route::get('/nonaktifkan_lapak/{id}', 'Backend\HomeSuperAdminController@nonaktifkan_lapak');
    Route::get('/aktifkan_user/{id}', 'Backend\HomeSuperAdminController@aktifkan_user');
    Route::get('/nonaktifkan_user/{id}', 'Backend\HomeSuperAdminController@nonaktifkan_user');
    Route::get('/lapak_superadmin', 'Backend\HomeSuperAdminController@lapak');
    Route::get('/user_superadmin', 'Backend\HomeSuperAdminController@user');
    
});
Route::group(['middleware' => 'auth:lapak'], function () {
    Route::get('/lapak_home', 'Backend\HomelapakController@index')->name('lapak_home');
    Route::get('/lapak_produk', 'Backend\HomelapakController@produk');
    Route::get('/produk_tambah', 'Backend\HomelapakController@tambah');
    Route::post('/produk_tambah', 'Backend\HomelapakController@simpan');
    Route::post('/produk_update', 'Backend\HomelapakController@update');
    Route::get('/nonaktifkan_produk/{id}', 'Backend\HomelapakController@nonaktif_produk');
    Route::get('/aktifkan_produk/{id}', 'Backend\HomelapakController@aktif_produk');
    Route::get('/profil_lapak', 'Backend\HomelapakController@profil');
    Route::patch('/profil_lapak/{id}', 'Backend\HomelapakController@update_profil');
    Route::get('/ongkir', 'Backend\HomelapakController@ongkir');
    Route::post('/ongkir_tambah', 'Backend\HomelapakController@simpan_ongkir');
    Route::post('/ongkir_update', 'Backend\HomelapakController@update_ongkir');
    Route::get('/transaksi', 'Backend\HomelapakController@transaksi');
    Route::get('/get_transaksi/{notrans}', 'Backend\HomelapakController@get_transaksi');
    Route::get('/konfirmasi_orderan/{notrans}', 'Backend\HomelapakController@konfirm_order');
});

Route::group(['middleware' => 'auth:user'], function () {
    Route::get('/landingpage_user', 'web\LandingpageController@landing_user')->name('landingpage_user');
    Route::get('/lihat_produk/{produk}', 'web\LandingpageController@lihat');
    Route::post('/to_cart/{produk}', 'web\LandingpageController@masuk_keranjang');
    Route::get('/cart', 'web\LandingpageController@cart');
    Route::get('/edit_cart/{cart}', 'web\LandingpageController@edit_cart');
    Route::patch('/to_cart_edit/{id}', 'web\LandingpageController@edit_keranjang');
    Route::get('/hapus_cart/{cart}', 'web\LandingpageController@hapus_cart');
    Route::post('/order', 'web\LandingpageController@order')->name('order');
    Route::get('/order_status', 'web\LandingpageController@orderstatus');
    Route::get('/get_pelapak/{id}', 'web\LandingpageController@get_pelapak');
    Route::get('/get_norek/{id}', 'web\LandingpageController@get_norek');
    Route::get('/get_ongkir_ke/{id}/{cust}', 'web\LandingpageController@get_ongkir');
    Route::post('/upload_bukti_bayar', 'web\LandingpageController@upload_transfer');
    Route::get('/cancel_order/{id}', 'web\LandingpageController@cancel');
});



