<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;
use App\Lapak;
use App\User;
use App\Superadmin;
use App\Kecamatan;
use Notification;
use Event;
// use App\Notifications\MyFirstNotification;
use App\Notifications\NewUser;
use App\Events\UserBaruNotif;
use App\Events\LapakBaruNotif;
use App\Mail\LapakpeduliEmail;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Str;

class PendaftaranController extends Controller
{
    public $pathuser;

    public function __construct()
    {
    $this->pathuser = 'assets/user';
    }

    public function daftarform()
    {
        $kecamatan = Kecamatan::orderBy('nama_kecamatan')->get();
        return view ('lapak.daftar',compact('kecamatan'));
    }

    public function daftar_lapak(Request $request)
    {
        if($request->password != $request->konfirmpassword){
            return back()->with('gagal_login','password tidak sama, ulangi kembali!');   
        }
        $request->validate([
            'nama_lapak'        => 'required|unique:lapaks,nama_lapak',
            'nama_owner'        => 'required',
            'no_kontak'         => 'required|unique:lapaks,no_kontak',
            'alamat'            => 'required',
            'email'             => 'required|unique:lapaks,email',
            'password'          => 'required|min:6',
            'konfirmpassword'   => 'required',
        ]);

        $tanggal_sekarang = date('Ymd');
        $jumlahlapak = Lapak::count();
        if($jumlahlapak < 10){
            $nourut = '00000';
        }elseif($jumlahlapak >=10 && $jumlahlapak < 100){
            $nourut = '0000';
        }elseif($jumlahlapak >=100 && $jumlahlapak < 1000){
            $nourut = '000';
        }elseif($jumlahlapak >=1000 && $jumlahlapak < 10000){
            $nourut = '00';
        }else{
            $nourut = '0';
        }
        $kodelapak = $tanggal_sekarang.''.$nourut.''.$jumlahlapak+1;

        $datas = [
            'nama'          => $request->nama_owner,
            'kode_lapak'    => $kodelapak,
            'nama_lapak'    => $request->nama_lapak
        ];

        // kirim notifikasi ke pusher
        event(new LapakBaruNotif($datas));

        // kirim email pin registrasi
        $pin = Str::random(5);
        $to_name = $request->nama_lapak;
        $to_email = $request->email;
        $data_email = array(
            'nama_owner'=> $request->nama_owner, 
            'nama_lapak'=> $request->nama_lapak, 
            'email'     => $request->email, 
            'pin'       => $pin, 
        );
            
        Mail::send('lapak_konfirm_pin', $data_email, function($pesan) use ($to_name, $to_email) {
            $pesan->to($to_email, $to_name)->subject('Konfirmasi PIN registrasi');
            $pesan->from(env('MAIL_USERNAME','lapak.peduli.covid@gmail.com'),'Lapak Peduli Covid19');
        });
        
        $lapak = new Lapak;
        $lapak->kode_lapak   = $kodelapak;
        $lapak->nama_lapak   = $request->nama_lapak;
        $lapak->nama_owner   = $request->nama_owner;
        $lapak->email        = $request->email;
        $lapak->password     = Hash::make($request->password);
        $lapak->no_kontak    = $request->no_kontak;
        $lapak->alamat       = $request->alamat;
        $lapak->pin          = $pin;
        $lapak->status       = 'menunggu aktivasi';
        
        $lapak->save();

        // return redirect('/login_lapak')->with('pesan', 'Pendaftaran anda menunggu konfirmasi oleh admin,  konfirmasi akan dikirim ke email anda, terima kasih telah bergabung bersama kami');
        return redirect ()->action(
            'PendaftaranController@lapak_pin_registrasi', ['email'=>$request->email]
        );
    }

    public function daftarUserform()
    {
        $kecamatan= Kecamatan::orderBy('nama_kecamatan')->get();
        return view ('user.daftar',compact('kecamatan'));
    }

    public function daftar_user(Request $request)
    {
        if($request->password != $request->konfirmpassword){
            return back()->with('gagal_login','password tidak sama, ulangi kembali!');    
        }
        $request->validate([
            'nama'              => 'required',
            'no_kontak'         => 'required|unique:users,no_kontak',
            'kecamatan_id'      => 'required',
            'alamat'            => 'required',
            'email'             => 'required|unique:users,email',
            'password'          => 'required|min:6',
            'konfirmpassword'   => 'required',
            // 'fotoselfie'        => 'required',
        ]);

        
        $tanggal_sekarang = date('Ymd');
        $jumlahuser = User::count();
        if($jumlahuser < 10){
            $nourut = '000000';
        }elseif($jumlahuser >=10 && $jumlahuser < 100){
            $nourut = '00000';
        }elseif($jumlahuser >=100 && $jumlahuser < 1000){
            $nourut = '0000';
        }elseif($jumlahuser >=1000 && $jumlahuser < 10000){
            $nourut = '000';
        }elseif($jumlahuser >=10000 && $jumlahuser < 100000){
            $nourut = '00';
        }else{
            $nourut = '0';
        }
        $kodeuser = $tanggal_sekarang.''.$nourut.''.$jumlahuser+1;

        $superadmin = Superadmin::first();

        $details = [
            'nama'      => $request->nama,
            'kode_user' => $kodeuser
        ];
        // $details = $request->nama;
        // return ($details);
        Notification::send($superadmin, new NewUser($details));
        // Event(new UserBaruNotif($details));
        event(new UserBaruNotif($details));

        // email pin registrasi
        $pin = Str::random(5);
        $to_name = $request->nama;
        $to_email = $request->email;
        $data_email = array(
            'nama'      => $request->email, 
            'pin'       => $pin, 
        );
            
        Mail::send('konfirm_pin', $data_email, function($pesan) use ($to_name, $to_email) {
            $pesan->to($to_email, $to_name)->subject('Konfirmasi PIN registrasi');
            $pesan->from(env('MAIL_USERNAME','lapak.peduli.covid@gmail.com'),'Lapak Peduli Covid19');
        });
        

        $user = new User;
        $user->kode_user    = $kodeuser;
        $user->nama         = $request->nama;
        $user->email        = $request->email;
        $user->password     = Hash::make($request->password);
        $user->no_kontak    = $request->no_kontak;
        $user->kecamatan_id = $request->kecamatan_id;
        $user->alamat       = $request->alamat;
        $user->pin          = $pin;
        // $user->foto_selfi   = $nama_file;
        $user->status_user  = 'menunggu aktivasi';
        
        $user->save();

        
        return redirect ()->action(
            'PendaftaranController@pin_registrasi', ['email'=>$request->email]
        );
        
        
    }

    public function pin_registrasi($email)
    {
        $customer = User::where('email',$email)->first();

        return view ('user.konfirm_pin',compact('customer'));

    }

    public function lapak_pin_registrasi($email)
    {
        $lapak = Lapak::where('email',$email)->first();

        return view ('lapak.konfirm_pin',compact('lapak'));

    }

    public function entrypin(Request $request)
    {
        $request->validate([
            'pin' => 'required|max:5',
        ]);

        $user = User::where('email',$request->email)->first();
        if($user->pin == $request->pin){
            User::where('id',$user->id)
                ->update([
                    'konfirm_pin' => 'konfirm',
                    'status_user' => 'aktif'
                ]);
            return redirect('/login_user')->with('pesan', 'Terima kasih telah menjadi bagian dari Lapak Peduli Covid19');
        }else{
            return back()->with('Erorr','PIN tidak sesuai'); 
        }
    }

    public function entrypin_lapak(Request $request)
    {
        $request->validate([
            'pin' => 'required|max:5',
        ]);

        $lapak = Lapak::where('email',$request->email)->first();
        if($lapak->pin == $request->pin){
            Lapak::where('id',$lapak->id)
                ->update([
                    'konfirm_pin' => 'konfirm',
                    'status'      => 'aktif'
                ]);
            return redirect('/login_lapak')->with('pesan', 'Terima kasih telah menjadi bagian dari Lapak Peduli Covid19');
        }else{
            return back()->with('Erorr','PIN tidak sesuai'); 
        }
    }
}
