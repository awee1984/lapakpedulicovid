<?php

namespace App\Events;

use Illuminate\Broadcasting\Channel;
use Illuminate\Queue\SerializesModels;
use Illuminate\Broadcasting\PrivateChannel;
use Illuminate\Broadcasting\PresenceChannel;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Contracts\Broadcasting\ShouldBroadcast;
use App\Lapak;


class TransaksiBaruNotif implements ShouldBroadcast
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    // public $event_transaksi;
    public $lapak;
    public $message;
    
    
    public function __construct(Lapak $lapak, $message)
    {
        $this->lapak = $lapak;
        $this->message = $message;
    }

    public function broadcastWith()
    {
        return  array(
            'id_lapak'    => $this->lapak->id,
            'message'       => $this->message
        );
    }

    
    public function broadcastOn()
    {
        // return new PrivateChannel('user.'.$this->message->to);
        // return ['transaksibaru'];
        return new PrivateChannel('lapak.'.$this->lapak->id);
    }

    // public function broadcastAs()
    // {
    //     return 'notif_transaksi';
    // }
}
