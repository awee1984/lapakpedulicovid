<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>Dashboard Pelapak | Lapak Peduli Covid19</title>
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(URL::asset('assets/images/favicon.png')); ?>">

    <!-- Bootstrap core CSS-->
    <link href="<?php echo e(url('/')); ?>/dashboard/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom fonts for this template-->
    <link href="<?php echo e(url('/')); ?>/dashboard/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

    <!-- Page level plugin CSS-->
    <link href="<?php echo e(url('/')); ?>/dashboard/vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="<?php echo e(url('/')); ?>/dashboard/css/sb-admin.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.3.1.js" integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60=" crossorigin="anonymous"></script>
    <script src="https://js.pusher.com/6.0/pusher.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/vue/1.0.18/vue.min.js"></script>
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>

  </head>

  <body id="page-top">

    <nav class="navbar navbar-expand navbar-dark bg-dark static-top">

      <a class="navbar-brand mr-1" href="index.html">Lapak Peduli</a>

      <button class="btn btn-link btn-sm text-white order-1 order-sm-0" id="sidebarToggle" href="#">
        <i class="fas fa-bars"></i>
      </button>

      
      <div class="d-none d-md-inline-block form-inline ml-auto mr-0 mr-md-3 my-2 my-md-0 text-light">
        Hello, <?php echo e(Auth::user()->nama_lapak); ?>

      </div>

      
      <!-- Navbar -->
      

    </nav>

    <div id="wrapper">
      
      <!-- Sidebar -->
      <ul class="sidebar navbar-nav">
        <li class="nav-item active">
          <a class="nav-link" href="<?php echo e(url('/lapak_home')); ?>">
            <i class="fas fa-fw fa-home"></i>
            <span>Beranda</span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(url('/profil_lapak')); ?>">
            <i class="fas fa-address-card"></i>
            <span>Profil Lapak</span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(url('/lapak_produk')); ?>">
            <i class="fas fa-cart-plus"></i>
            <span>Produk</span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(url('/ongkir')); ?>">
            <i class="fas fa-dolly-flatbed"></i>
            <span>Ongkos Kirim</span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(url('/transaksi')); ?>">
            <i class="fas fa-money-bill-alt"></i>
            <span>Transaksi</span>
            <h5 class="badge badge-pill badge-danger" id="transnotif" style="font-size:60%;vertical-align:top;position:relative;"></h5>
              
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" onclick="event.preventDefault(); document.getElementById('logout-form').submit();" href="<?php echo e(url('/logout')); ?>">
            <i class="fas fa-sign-out-alt fa-fw"></i>
            <span>Keluar</span>
          </a>
          <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" >
            <?php echo e(csrf_field()); ?>

          </form>
        </li>
        
        
      </ul><?php /**PATH C:\xampp\htdocs\lapak_peduli\lapak_peduli\resources\views/dashboard/header.blade.php ENDPATH**/ ?>