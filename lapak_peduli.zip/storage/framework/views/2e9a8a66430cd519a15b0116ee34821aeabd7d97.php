<!-- Bootstrap core JavaScript-->
    </div>
  </div>
</div> 
    
<script src="<?php echo e(url('/')); ?>/dashboard/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

<!-- Core plugin JavaScript-->
<script src="<?php echo e(url('/')); ?>/dashboard/vendor/jquery-easing/jquery.easing.min.js"></script>

<!-- Page level plugin JavaScript-->

<script src="<?php echo e(url('/')); ?>/dashboard/vendor/datatables/jquery.dataTables.js"></script>
<script src="<?php echo e(url('/')); ?>/dashboard/vendor/datatables/dataTables.bootstrap4.js"></script>

<!-- Custom scripts for all pages-->
<script src="<?php echo e(url('/')); ?>/dashboard/js/sb-admin.min.js"></script>


<!-- Demo scripts for this page-->
<script src="<?php echo e(url('/')); ?>/dashboard/js/demo/datatables-demo.js"></script>

<script src="<?php echo e(url('/')); ?>/assets/myscript.js"></script>

</body>

</html><?php /**PATH C:\xampp\htdocs\lapak_peduli\lapak_peduli\resources\views/dashboard/superadminfooter.blade.php ENDPATH**/ ?>