@include('dashboard.superadminheader')
      

<div class="row">
  <div class="col-xl-4 col-sm-4 mb-4">
    <div class="card text-white bg-primary o-hidden h-100">
      <div class="card-body">
        <div class="card-body-icon">
          <i class="fas fa-fw fa-shopping-bag"></i>
          {{-- <i class="fas fa-fw fa-comments"></i> --}}
        </div>
        <div class="mr-5" style="font-size:24pt;">{{$jumlah_lapak}}</div>
      </div>
      <div class="card-footer">
        <h5>LAPAK <a href="{{url('/lapak_superadmin')}}" id="notif_lapak" class="badge badge-pill badge-warning" style="font-size:60%;vertical-align:top"></a></h5>
      </div>
    </div>
  </div>

  <div class="col-xl-4 col-sm-4 mb-4">
    <div class="card text-white bg-success o-hidden h-100">
      <div class="card-body">
        <div class="card-body-icon">
          <i class="fas fa-fw fa-users"></i>
          {{-- <i class="fas fa-fw fa-comments"></i> --}}
        </div>
        <div class="mr-5" style="font-size:24pt;">{{$jumlah_user}}</div>
      </div>
      <div class="card-footer">
        <h5>CUSTOMER <a href="{{url('/user_superadmin')}}" id="notif" class="badge badge-pill badge-warning" style="font-size:60%;vertical-align:top"></a></h5>
      </div>
    </div>
  </div>

  <div class="col-xl-4 col-sm-4 mb-4">
    <div class="card text-white bg-warning o-hidden h-100">
      <div class="card-body">
        <div class="card-body-icon">
          <i class="fas fa-fw fa-shopping-bag"></i>
          {{-- <i class="fas fa-fw fa-comments"></i> --}}
        </div>
        <div class="mr-5" style="font-size:24pt;">{{$jumlah_produk}}</div>
      </div>
      <div class="card-footer">
        <h5>PRODUK</h5>
      </div>
    </div>
  </div>
</div>
          
          
          {{-- @foreach (auth()->user()->unreadNotifications as $notifications)
          <div class="alert alert-primary" role="alert">
            Pendaftaran User Baru {{$notifications->data['nama_user']}}
          
          @endforeach --}}

{{-- <div id="notif"></div> --}}
          
          
grafik transaksi

        
    
@include('dashboard.superadminfooter')