<?php

namespace App\Http\Controllers\Auth;

use App\User;
use App\Kecamatan;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use App\Mail\LapakpeduliEmail;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Hash;

class AuthController extends Controller
{

    public function listkecamatan(){
        return response()->json(DB::table('kecamatans')
            ->orderBy('nama_kecamatan')
            ->get(),200);
    }

    public function login(Request $request) {
        $request->validate([
            'email' => 'required|string|email',
            'password' => 'required|string',
            //'remember_me' => 'boolean'
        ]);
        $credentials = request(['email', 'password']);
        if(!Auth::attempt($credentials))
            return response()->json([
                'message' => 'Unauthorized'
            ], 401);
        $user = $request->user();
        $tokenResult = $user->createToken('Personal Access Token');
        $token = $tokenResult->token;
        if ($request->remember_me)
            $token->expires_at = Carbon::now()->addWeeks(1);
        $token->save();
        return response()->json([
            'access_token' => $tokenResult->accessToken,
            'token_type' => 'Bearer',
            'expires_at' => Carbon::parse(
                $tokenResult->token->expires_at
            )->toDateTimeString()
        ]);
    }
    public function register(Request $request)
    {
        $request->validate([
            'nama'          => 'required|string',
            'no_kontak'     => 'required',
            'kecamatan_id'  => 'required',
            'alamat'        => 'required|string',
            'email'         => 'required|string|email|unique:users,email',
            'password'      => 'required|string'
        ]);

        $tanggal_sekarang = date('Ymd');
        $jumlahuser = User::count();
        if($jumlahuser < 10){
            $nourut = '000000';
        }elseif($jumlahuser >=10 && $jumlahuser < 100){
            $nourut = '00000';
        }elseif($jumlahuser >=100 && $jumlahuser < 1000){
            $nourut = '0000';
        }elseif($jumlahuser >=1000 && $jumlahuser < 10000){
            $nourut = '000';
        }elseif($jumlahuser >=10000 && $jumlahuser < 100000){
            $nourut = '00';
        }else{
            $nourut = '0';
        }
        $kodeuser = $tanggal_sekarang.''.$nourut.''.$jumlahuser+1;

        $pin = Str::random(5);
        $to_name = $request->nama;
        $to_email = $request->email;
        $data_email = array(
            'nama'      => $request->email, 
            'pin'       => $pin, 
        );
            
        Mail::send('konfirm_pin', $data_email, function($pesan) use ($to_name, $to_email) {
            $pesan->to($to_email, $to_name)->subject('Konfirmasi PIN registrasi');
            $pesan->from(env('MAIL_USERNAME','lapak.peduli.covid@gmail.com'),'Lapak Peduli Covid19');
        });

        $user = new User;
        $user->kode_user    = $kodeuser;
        $user->nama         = $request->nama;
        $user->email        = $request->email;
        $user->password     = Hash::make($request->password);
        $user->no_kontak    = $request->no_kontak;
        $user->kecamatan_id = $request->kecamatan_id;
        $user->alamat       = $request->alamat;
        $user->pin          = $pin;
        // $user->foto_selfi   = $nama_file;
        $user->status_user  = 'menunggu aktivasi';
        
        $user->save();

        return response()->json([
            'message' => 'Registrasi berhasil, silahkan cek email anda'
        ], 201);
    }

    public function konfirmpin(Request $request)
    {
        $request->validate([
            'email' => 'required|string',
            'pin'   => 'required|string|max:5',
        ]);

        $user = User::where('email',$request->email)->first();
        if($user->pin == $request->pin){
            User::where('id',$user->id)
                ->update([
                    'konfirm_pin' => 'konfirm',
                    'status_user' => 'aktif'
                ]);
            return response()->json([
                'message' => 'PIN dikonfirmasi, Terima kasih telah menjadi bagian dari Lapak Peduli Covid19'
            ], 201);
        }else{
            return response()->json([
                'message' => 'Gagal, PIN tidak sesuai'
            ], 401); 
        }
    }

    public function list_produk()
    {
        return response()->json(DB::table('produks')
            ->join('lapaks','produks.lapak_id','lapaks.id')
            ->orderBy('produks.priority','desc')
            ->get(),200);
    }

    public function kategori()
    {
        return response()->json(DB::table('kategoris')
            ->get(),200);
    }

    public function advertise()
    {
        return response()->json(DB::table('advertises')
            ->get(),200);
    }

    public function caribykategori(Request $request)
    {
        
        return response()->json(DB::table('produks')
        ->join('kategoris','produks.kategori_id','kategoris.id')
        ->where('status_produk','tersedia')
        ->where('kategoris.id',$request->kategori)
        // ->where('lapaks.nama_lapak','LIKE',"%{$request->cari}%")
        ->orderBy('produks.priority','desc')
        ->get(),200);
        
        
    }

    public function logout(Request $request)
    {
        $request->user()->token()->revoke();
        return response()->json([
            'message' => 'Berhasil Logout'
        ]);
    }
  
    /**
     * Get the authenticated User
     *
     * @return [json] user object
     */
    public function user(Request $request)
    {
        return response()->json($request->user());
    }
}
