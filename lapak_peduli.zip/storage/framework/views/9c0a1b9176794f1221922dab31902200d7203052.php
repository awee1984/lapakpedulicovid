<?php echo $__env->make('dashboard.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div id="content-wrapper">
  <div class="container-fluid">
    <ol class="breadcrumb bg-dark" style="box-shadow:0px 0px 8px #0000001a;">
      <li class="breadcrumb-item">
        <a class="text-light" href="#">Data Umum</a>
      </li>
      <li class="breadcrumb-item active text-light">Data Lapak</li>
    </ol>
    <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#tambahprodukModal">
      Tambah produk
    </button>
    
    <br><br>
    <div class="row">
      <div class="col-lg-12">
        <?php if(session('status')): ?>
          <div class="alert alert-success">
              <?php echo e(session('status')); ?>

          </div>
        <?php endif; ?>
      </div>
    </div>
    <!-- DataTables Example -->
    

    <!-- tambah produk Modal -->
    

    <!-- edit produk Modal -->
    <div class="modal fade " id="editprodukModal" tabindex="-1" role="dialog" aria-labelledby="#editprodukModalTitle" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="editprodukModalTitle">Tambah Produk</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <form action="<?php echo e(url('/produk_tambah')); ?>" method="post" enctype="multipart/form-data">
            <?php echo method_field('patch'); ?>
            <?php echo csrf_field(); ?>
            <div class="modal-body">
              <div class="row">
                <div class="col-12">
                  <div class="row">
                    <div class="col-6">
                      <div class="form-group">
                        <select name="kategori_id" id="kategori" class="form-control" >
                          <option value="">-- Pilih Kategori --</option>    
                          
                        </select>
                        <?php if ($errors->has('kategori_id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('kategori_id'); ?>
                        <span class="help-block text-danger">Wajib diisi</span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                      </div>
                      <div class="form-group">
                        <input type="text" name="nama_produk" id="nama_produk" class="form-control" placeholder="Nama Produk" value="<?php echo e(old('nama_produk')); ?>">
                        <?php if ($errors->has('nama_produk')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nama_produk'); ?>
                        <span class="help-block text-danger">Wajib diisi</span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                      </div>
                      <div class="form-group">
                        <input type="text" name="satuan" id="satuan" class="form-control" placeholder="Satuan" value="<?php echo e(old('satuan')); ?>">
                        <?php if ($errors->has('satuan')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('satuan'); ?>
                        <span class="help-block text-danger">Wajib diisi</span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                      </div>
                      <div class="form-group">
                        <input type="number" name="stok" id="stok" class="form-control" placeholder="Jumlah Stok" value="<?php echo e(old('stok')); ?>">
                        <?php if ($errors->has('stok')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('stok'); ?>
                        <span class="help-block text-danger">Wajib diisi</span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                      </div>
                      <div class="form-group">
                        <input type="number" name="harga" id="harga" class="form-control" placeholder="Harga" value="<?php echo e(old('harga')); ?>">
                        <?php if ($errors->has('harga')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('harga'); ?>
                        <span class="help-block text-danger">Wajib diisi</span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                      </div>
                      <div class="form-group">
                        <textarea name="deskripsi_produk" id="deskripsi_produk" rows="5" class="form-control" placeholder="Deskripsi produk" value="<?php echo e(old('deskripsi_produk')); ?>"></textarea>
                        <?php if ($errors->has('deskripsi_produk')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('deskripsi_produk'); ?>
                        <span class="help-block text-danger">Wajib diisi</span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                      </div>
                    </div>
                    <div class="col-6">
                      <img width="300" id="previewing"  src="" class="img-responsive">
                      <br><br>
                      
                      <input type="file" name="gambar" id="file" />
                      <div id="message"></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="modal-footer">
              <button type="submit" class="btn btn-success btn-sm">Simpan</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>

  

  <!-- Sticky Footer -->
  <footer class="sticky-footer">
    <div class="container my-auto">
      <div class="copyright text-center my-auto">
        <span>Copyright © Lapak_Peduli_Covid19 2020</span>
      </div>
    </div>
  </footer>
</div>
<?php echo $__env->make('dashboard.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lapak_peduli\lapak_peduli\resources\views/dashboard/data_lapak.blade.php ENDPATH**/ ?>