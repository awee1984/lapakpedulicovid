<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Dashboard Pelapak | Lapak Peduli Covid19</title>
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(URL::asset('assets/images/favicon.png')); ?>">

    <!-- Bootstrap core CSS-->
    <link href="<?php echo e(url('/')); ?>/dashboard/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom fonts for this template-->
    <link href="<?php echo e(url('/')); ?>/dashboard/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

    <!-- Page level plugin CSS-->
    <link href="<?php echo e(url('/')); ?>/dashboard/vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="<?php echo e(url('/')); ?>/dashboard/css/sb-admin.css" rel="stylesheet">
    
    <script src="https://code.jquery.com/jquery-3.3.1.js" integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60=" crossorigin="anonymous"></script>
    <script src="https://js.pusher.com/6.0/pusher.min.js"></script>

  </head>

  <body id="page-top">

    <nav class="navbar navbar-expand navbar-dark bg-dark static-top">

      

      
      
      

      <!-- Navbar -->
      <ul class="navbar-nav ml-auto ml-md-0 nav justify-content-end" >
        <li class="nav-item dropdown no-arrow">
          <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            Hello, Super Admin 
          </a>
          <div class="dropdown-menu dropdown-menu-right" aria-labelledby="userDropdown">
            <a class="dropdown-item" onclick="event.preventDefault(); document.getElementById('logout-form').submit();" href="<?php echo e(url('/logout')); ?>">Keluar</a>
            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" >
              <?php echo e(csrf_field()); ?>

            </form>
            
          </div>
        </li>
      </ul>

    </nav>

    <div id="wrapper">
      
      <!-- Sidebar -->
      <ul class="sidebar navbar-nav">
        <li class="nav-item active">
          <a class="nav-link" href="<?php echo e(url('/superadmin_home')); ?>">
            <i class="fas fa-fw fa-home"></i>
            <span>Beranda</span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(url('/lapak_superadmin')); ?>">
            <i class="fas fa-fw fa-store"></i>
            <span>Lapak </span> 
            <h5 class="badge badge-pill badge-danger" id="lapaknotification" style="font-size:60%;vertical-align:top;position:relative;"></h5>
            
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(url('/user_superadmin')); ?>">
            <i class="fas fa-fw fa-users"></i>
            <span>Customer</span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">
            <i class="fas fa-barcode"></i>
            <span>Produk</span>
          </a>
        </li>
      </ul>

      <div id="content-wrapper">
        <div class="container-fluid"><?php /**PATH C:\xampp\htdocs\lapak_peduli\lapak_peduli\resources\views/dashboard/superadminheader.blade.php ENDPATH**/ ?>