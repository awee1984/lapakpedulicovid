    
    
    <!-- Bootstrap core JavaScript-->
    <script src="<?php echo e(url('/')); ?>/dashboard/vendor/jquery/jquery.min.js"></script>
    <script src="<?php echo e(url('/')); ?>/dashboard/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="<?php echo e(url('/')); ?>/dashboard/vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Page level plugin JavaScript-->
    <script src="<?php echo e(url('/')); ?>/dashboard/vendor/chart.js/Chart.min.js"></script>
    <script src="<?php echo e(url('/')); ?>/dashboard/vendor/datatables/jquery.dataTables.js"></script>
    <script src="<?php echo e(url('/')); ?>/dashboard/vendor/datatables/dataTables.bootstrap4.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="<?php echo e(url('/')); ?>/dashboard/js/sb-admin.min.js"></script>
    
    
    <!-- Demo scripts for this page-->
    
    <script src="<?php echo e(url('/')); ?>/assets/myscript.js"></script>



<script>
  Echo.private(`lapak.<?php echo e(Auth::id()); ?>`)
  // .listen('StatustransNotif', (e) => {
  .listen('TransaksiBaruNotif', (e) => {
      // console.log(e);
      // $("#notif_status_order").show();
    $("#transnotif").text("*");
    $("#transnotif1").text("*");
    // $("#notransnya").text("" + notrans + "");
  });
</script>

<script>
  Echo.private(`lapak.<?php echo e(Auth::id()); ?>`)
  // .listen('StatustransNotif', (e) => {
  .listen('BuktiTransferNotif', (e) => {
      // console.log(e);
      // $("#notif_status_order").show();
    $("#transnotif").text("*");
    $("#transnotif1").text("*");
    // $("#notransnya").text("" + notrans + "");
  });
</script>

  </body>

</html><?php /**PATH C:\xampp\htdocs\lapak_peduli\lapak_peduli\resources\views/dashboard/footer.blade.php ENDPATH**/ ?>