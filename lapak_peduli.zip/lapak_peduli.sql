-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 15 Nov 2021 pada 09.51
-- Versi server: 10.4.8-MariaDB
-- Versi PHP: 7.3.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lapak_peduli`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `advertises`
--

CREATE TABLE `advertises` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `lapak_id` int(11) NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tgl_entry` date NOT NULL,
  `durasi` int(11) NOT NULL,
  `tgl_expired` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `advertises`
--

INSERT INTO `advertises` (`id`, `lapak_id`, `image`, `tgl_entry`, `durasi`, `tgl_expired`, `created_at`, `updated_at`) VALUES
(1, 4, 'banner1.jpg', '2020-05-15', 1, '2020-05-22', '2020-05-15 15:27:45', '2020-05-15 15:27:45'),
(2, 5, 'banner2.jpg', '2020-05-15', 1, '2020-05-22', '2020-05-15 15:27:45', '2020-05-15 15:27:45'),
(3, 7, 'banner3.jpg', '2020-05-15', 1, '2020-05-22', '2020-05-15 15:27:45', '2020-05-15 15:27:45');

-- --------------------------------------------------------

--
-- Struktur dari tabel `banks`
--

CREATE TABLE `banks` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nama_bank` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `banks`
--

INSERT INTO `banks` (`id`, `nama_bank`, `created_at`, `updated_at`) VALUES
(1, 'BANK SULTRA', '2020-04-25 03:02:05', '2020-04-25 03:02:05'),
(2, 'BANK MANDIRI', '2020-04-25 03:02:05', '2020-04-25 03:02:05'),
(3, 'BANK BNI', '2020-04-25 03:02:05', '2020-04-25 03:02:05'),
(4, 'BANK BRI', '2020-04-25 03:02:05', '2020-04-25 03:02:05'),
(5, 'BANK BTN', '2020-04-25 03:02:05', '2020-04-25 03:02:05'),
(6, 'BANK MUAMALAT', '2020-04-25 03:02:05', '2020-04-25 03:02:05');

-- --------------------------------------------------------

--
-- Struktur dari tabel `carts`
--

CREATE TABLE `carts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tanggal_order` date NOT NULL,
  `user_id` int(11) NOT NULL,
  `produk_id` int(11) NOT NULL,
  `lapak_id` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `request_khusus` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `metode_bayar` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `carts`
--

INSERT INTO `carts` (`id`, `tanggal_order`, `user_id`, `produk_id`, `lapak_id`, `qty`, `request_khusus`, `metode_bayar`, `created_at`, `updated_at`) VALUES
(2, '2020-05-20', 4, 19, 4, 4, NULL, 'transfer', '2020-05-20 06:51:05', '2020-05-20 07:09:06');

-- --------------------------------------------------------

--
-- Struktur dari tabel `kategoris`
--

CREATE TABLE `kategoris` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nama_kategori` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `kategoris`
--

INSERT INTO `kategoris` (`id`, `nama_kategori`, `created_at`, `updated_at`) VALUES
(1, 'alat rumah tangga', '2020-04-22 08:43:53', '2020-04-22 08:43:53'),
(2, 'anak', '2020-04-22 08:43:53', '2020-04-22 08:43:53'),
(3, 'alat tulis kantor & sekolah', '2020-04-22 08:43:53', '2020-04-22 08:43:53'),
(4, 'elektronik', '2020-04-22 08:43:53', '2020-04-22 08:43:53'),
(5, 'fashion', '2020-04-22 08:43:53', '2020-04-22 08:43:53'),
(6, 'handphone', '2020-04-22 08:43:53', '2020-04-22 08:43:53'),
(7, 'ibu & bayi', '2020-04-22 08:43:53', '2020-04-22 08:43:53'),
(8, 'kesehatan', '2020-04-22 08:43:53', '2020-04-22 08:43:53'),
(9, 'makanan & minuman', '2020-04-23 04:01:52', '2020-04-23 04:01:52'),
(10, 'olahraga', '2020-04-22 08:43:53', '2020-04-22 08:43:53'),
(11, 'sembako', '2020-04-22 08:43:53', '2020-04-22 08:43:53'),
(12, 'serba-serbi', '2020-04-22 08:43:53', '2020-04-22 08:43:53');

-- --------------------------------------------------------

--
-- Struktur dari tabel `kecamatans`
--

CREATE TABLE `kecamatans` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nama_kecamatan` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `kecamatans`
--

INSERT INTO `kecamatans` (`id`, `nama_kecamatan`, `created_at`, `updated_at`) VALUES
(1, 'Kolaka', '2020-04-28 14:28:53', '2020-04-28 14:28:53'),
(2, 'Latambaga', '2020-04-28 14:28:53', '2020-04-28 14:28:53'),
(3, 'Wundulako', '2020-04-28 14:28:53', '2020-04-28 14:28:53'),
(4, 'Baula', '2020-04-28 14:28:53', '2020-04-28 14:28:53'),
(5, 'Pomalaa', '2020-04-28 14:28:53', '2020-04-28 14:28:53'),
(6, 'Tanggetada', '2020-04-28 14:28:53', '2020-04-28 14:28:53'),
(7, 'Polinggona', '2020-04-28 14:28:53', '2020-04-28 14:28:53'),
(8, 'Watubangga', '2020-04-28 14:28:53', '2020-04-28 14:28:53'),
(9, 'Toari', '2020-04-28 14:28:53', '2020-04-28 14:28:53'),
(10, 'Samaturu', '2020-04-28 14:28:53', '2020-04-28 14:28:53'),
(11, 'Wolo', '2020-04-28 14:28:53', '2020-04-28 14:28:53'),
(12, 'Iwoimendaa', '2020-04-28 14:28:53', '2020-04-28 14:28:53');

-- --------------------------------------------------------

--
-- Struktur dari tabel `lapaks`
--

CREATE TABLE `lapaks` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `kode_lapak` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nama_lapak` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nama_owner` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `no_kontak` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `alamat` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `waktu_buka` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `waktu_tutup` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bank_id` int(11) DEFAULT NULL,
  `no_rekening` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `backdrop` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pin` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `konfirm_pin` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `lapaks`
--

INSERT INTO `lapaks` (`id`, `kode_lapak`, `nama_lapak`, `nama_owner`, `email`, `email_verified_at`, `password`, `no_kontak`, `alamat`, `waktu_buka`, `waktu_tutup`, `bank_id`, `no_rekening`, `backdrop`, `pin`, `konfirm_pin`, `status`, `remember_token`, `created_at`, `updated_at`) VALUES
(4, '20200505000001', 'Bara\'s Store', 'Ahmad Al Barra', 'bara.zaafarani@gmail.com', NULL, '$2y$10$FMGS/EskklTu9JMK48f98eJAIJWAp5poyN24HyeTkB1DN8ltcF8Jy', '323232354546', 'Jl. Ahmad Mustin I No. 187', '09.00', '22.00', 4, '02.002.103', '1588679556_5969c124d4bacb8730b819b2ee8ee96c.jpg', 'CzDDE', 'konfirm', 'aktif', NULL, '2020-05-05 00:50:57', '2020-05-05 03:52:36'),
(5, '20200505000002', 'Hannin Cake', 'Hanin Zahirah', 'hanin@mail.com', NULL, '$2y$10$uVtuzlVYQoHCtT17qOzwpupPONjJoa7UZMzrdlKT4FfF4Tx4.dSse', '33232', 'Jl. Nanggomba No. 24 Kel. Silea', NULL, NULL, NULL, NULL, NULL, '4RHMW', 'konfirm', 'aktif', NULL, '2020-05-05 01:18:55', '2020-05-05 01:20:24'),
(7, '20200505000003', 'Aina Store', 'Raniah Zara Zaina', 'aina@mail.com', NULL, '$2y$10$4ZqZwdGf2sp5dOeTmkxV5.c7vkFGcMDWx89y9QnXdV0alApyxp6ta', '025552232332', 'Jl. Nanggomba No. 24 Kel. Silea', '08.00', '17.30', 4, '002.0021.013330.0', NULL, 'KjoR9', 'konfirm', 'aktif', NULL, '2020-05-05 03:19:33', '2020-05-10 03:43:36');

-- --------------------------------------------------------

--
-- Struktur dari tabel `messages`
--

CREATE TABLE `messages` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `from` int(10) UNSIGNED NOT NULL,
  `to` int(10) UNSIGNED NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `messages`
--

INSERT INTO `messages` (`id`, `from`, `to`, `message`, `created_at`, `updated_at`) VALUES
(1, 1, 2, 'Status transaksi', '2020-05-06 06:23:53', '2020-05-06 06:23:53'),
(2, 1, 2, 'Status transaksi', '2020-05-06 06:25:06', '2020-05-06 06:25:06'),
(3, 1, 2, 'Status transaksi', '2020-05-06 06:25:16', '2020-05-06 06:25:16'),
(4, 1, 2, 'Status transaksi', '2020-05-06 06:25:34', '2020-05-06 06:25:34'),
(5, 4, 2, 'Status transaksi', '2020-05-06 06:29:22', '2020-05-06 06:29:22'),
(6, 4, 2, 'Status transaksi', '2020-05-06 06:39:13', '2020-05-06 06:39:13'),
(7, 4, 2, 'Status transaksi', '2020-05-06 06:39:49', '2020-05-06 06:39:49'),
(8, 4, 2, 'Status transaksi', '2020-05-06 06:42:09', '2020-05-06 06:42:09'),
(9, 4, 2, 'Status transaksi', '2020-05-06 06:45:05', '2020-05-06 06:45:05'),
(10, 4, 2, 'Status transaksi', '2020-05-06 06:45:45', '2020-05-06 06:45:45'),
(11, 4, 2, 'Status transaksi', '2020-05-06 06:48:18', '2020-05-06 06:48:18');

-- --------------------------------------------------------

--
-- Struktur dari tabel `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(3, '2014_10_12_000000_create_users_table', 1),
(4, '2014_10_12_100000_create_password_resets_table', 1),
(5, '2020_04_22_083332_create_produks_table', 2),
(6, '2020_04_22_083842_create_kategoris__table', 2),
(7, '2020_04_23_041534_create_lapaks_table', 3),
(8, '2020_04_25_025912_create_banks_table', 4),
(9, '2020_04_27_085815_create_carts_table', 5),
(10, '2020_04_28_141614_create_ongkirs_table', 6),
(11, '2020_04_28_141942_create_kecamatans_table', 6),
(12, '2020_04_28_162949_create_superadmins_table', 7),
(13, '2020_04_29_063507_create_transaksis_table', 8),
(14, '2020_05_01_055015_create_notifications_table', 9),
(15, '2020_05_06_140423_create_messages_table', 10),
(16, '2016_06_01_000001_create_oauth_auth_codes_table', 11),
(17, '2016_06_01_000002_create_oauth_access_tokens_table', 11),
(18, '2016_06_01_000003_create_oauth_refresh_tokens_table', 11),
(19, '2016_06_01_000004_create_oauth_clients_table', 11),
(20, '2016_06_01_000005_create_oauth_personal_access_clients_table', 11),
(21, '2020_05_15_152451_create_advertises_table', 12);

-- --------------------------------------------------------

--
-- Struktur dari tabel `notifications`
--

CREATE TABLE `notifications` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_id` bigint(20) UNSIGNED NOT NULL,
  `data` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `notifications`
--

INSERT INTO `notifications` (`id`, `type`, `notifiable_type`, `notifiable_id`, `data`, `read_at`, `created_at`, `updated_at`) VALUES
('109a5c4f-4947-47cd-9c76-876ebc2db0cc', 'App\\Notifications\\NewUser', 'App\\Superadmin', 1, '{\"nama\":\"aswik\",\"kode_user\":202005040000001}', NULL, '2020-05-04 07:15:23', '2020-05-04 07:15:23'),
('1b0e2043-1c65-4d0d-8f75-9d0974a10a23', 'App\\Notifications\\NewUser', 'App\\Superadmin', 1, '{\"nama\":\"kiking\",\"kode_user\":202005090000003}', NULL, '2020-05-09 08:07:42', '2020-05-09 08:07:42'),
('23b78fc6-66bd-45d0-a46f-1f4d224268b1', 'App\\Notifications\\NewUser', 'App\\Superadmin', 1, '{\"nama\":\"alwan\",\"kode_user\":202005040000009}', NULL, '2020-05-04 05:42:19', '2020-05-04 05:42:19'),
('287b955d-3e28-4efd-8b15-3ec10438d748', 'App\\Notifications\\NewUser', 'App\\Superadmin', 1, '{\"nama_user\":\"kiking\"}', '2020-05-02 06:06:04', '2020-05-02 05:43:49', '2020-05-02 06:06:04'),
('30b15f85-fdd6-48fe-913a-8149709936d5', 'App\\Notifications\\NewUser', 'App\\Superadmin', 1, '{\"nama_user\":\"afsal\"}', '2020-05-02 06:16:29', '2020-05-02 06:16:11', '2020-05-02 06:16:29'),
('771ac484-f8f3-4c08-b947-89feb1fce4ba', 'App\\Notifications\\NewUser', 'App\\Superadmin', 1, '{\"nama\":\"nara\",\"kode_user\":202005040000009}', NULL, '2020-05-04 06:29:39', '2020-05-04 06:29:39'),
('7c532c6f-dbeb-444a-a16e-ffc6a775992c', 'App\\Notifications\\NewUser', 'App\\Superadmin', 1, '{\"nama\":\"arkan\",\"kode_user\":202005040000007}', NULL, '2020-05-04 05:49:32', '2020-05-04 05:49:32'),
('9a129535-9e8c-4a16-8a86-add893573c68', 'App\\Notifications\\NewUser', 'App\\Superadmin', 1, '{\"nama\":\"afsal\",\"kode_user\":202005040000007}', NULL, '2020-05-04 05:38:51', '2020-05-04 05:38:51'),
('9d24e183-0be9-4171-a5f4-8d0a098c3fa3', 'App\\Notifications\\NewUser', 'App\\Superadmin', 1, '{\"nama\":\"arkan\",\"kode_user\":202005040000008}', NULL, '2020-05-04 05:40:59', '2020-05-04 05:40:59'),
('9f66a0b4-a047-4eb5-95fe-fa8fd3ec0517', 'App\\Notifications\\NewUser', 'App\\Superadmin', 1, '{\"nama\":\"kiking\",\"kode_user\":202005040000006}', NULL, '2020-05-04 05:48:41', '2020-05-04 05:48:41'),
('b5b5326a-706b-447f-b88e-62c7d86d11f0', 'App\\Notifications\\NewUser', 'App\\Superadmin', 1, '{\"nama\":\"bara\",\"kode_user\":202005040000002}', NULL, '2020-05-04 07:58:04', '2020-05-04 07:58:04'),
('cc27e81d-673d-40c7-bd99-407dd70ca0cf', 'App\\Notifications\\NewUser', 'App\\Superadmin', 1, '{\"nama\":\"aswik\",\"kode_user\":202005040000001}', NULL, '2020-05-04 07:35:09', '2020-05-04 07:35:09'),
('dd470456-000a-4df6-83a0-7760eacdda96', 'App\\Notifications\\NewUser', 'App\\Superadmin', 1, '{\"nama\":\"itong\",\"kode_user\":202005040000008}', NULL, '2020-05-04 06:26:18', '2020-05-04 06:26:18');

-- --------------------------------------------------------

--
-- Struktur dari tabel `oauth_access_tokens`
--

CREATE TABLE `oauth_access_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `client_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `oauth_access_tokens`
--

INSERT INTO `oauth_access_tokens` (`id`, `user_id`, `client_id`, `name`, `scopes`, `revoked`, `created_at`, `updated_at`, `expires_at`) VALUES
('0086c452d8fa4d35eb92b24cf593386cffe1043fa87a3783174baa023ddd17f3fedae93af04edc80', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 07:45:23', '2020-05-16 07:45:23', '2021-05-16 15:45:23'),
('0102927afa0b7056afab298d6f9aa230cde9d65b967e419cfa1186d1566670d2029ca5543badb8c8', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 05:59:51', '2020-05-15 05:59:51', '2021-05-15 13:59:51'),
('013c2547ff78b4fcb368bdf233568dd932d29d52c244a374e231aac54f933ad083ed167ffd8689ca', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-16 05:13:20', '2020-05-16 05:13:20', '2021-05-16 13:13:20'),
('01d88275737ef55d4f5853a53b8a3c57642ff14b984410aa479583f22325e517fb8017c3654fef86', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 05:18:26', '2020-05-16 05:18:26', '2021-05-16 13:18:26'),
('0296086f6b339be079ecbd35646e4e4b1a1e6c03bc83256a5999c67f2d10f85fa00e9df277997930', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-18 00:19:43', '2020-05-18 00:19:43', '2021-05-18 08:19:43'),
('0329883b21fc6fa0685001f43c6e46876e80240c42725438785963ade56a1df8756a90e19a005019', 4, 1, 'Personal Access Token', '[]', 0, '2020-06-01 20:04:59', '2020-06-01 20:04:59', '2021-06-02 04:04:59'),
('035cefc9e2149d6fed3579e34ed5ca803232dfc320ce1a7c1aee03b5557824bed04de2d369c22e3e', 4, 1, 'Personal Access Token', '[]', 0, '2020-06-01 20:12:05', '2020-06-01 20:12:05', '2021-06-02 04:12:05'),
('0376c63dd4907a68a18e482d21117d08ae1c799684d03b7a4f45c08cd52815f76b1114da73252f59', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-14 23:50:29', '2020-05-14 23:50:29', '2021-05-15 07:50:29'),
('040eb36c1040e59bfaff360a1c5ec5545e2cf3ecc0f8be86907d94ae2e422337d201f14acb11e506', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-16 05:09:57', '2020-05-16 05:09:57', '2021-05-16 13:09:57'),
('045d5ec11da1238e6d24b444bd62ede5d35199b3390844bcdc9f0d36815702c0104640e580f80f8f', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 05:40:58', '2020-05-15 05:40:58', '2021-05-15 13:40:58'),
('04729c0cd5996dd9f7a8bf3889694b969e2639609db7ab63ff907c4662ef666722074aeaea97b6c5', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 07:13:58', '2020-05-16 07:13:58', '2021-05-16 15:13:58'),
('054408ab1e9606c7e32cc82db0f1941647cec922c00ff36f4fa2ddbb6da5fbb495ed9bc171bf0c16', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 05:16:00', '2020-05-16 05:16:00', '2021-05-16 13:16:00'),
('0618b0a09911fe6646670c84ddc6afa3adc9eb18b070e37e47e089ac74732e8f537edb2c45bcca1b', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 05:54:26', '2020-05-16 05:54:26', '2021-05-16 13:54:26'),
('08a01bc9d3afa6646e1f6c62dc2a92bfa33e0158d8c10cb286423d5ff7a7c30142d4f412baa3633d', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 06:46:27', '2020-05-16 06:46:27', '2021-05-16 14:46:27'),
('095959944a97765cee7f1f45eb30d92b7262a8e3afb6ae11887716ca2d4425ecdc0577505de84293', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 06:20:09', '2020-05-16 06:20:09', '2021-05-16 14:20:09'),
('099f260f094397c4537a46e8c3d2a5497f4d6ddbe5472172fc45cdd54cd1a226da6d7bc7d0b84bdd', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 22:15:36', '2020-05-15 22:15:36', '2021-05-16 06:15:36'),
('0a02d1e85a471994c68f01c5884f4faff20ca3699951b4a41a289596016f580a0511267b428dcfb9', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-17 23:53:19', '2020-05-17 23:53:19', '2021-05-18 07:53:19'),
('0b74018f2367bbc2a852f96749704c2bc3073a7b17395a6a1af2312926dc20b9ba4fbd593b395680', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-16 04:54:38', '2020-05-16 04:54:38', '2021-05-16 12:54:38'),
('0b81bba9127bb7d84178f1cf8e481959bdb8a2421e3587e770032b36ec07634c8ffbbefd5a1be1b0', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-16 04:06:56', '2020-05-16 04:06:56', '2021-05-16 12:06:56'),
('0c33e4c75280bbb1ddc9abc2ce2375718640ae23187cc9da4284eb1624fdd35e49c3783421c47ac3', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-16 04:59:46', '2020-05-16 04:59:46', '2021-05-16 12:59:46'),
('0c3828aefd571e2c87bca58bf63b815601b0972bb948d516bf5f169a98c0e5b93bd3e7cb09c7c318', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 07:52:47', '2020-05-16 07:52:47', '2021-05-16 15:52:47'),
('0c5c26569ebcd9295075d55e4680f0370baf7d20be9b370148ec4c57663288b5e1d3242765404848', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-17 06:36:46', '2020-05-17 06:36:46', '2021-05-17 14:36:46'),
('0c6997f68478143fa65974befd930d8f5bfc0c302aa0e98d13b3c3af3476cee873ed2a5d7041caad', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 06:29:34', '2020-05-15 06:29:34', '2021-05-15 14:29:34'),
('0d42eaf84947cf482bccf3f2d5df7dd504510fa832f6c95e6b351f974bc0a39da3e5ce5887d7198a', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-14 23:52:10', '2020-05-14 23:52:10', '2021-05-15 07:52:10'),
('0dc2337293061b1f80b2f391bc3ef01fbc01479caa042b73b33248451581dea17738926a1d2ef845', 4, 1, 'Personal Access Token', '[]', 0, '2020-06-01 20:08:47', '2020-06-01 20:08:47', '2021-06-02 04:08:47'),
('0f1e2bea90a1e2831d5d595c91cdb1d0a6a6731e2207b2d62824a6b801c0ceea6b5d481c5b257232', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 06:23:31', '2020-05-16 06:23:31', '2021-05-16 14:23:31'),
('0f93505f56105aed922850e5d7de4f55ebcf305b1d8546b5abf3dc178d9926bcc5280fd54248f8f9', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 05:38:34', '2020-05-16 05:38:34', '2021-05-16 13:38:34'),
('1082dd3dae129983ded0bcc646f41c42716fa5ac297841d2e8110f924d1ae5875dc842681363ddcf', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 01:07:19', '2020-05-15 01:07:19', '2021-05-15 09:07:19'),
('11d784cf121a92b5516d7374b6c83165def54a36d7e9249ddc42f9554f70edf8dc1ff30967cbf076', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 01:01:30', '2020-05-15 01:01:30', '2021-05-15 09:01:30'),
('14d97367a13f4c2d577370bf8f02163b35ce037fcfd552a820a5ae99b7d4452c025bd100fa7a7c62', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-20 08:15:57', '2020-05-20 08:15:57', '2021-05-20 16:15:57'),
('15b7141052eb00917f2fbd0754b95f0ca3bbb9ed8969dd8152222a7140b7a7a0f86a44b936f63a40', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 07:26:34', '2020-05-16 07:26:34', '2021-05-16 15:26:34'),
('15dc27e0096e36c50d8d89c4f8b22fd7399684913c524446c6ed6eb793e1bb40b90d60ab2ed67128', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-17 23:22:49', '2020-05-17 23:22:49', '2021-05-18 07:22:49'),
('1676f1c16b13adc4588d1fe8ee7ad802bc412805a52c5cd59b1c575238c1fcfb13295a7ff580e689', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 05:46:01', '2020-05-15 05:46:01', '2021-05-15 13:46:01'),
('16b863bfa0bab796f2cd7b545dc7806ff7e5ab6f3062cacc1044ba05a1e4c9b6c130a38fd56b430e', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 07:51:54', '2020-05-15 07:51:54', '2021-05-15 15:51:54'),
('1758cee41aaffb00d725547abeb475437d14183f0856a2b9af24ff97dc7746f0ebdd19c0d6ef86f4', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 05:20:42', '2020-05-16 05:20:42', '2021-05-16 13:20:42'),
('17dc2dcd3996b7a4236c06fd51fc82c158f85bb347627eb532f7d0009fabf226b5c09a19b5917430', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 22:25:04', '2020-05-15 22:25:04', '2021-05-16 06:25:04'),
('1841784b98fdeaae0c6b2f7aabff95f5d942343e008dc868ac0cbc4987db7f0591bfcedd1aaf46e0', 4, 1, 'Personal Access Token', '[]', 0, '2020-06-01 20:51:23', '2020-06-01 20:51:23', '2021-06-02 04:51:23'),
('185cd78254cbd305bb0136e6729cabb8311e9fbb31aa10a4e0ae483dc2f66f794876756639dce4fd', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-16 03:59:14', '2020-05-16 03:59:14', '2021-05-16 11:59:14'),
('19de05f524c2302e624c8347efd4dc5471293da6e4acdaeabe8a1fbec60cf3365eefc1083ca94cce', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 03:54:41', '2020-05-15 03:54:41', '2021-05-15 11:54:41'),
('1a51dfdeb4ea15f68cec56db10bfee1009ca9550395eb928593c075c004f2aadf52b462ad02f848e', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 07:41:47', '2020-05-16 07:41:47', '2021-05-16 15:41:47'),
('1b6aeb9b2e1dfcee3826125bbe89386d26be2ddb7ae358828fe072698160d3a2bba6ca4d17215975', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-16 04:58:05', '2020-05-16 04:58:05', '2021-05-16 12:58:05'),
('1bd64c2ec22ee1706ef22ee5965fb3fc084025ef7c4e89423b35f2c6ad65ea600993e211a9c9bd3e', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 06:41:14', '2020-05-16 06:41:14', '2021-05-16 14:41:14'),
('1d0ff752387c2901d47c92d9c69204bd43f07ca0f350d4b2868de108f5a6c68f06595bcdbc955cd7', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 00:21:19', '2020-05-15 00:21:19', '2021-05-15 08:21:19'),
('1d8a6da5fee9dc36c446775a42634a151b0332611c19d6c32c82e9c91a291308df98b68aabfd7443', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-20 06:51:13', '2020-05-20 06:51:13', '2021-05-20 14:51:13'),
('1deecbb82a46d978aadc09d1547a8d01f2433f3ac6c04413ae0cf7fab85ea9016001e20c2e6064ab', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 05:26:45', '2020-05-16 05:26:45', '2021-05-16 13:26:45'),
('1fbd919ca61bdb12e54628890fd0d17cd1c93bb9db1b9a0fff1c141f839eab3b37d08661d2a471eb', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 22:23:00', '2020-05-15 22:23:00', '2021-05-16 06:23:00'),
('1fe5590fe3a646a4cf09af89f53fd25501f9128057fe53287040148c0a394f39d791f31e75e34167', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 06:02:33', '2020-05-15 06:02:33', '2021-05-15 14:02:33'),
('203cb8a2d3b7442c9a7091e37c5fc693101d5c7da94cea1dc9898270ecd850785d870190e0ce5df8', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-16 04:16:43', '2020-05-16 04:16:43', '2021-05-16 12:16:43'),
('20ab9c131fed80088cbe9f0b71bd1417633d3be6170e897121586462b880bb31c50b37c58d9d4104', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 07:07:43', '2020-05-15 07:07:43', '2021-05-15 15:07:43'),
('20ad8ef3c3154a0579179f8020945d800f2e66565ef6218255ec940e69ee7f0f855b7c07b50ee030', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 03:31:34', '2020-05-15 03:31:34', '2021-05-15 11:31:34'),
('20b0a1b7959f22a48fff97f39baf4fd94a95101d2e592fc025986d773b02c9d6c95e7bf8190ec389', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 06:25:53', '2020-05-16 06:25:53', '2021-05-16 14:25:53'),
('2102d0c289abab67692882754005c72086e0c9c1901ce304a039bfaafd39e3124766821100d89815', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-17 06:09:48', '2020-05-17 06:09:48', '2021-05-17 14:09:48'),
('217010781875f4daf6b3eb07364f4f5057dd746683743904b4878df42bb87aed3522311541c67827', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-20 08:17:14', '2020-05-20 08:17:14', '2021-05-20 16:17:14'),
('23a7d6b71465a4751bcca3d32177132591c627bf9b09bddb86ac0899a32e7963ded9a881ba9b4846', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-16 05:05:45', '2020-05-16 05:05:45', '2021-05-16 13:05:45'),
('23ca1f48f5164ff53ff68b13730e3a69b2faab643c66f84f78fa3a8e21fc9f32524825045164c6ba', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 00:55:28', '2020-05-15 00:55:28', '2021-05-15 08:55:28'),
('244aa2dca1e91575d80fdea83924a7d3cfd3e3e268949582b29803da7240986d4eed2da978af9fc3', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 01:05:38', '2020-05-15 01:05:38', '2021-05-15 09:05:38'),
('2459f1cc65dd845f9430b64f713d1fa4c82a762ba83f273fed20289c3f90b2324c4e37e12a4c88f0', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 06:13:46', '2020-05-16 06:13:46', '2021-05-16 14:13:46'),
('25781ae6b5e624b5adebe2cbfe44d9707beb2226ded8d6667fc8ca4f5505a4b4b94ace547c924a1e', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-20 08:14:25', '2020-05-20 08:14:25', '2021-05-20 16:14:25'),
('2605b5c55560fc35cf8a353ec218740a8599c7b15296e8ea357a36abb4e7acbd28e0dd23feb20a9b', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 07:27:37', '2020-05-16 07:27:37', '2021-05-16 15:27:37'),
('260b8109cbf6062fa66c622c35b116a5eb9e9846c011c02207b412fa0d0d3640192059049cda362f', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 06:18:54', '2020-05-16 06:18:54', '2021-05-16 14:18:54'),
('26311d6b331f35b96a426198495193bc23c42eccba417c0c39e9b7c28af228aa7c7bd2eeac1e8812', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 05:36:50', '2020-05-16 05:36:50', '2021-05-16 13:36:50'),
('27ec6d833644800245d61032c5a4b88ecc4183858909c8ee19e5d18498f14840b850ba36dda8bbe9', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 06:52:42', '2020-05-16 06:52:42', '2021-05-16 14:52:42'),
('28623c2579096be84724da040c8acccda85e648a374d74ebc6f42ec1f7701063c025c66e2dc30957', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-16 04:41:05', '2020-05-16 04:41:05', '2021-05-16 12:41:05'),
('297f4790c842a8e6ec7753c298dd9cc4c4aba03a9d549ec53faef9d76d3b1dde838b579aca2d0efc', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-20 08:19:24', '2020-05-20 08:19:24', '2021-05-20 16:19:24'),
('2987beea0684fcace8d787394001bb44480ac50759dc949281ab06e966e7462e776ba4d2f7cc5160', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 01:10:22', '2020-05-15 01:10:22', '2021-05-15 09:10:22'),
('2a565ee23e91e7c5bc7cdc9da51b5c9f9c2dc1567e05d2b0c56fb9eec883f0d4bf4952c4e1a71b85', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 05:44:47', '2020-05-15 05:44:47', '2021-05-15 13:44:47'),
('2a97d6fbf583cc65d2864010c9043470b0d82f2c1314545d3afa319da56e4edb5a127b8c22538153', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-16 05:13:02', '2020-05-16 05:13:02', '2021-05-16 13:13:02'),
('2b1e65f003d7f401575401541bf00cfe17faa9467a4d0d0f1f515f1c1da3803bc5f0f87ea821b314', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 08:15:30', '2020-05-16 08:15:30', '2021-05-16 16:15:30'),
('2bd9231d75b4a9d8b3bdd9268cc7e3e6f41bd9039291023106b545561535360a7b5bc08e5f7105c0', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 07:35:24', '2020-05-16 07:35:24', '2021-05-16 15:35:24'),
('2cb34d46cf10229929a3b295b36fad793faf3ff4d8e229197d4fac45d888dc1b9ed9a33190076ee6', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 05:44:54', '2020-05-16 05:44:54', '2021-05-16 13:44:54'),
('2d0b30c0c8c6a8e3ead030eeed404a2986234c359dba2da4a4528d5841435da77e727135fcf85554', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-16 04:49:32', '2020-05-16 04:49:32', '2021-05-16 12:49:32'),
('2edea3bb598b6630fd7493a1a33399f2800db8966166d3321fd862a40e4eae63685dbc820f634c7f', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 05:46:05', '2020-05-15 05:46:05', '2021-05-15 13:46:05'),
('3009518737c7dde59918f536046389654b48eaba8609648daf51f1abbcf6369f3d5c93fc97dd66cc', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-17 07:41:04', '2020-05-17 07:41:04', '2021-05-17 15:41:04'),
('30202729b470e2e2300f4aaa7456f98d18aff2f2c80cca0897badb03fbf9bc7be8fd7a93563c612d', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 05:33:37', '2020-05-16 05:33:37', '2021-05-16 13:33:37'),
('30d5c8d77deb8bfafe95cb3ef5a202c4a646d2a492a5aff344cb331932fe2e949dbe5e6ca1c3515f', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 00:07:40', '2020-05-15 00:07:40', '2021-05-15 08:07:40'),
('315d2bbf03e495bb6ef8a6ac3657390fe9a9518faed16f50bae44ab827e27cdeeeb448e3a85d78a1', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 06:20:06', '2020-05-16 06:20:06', '2021-05-16 14:20:06'),
('3193ec785aba2779a51d0b7ed9784cf9dd7fb6dea0ffa4045272cd62fb2552e04f15ceb663788af0', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 07:30:55', '2020-05-16 07:30:55', '2021-05-16 15:30:55'),
('3400479fc4a93a224b382db8ed843f65bbc9ae4b1c53dbe11dd5d6eb399628897b3423e9c829ee8d', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-16 03:43:37', '2020-05-16 03:43:37', '2021-05-16 11:43:37'),
('34459dd8c6d873637611ea6e9d607e19f064393670421c53d65e0901f69fcfb2e5eb0e258eb119ba', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-16 03:48:18', '2020-05-16 03:48:18', '2021-05-16 11:48:18'),
('34cae0fb978d2ea16f51da02c94e09c724702fe689e6f5f2368f1dda834fd449cbe7f2475790fb5e', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 01:08:11', '2020-05-15 01:08:11', '2021-05-15 09:08:11'),
('35f7875d815f9b85d7d687b461ae5251c41d1439a8ba649a0881ba02208685e2a17c98df15d74bca', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-17 04:44:06', '2020-05-17 04:44:06', '2021-05-17 12:44:06'),
('36291370f81747656b46c193e01a37d2b7eabf01ec1f3f3a7d8affe2746755700f741480ebd219af', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-17 06:51:56', '2020-05-17 06:51:56', '2021-05-17 14:51:56'),
('36a3409ab0b165b48f34cc696441276df469a5995806bdffb218f5acafd912997a2cf9d19371a137', 4, 1, 'Personal Access Token', '[]', 0, '2020-06-01 20:35:52', '2020-06-01 20:35:52', '2021-06-02 04:35:52'),
('36ca8d86c2cf6f8190cd7a6f3a66e5ad3009b70c623a89107e52e61ceb929a38d17e14621bf964c7', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-17 07:19:31', '2020-05-17 07:19:31', '2021-05-17 15:19:31'),
('378bf2a58a3dbd888f90a93e46f63ff9b3e452d0f209c4d970c7c7a3f0ecd1e07bde96aa76717fb4', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 07:22:25', '2020-05-16 07:22:25', '2021-05-16 15:22:25'),
('38a2b70cddd3e059b102c9a4c3f15be094398a0d5a99631d84616a6f3e6836052cabf9152310dae0', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 05:21:24', '2020-05-16 05:21:24', '2021-05-16 13:21:24'),
('38d9553dec59e0be661e4f44aa9a116891267946673b92d526791111e6c37d5b9f020ec0b2325d85', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 07:35:23', '2020-05-16 07:35:23', '2021-05-16 15:35:23'),
('3a5d0e4b6f720e2e5487c01ccab69f4b228d30d139948c048ff790aab89027daf578c5f10adb913c', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 03:29:34', '2020-05-15 03:29:34', '2021-05-15 11:29:34'),
('3a77e5f9d35fd3fccfbd9314a6d673cfa6172ac9c1ec2300ca186b54fa6142a1f8990f6a1d36edc7', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-17 07:00:31', '2020-05-17 07:00:31', '2021-05-17 15:00:31'),
('3aa6a02f75422283797a6c8f6a149c4d4bc49a053c9c0b7da2545cf386cd4707c9d533caae54fffc', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 05:44:41', '2020-05-15 05:44:41', '2021-05-15 13:44:41'),
('3b55d79bcbfa883d6a633b1637bb08da1a589c5af98021862f49f4e0582cceb76a3a894533a13a53', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 01:12:58', '2020-05-15 01:12:58', '2021-05-15 09:12:58'),
('3c11df807cea7541bc739154bdce80667c6b5c14ecd48803858affd2bc671109e53b00be50497c96', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 05:40:46', '2020-05-16 05:40:46', '2021-05-16 13:40:46'),
('3c66aaa44afda5ac3dfcc04f5aacb00632f7166e95a6710a5d6d4a836e7fdf47db84f3e9aa054f65', 4, 1, 'Personal Access Token', '[]', 0, '2020-06-01 20:12:18', '2020-06-01 20:12:18', '2021-06-02 04:12:18'),
('3cda22349b2e39e20a005d65339cf3cb8b5b37a14744b7712b55c7999fdbf891de53251c0ebdb370', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-20 08:20:44', '2020-05-20 08:20:44', '2021-05-20 16:20:44'),
('3d4d71f7747fb52e7e6fdf0b8d38947b607b3e26417ec5545761d9fee4e4d4085dc1443af2f653fa', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 05:29:50', '2020-05-16 05:29:50', '2021-05-16 13:29:50'),
('3d6045df68081ad9b57eb91792c142ace28a7493215b48fb9af524a931e41fe3575890c5ba439c43', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 00:09:54', '2020-05-15 00:09:54', '2021-05-15 08:09:54'),
('3e14c2462de85fe7e5c6990957b1a8c0c26dffa8aa30a116025be9bee1ebcd56030602d60e08c5ba', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 00:08:39', '2020-05-15 00:08:39', '2021-05-15 08:08:39'),
('3e2afd52598cde7cffd45828b1d7e9b0a588532de487f0e2e52d0bbe78eaeae418fe8ed6e5a55632', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 06:42:27', '2020-05-15 06:42:27', '2021-05-15 14:42:27'),
('3e6e5ab25edd11438bbe46e4ec629d6c810ef4fb087f34701dacd46545f62970f461a52d65b29015', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 06:41:55', '2020-05-16 06:41:55', '2021-05-16 14:41:55'),
('3ed0c095eee795e8cfde4d36c5bfb412cbdeee272bd0989566e7aab9ddda8d91e4b9e7167a877955', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-17 07:01:57', '2020-05-17 07:01:57', '2021-05-17 15:01:57'),
('3eee91d4a60d319f27b11402c346517973862d36b54f6311426f5d0149a0db1e62e462b7f5cc5d97', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-17 07:40:11', '2020-05-17 07:40:11', '2021-05-17 15:40:11'),
('3f993d1da119307053d21938023a1fe8e7c4dc91cff1aca452d0b1cbd5744debcf20cffd5ed185cf', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 07:34:35', '2020-05-15 07:34:35', '2021-05-15 15:34:35'),
('40d2a9c40d0b01cb1d145786cb760500d479aba478cbca7850b0078e2028fb59ad72b535ac25ab0c', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 06:30:13', '2020-05-16 06:30:13', '2021-05-16 14:30:13'),
('40dba60d6a0dadfeeadf9f130a616a7026d882a78bdc6f5c7c58a6a73c89bd5c57142f8c0680fa04', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-17 06:50:39', '2020-05-17 06:50:39', '2021-05-17 14:50:39'),
('41e1a099b60a68c0b8f16738d15be57b22e5c2f1817ba153aeb0f6cb8fb137f43e297ecc7940dcf8', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-14 23:36:52', '2020-05-14 23:36:52', '2021-05-15 07:36:52'),
('41ed9bc6d2c3e159fb0a04b65344ecfb4f4356644afa4b85b0cb6608444972e1cf27cca7bf8b77fd', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 03:32:00', '2020-05-15 03:32:00', '2021-05-15 11:32:00'),
('423d2c75b17c447b02ff70da488bc8dc1af8883fe5876180a8127ca28df48926651862d23135006d', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-16 03:46:58', '2020-05-16 03:46:58', '2021-05-16 11:46:58'),
('4242fcc023e501b84523f5f79bd9b63a412e9f1c4d47b0b32bf4955938c682b2c1b7398fbb689ba2', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 06:54:39', '2020-05-15 06:54:39', '2021-05-15 14:54:39'),
('4278e0b2d2e526ce3f25c7418e2173c87479568bb859ea9f3ac41bb8b30b96dfaf2f4d37123859ed', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-20 08:50:27', '2020-05-20 08:50:27', '2021-05-20 16:50:27'),
('434efaea529f8e907bcafcaecb220470a24d6cc3495466d0d22b1968a78fe7bc152dad5f4c2d759a', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 07:56:04', '2020-05-15 07:56:04', '2021-05-15 15:56:04'),
('443cb07dc2ab3d2f071780f04897d0ce24721c7cf63b7e86b7db49d8a6fb8dceca8171d49702f9bb', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-14 23:34:33', '2020-05-14 23:34:33', '2021-05-15 07:34:33'),
('466c19785a331a44ac58470cf5df65e1d9dc9ada3843721047756403189321213b3f70f636b1d982', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 06:18:37', '2020-05-16 06:18:37', '2021-05-16 14:18:37'),
('46be1d359a39ca46d318b6cc790c8e06ff18ae6a3a53e2c8b838791867aa5a7ca8b850879810d0aa', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-20 08:06:34', '2020-05-20 08:06:34', '2021-05-20 16:06:34'),
('46c41190d587033059513ef55f1bf291f7e7e051f7f392338dc985cf994604b13d5b729c4f96f4c1', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-16 04:42:48', '2020-05-16 04:42:48', '2021-05-16 12:42:48'),
('46c4e2bb903a0b2f3a767cf8bfefe1de0401673d5effae362e312e445673dbfef4718ab04e5272a6', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 07:19:45', '2020-05-16 07:19:45', '2021-05-16 15:19:45'),
('476c1e3bbe57ebbfc827290faa9cabfe55a3dfe81bd92de6169efa00852a332f0ad15aeb41cbafe6', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 06:24:40', '2020-05-16 06:24:40', '2021-05-16 14:24:40'),
('48079e2830140696445087f3e6a9785974bf081068234857dc61b67b1032c8f860ca874e44635fb5', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 03:56:36', '2020-05-15 03:56:36', '2021-05-15 11:56:36'),
('4837535ebf78502b91369bbff3f7fe81d3b9c1417e84a89f5ff9ab239d2ed9fc424619c004d166c4', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 06:31:44', '2020-05-15 06:31:44', '2021-05-15 14:31:44'),
('4964931a3f5fd935ed1c3a7853bc9b18a3002c7c22ff4ac8c614c64f99ca87defa23120cc1ae5ea7', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 06:52:43', '2020-05-15 06:52:43', '2021-05-15 14:52:43'),
('496fe154d6421da895a0bf09898084770fea3e06d7405028b925a642226e78575ca820a6f808f1be', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 07:34:41', '2020-05-16 07:34:41', '2021-05-16 15:34:41'),
('4997b0556e648820418e02798bc3684ed44e53b92898c491f91ab3490da3a024b1a22539570cdc10', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 07:45:58', '2020-05-15 07:45:58', '2021-05-15 15:45:58'),
('4a65e5ea0652ddc721f40b526243a6e06e7f7cd10a9d1cbac2d850ad95d6af0dcc418f6db6a5e4d7', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-20 08:51:22', '2020-05-20 08:51:22', '2021-05-20 16:51:22'),
('4ba7c23b6e6e062499402becfaa81f5baafb0af5b6305617a1e1cb54f3c04d7e5fca139ae3197dff', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 01:02:56', '2020-05-15 01:02:56', '2021-05-15 09:02:56'),
('4c0441c2ed1f14a8b4135d679b27821d44044a57d4890b381b5223a02fe8f2cb2b638c9cf0886ffe', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-14 08:51:22', '2020-05-14 08:51:22', '2021-05-14 16:51:22'),
('4cb786db31ddf0ebf2951a854c145250401c6228f9b5111d93900ddf463432527336819c678fad7b', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 05:22:49', '2020-05-16 05:22:49', '2021-05-16 13:22:49'),
('4e139ecadbc48009c0baa83d04c11bc516c9e344498d6652c1e589609d8fa08c228b334acf0db119', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-17 05:05:42', '2020-05-17 05:05:42', '2021-05-17 13:05:42'),
('4eb52467194347da9994ca6263706206d668ee2df3fde369fdce315e0fb89827275826473127c37b', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-14 23:51:24', '2020-05-14 23:51:24', '2021-05-15 07:51:24'),
('5037db9db7150d6216d437fa694ac937bf0a37b6f2856c3494f545e86b12c76bbb05565235959712', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 01:06:43', '2020-05-15 01:06:43', '2021-05-15 09:06:43'),
('504c5dcccca70cb860b7bb1e932b62a5e277a8ccc8aa2a85dbd8f15b7f1203a42e7e2ea716fb1e03', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 00:51:17', '2020-05-15 00:51:17', '2021-05-15 08:51:17'),
('507d5979f3737d7a4c93733303fb1174cd08ed38f3117679b0eaf939caa2def381689b8b0407fc61', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 08:01:10', '2020-05-15 08:01:10', '2021-05-15 16:01:10'),
('50ea28fae3a1c9627934433fa3986b205ea9d88ad331b866d19e3471fba8f180bc7ba6628ced8f5c', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-16 04:27:49', '2020-05-16 04:27:49', '2021-05-16 12:27:49'),
('510a400ac9f77019dfb206c0e05d7f9e99bf62cff211a1cf52fa04020252783c79814efbb3a42347', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-17 23:49:14', '2020-05-17 23:49:14', '2021-05-18 07:49:14'),
('51a2f9a05d5bc29ac5fa05f0b5840e58381db8ce787e10d55b2a4f1414eb2f3dcebb27fd731a0344', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-16 04:33:17', '2020-05-16 04:33:17', '2021-05-16 12:33:17'),
('521fdc442ab252c84c4c89c2c24c7304d1a7675262cbc75f82cc84d6589234d84a38e6311ce19fd0', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 05:37:29', '2020-05-16 05:37:29', '2021-05-16 13:37:29'),
('52e23d818d3bc11246518eb3cdf84947d534138fc63841a6bd04c79c3b71c8ae3d00807f047f4a06', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 00:24:58', '2020-05-15 00:24:58', '2021-05-15 08:24:58'),
('53b4dd64d7839180aaa52596482d118af7e85cdc8e5389b24980d8da7b4890467ee8641ed603424e', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 05:51:49', '2020-05-15 05:51:49', '2021-05-15 13:51:49'),
('53d2e4cd71826ab30c5b0efda8f195ec4311a13d761642a1670f4ded26098012cd848f448cea1448', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-17 07:18:54', '2020-05-17 07:18:54', '2021-05-17 15:18:54'),
('550456493d020386b988510425e4a3ff5c23388afa3c579d9523711cb1ad185b6d54886fc71c0ac2', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-17 07:06:45', '2020-05-17 07:06:45', '2021-05-17 15:06:45'),
('5568b86fa44d32111e0fc62c42946724344365bc646ef85eec31d9b9a40cb004714267e931e761fa', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 06:23:33', '2020-05-16 06:23:33', '2021-05-16 14:23:33'),
('55a87157726844a27356c84436377bdf13045e72e257b766de7535dff5819312025ca008a1123e60', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 07:52:18', '2020-05-16 07:52:18', '2021-05-16 15:52:18'),
('55c730ed79dc8733f73bfa8e081bf1985197c76dcf3839cb0d3f262bc39ef59465a65bf6115a25dc', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 05:38:25', '2020-05-15 05:38:25', '2021-05-15 13:38:25'),
('55e813f23aa247879be1abacc32ced8d72c08dc1fe3bfdf70c6d7ba2caad9348f3fccaaadb3b6797', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 06:09:19', '2020-05-15 06:09:19', '2021-05-15 14:09:19'),
('56502fd32f24ff98e7091f8ea0738b9bd1b06d415a6cd96a7a59623771f791ea554a05bca35b8218', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-17 04:44:45', '2020-05-17 04:44:45', '2021-05-17 12:44:45'),
('568168b823717ce9eca757820378557f637633eff096fe607b3576cb18cf67f8e9cd76305c6ea006', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 06:30:39', '2020-05-15 06:30:39', '2021-05-15 14:30:39'),
('576113704fe963a084b68cda3f7d02905279354f576ee208477e3f9ae9679bf67aef3246a87787ae', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 01:10:08', '2020-05-15 01:10:08', '2021-05-15 09:10:08'),
('57c3a14d3a3568c1e9fe07916db007dd71243b8121e9cfd302ce46430c89efaaea372f759f9f060b', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 06:42:30', '2020-05-16 06:42:30', '2021-05-16 14:42:30'),
('585430bebe7cbf2cb1c3852abf72029ee2123e59b11c4e18a3924e946e1ee14081cb887e24567f40', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-16 05:07:36', '2020-05-16 05:07:36', '2021-05-16 13:07:36'),
('58e8aa9e4916a146cf56957101ec6f30940605bfd3839a59ba250e310e97a6d9cf537d041bbe6d6b', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 06:30:23', '2020-05-16 06:30:23', '2021-05-16 14:30:23'),
('5977fcaa72b8bf2c0e0c0d7c5ac62bb5839829e8b1a29e7ca4acf0c59d724e970a03d697d6a02130', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-16 03:55:04', '2020-05-16 03:55:04', '2021-05-16 11:55:04'),
('5a65909d0d34bcc1467e2b487bc3b7870cadce1326811591beae98bfc90c040988194783f9e56fc0', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 07:55:37', '2020-05-15 07:55:37', '2021-05-15 15:55:37'),
('5a9a9d77caa7356aeea2e0104e1c3443c03b0fb633dfdd730b3629956ee269d71af52e26aee510ae', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-16 04:21:27', '2020-05-16 04:21:27', '2021-05-16 12:21:27'),
('5b412669a69665ecb45a28816223e33f2efc759a290a2c44898c8f4ebd264c59f56d8552411c5a5a', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 06:25:50', '2020-05-15 06:25:50', '2021-05-15 14:25:50'),
('5cbbb928a59521f096567d44204405c00879ec4fed7c49b9e9e07af501bb0f5209398d67b7793ee9', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 06:29:01', '2020-05-16 06:29:01', '2021-05-16 14:29:01'),
('5d2863be208cfc8a0fd7e20733e64ebb5eba65c09cf16298f1259c45b64c5f7de26896e96213417f', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 00:48:42', '2020-05-15 00:48:42', '2021-05-15 08:48:42'),
('5d5c04961c4c2727be8d1ecd0befdac2e37124d9bf3162ef67b2fd26a43e9ae98cddd40af4f6dba9', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-17 06:36:33', '2020-05-17 06:36:33', '2021-05-17 14:36:33'),
('5da536ba931831949ec633857809fc4787554f144f8a69f04aeaf26cc11e4130552fb2cdce122212', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 22:15:57', '2020-05-15 22:15:57', '2021-05-16 06:15:57'),
('5e676e9979f92eb3acede713e597505b5b2388e38c8fcb531c0f75ecae6d8bbacf314782e54ea047', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 07:48:35', '2020-05-16 07:48:35', '2021-05-16 15:48:35'),
('5eaaeba8455c1f17654a44495f6146470e189056b9978f792ecf079b7631347bbabe997196ff11ce', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-17 06:52:42', '2020-05-17 06:52:42', '2021-05-17 14:52:42'),
('5ead445b7980fc76cfc0900d0f7508a52fe78ca92ad7b9390799a8e0ccb2bbcebafba2e1268235fc', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 04:01:07', '2020-05-15 04:01:07', '2021-05-15 12:01:07'),
('5f7f5bdede2aca26b153bcc8fb9f90beb85e9b725e0aa59238e2066352a35f459fc4dac194626fe8', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 08:13:08', '2020-05-16 08:13:08', '2021-05-16 16:13:08'),
('5f86160a21481969a99e4c685445e3c4521ca5c3f7b427c9876696bffb01eb6521a3846c8173be07', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 22:26:00', '2020-05-15 22:26:00', '2021-05-16 06:26:00'),
('5ffb69ec63488105925413fcef49131b9384136d87ba789ee10a1eadeef84277b7edb1a8664c8d36', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 07:42:45', '2020-05-16 07:42:45', '2021-05-16 15:42:45'),
('61e2db90b6cc0af4dc8e344d26a9680ff0ea9e54d2b450c50fedba55a5da47c45386e88762266a32', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-17 23:31:32', '2020-05-17 23:31:32', '2021-05-18 07:31:32'),
('61f4552f11f67d7b0b74d24fe03e80900a2e446d4df41f7d91806589b6d6df43e349b6c7529fdd89', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 07:19:49', '2020-05-16 07:19:49', '2021-05-16 15:19:49'),
('6237ce119411955e06a7de740f74805e35a69da7fb0f51495322a338dba0a806022d4c07290f5daa', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 07:18:42', '2020-05-16 07:18:42', '2021-05-16 15:18:42'),
('628a83e4645645e3d94f48af2fd18536b3392dff37096d0159f8bb4d99b7f125d388d7137275de9c', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 06:31:25', '2020-05-15 06:31:25', '2021-05-15 14:31:25'),
('62af45ef0141b9d5777cfa8947fdecde90817987e86f01ee53c5c214f9c07ec75a36112937c9a1b1', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-20 08:48:07', '2020-05-20 08:48:07', '2021-05-20 16:48:07'),
('62b5512917789eaeb7df70300ac886490fd7800771058668f451fb77ef907f7b28df04becbb76aba', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 00:00:02', '2020-05-15 00:00:02', '2021-05-15 08:00:02'),
('6320d13e555d175cec4d0390295a88526a8c278b151898f03993ad880f4a70a7db5214e53ccff09f', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 00:58:53', '2020-05-15 00:58:53', '2021-05-15 08:58:53'),
('63a6ed7f67e71b2eba78400c30efd697e355ffec642d7794c105f59ca5246ac434f71403af575afa', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 07:49:43', '2020-05-15 07:49:43', '2021-05-15 15:49:43'),
('642ce084bb1c033eb5613416d46256372179c988a25a28eb489ee05f3fcfdfdd6f15dfcbb55ccf67', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-17 06:38:09', '2020-05-17 06:38:09', '2021-05-17 14:38:09'),
('64d363f2fee4e61eeeba9c877791448bc03c787cb74658ec6ba8eaa2321df848defad7e8e4c4cc8a', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-16 04:02:53', '2020-05-16 04:02:53', '2021-05-16 12:02:53'),
('65979e198bc50cd6629b65027d08914a6d6a5244419f34fb334a8917d4a27a0b4e7d31e871835751', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-14 23:43:19', '2020-05-14 23:43:19', '2021-05-15 07:43:19'),
('659c55d8bceb7040c08bdb0562afe53eb6dc46a96e7d8de412786101a2e64fe1905a40a46afe9ffd', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 08:03:06', '2020-05-16 08:03:06', '2021-05-16 16:03:06'),
('65b859f63e85a767e13152e873a3e00fabfc7afe4ff15a746d0c081e0b09b9f469427c186da3d882', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 04:43:41', '2020-05-15 04:43:41', '2021-05-15 12:43:41'),
('666892026d1a4082bd614ae646ca6ed21107ebd606b3bcf76030e6a4f0876951cb70896a9c9a7f0c', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 03:46:12', '2020-05-15 03:46:12', '2021-05-15 11:46:12'),
('6678ff17951fd39dc755ed199c92f6ae3f7c27f6aa51898c0ce21559b3b882ca37cb36f23769515b', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 07:58:11', '2020-05-15 07:58:11', '2021-05-15 15:58:11'),
('669c32a71ba248fa7af4ccfa40282f077ca4ca58f90f46de73a66cf8dd015fd835a86ea6ad02de53', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 00:23:42', '2020-05-15 00:23:42', '2021-05-15 08:23:42'),
('67228f6b08b44af4e6e5b170788cbc24ca15ef423bf09ff72a90b154158add67d56c73a6e9021da9', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-17 06:55:01', '2020-05-17 06:55:01', '2021-05-17 14:55:01'),
('67e492fc83cf0b74a419c9446cda6354a921217be82290a5a52de14818cec10a06a9d029bce4c080', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-20 08:53:43', '2020-05-20 08:53:43', '2021-05-20 16:53:43'),
('68a11d432b3f0414c939d4199f65977c659ccfbce2f58cbd8550f5367bf8033d1f5cfe8fac4e7eb1', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 06:20:14', '2020-05-16 06:20:14', '2021-05-16 14:20:14'),
('68f1fb4d406fc88c35662d6f3c67cdc5c4f8fad76c18af6d9e30510f2c17e092b8f1a50188216d63', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 06:33:21', '2020-05-16 06:33:21', '2021-05-16 14:33:21'),
('68f546bfd27b20ae1a89d2dfbd269a48e7e020e9e7a155724a2ceaa8f0f6e1a77128711877454362', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-16 05:06:29', '2020-05-16 05:06:29', '2021-05-16 13:06:29'),
('69817099c900047cd99a04ca5cb4d713b2c453537d5340d15e225f64dea7ca46d9c207823a768caa', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 03:34:18', '2020-05-15 03:34:18', '2021-05-15 11:34:18'),
('6a702783f61ecdc91465da87f2cc8866357b1d0617ebdc43b6e0f4e331784190b1795db34858e0c8', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-20 08:54:45', '2020-05-20 08:54:45', '2021-05-20 16:54:45'),
('6aac4f220237f4c2f6f934726499ea340d7455ac17a2ae6848fe97476287f72fdced7b2d35a55979', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 07:45:43', '2020-05-16 07:45:43', '2021-05-16 15:45:43'),
('6bf7d1c65b919c1f40f9566c2b2a50b31c3588fd539656352b37814df19088dd67537963c181f755', 4, 1, 'Personal Access Token', '[]', 0, '2020-06-01 20:21:34', '2020-06-01 20:21:34', '2021-06-02 04:21:34'),
('6c16a0b351b12ca10693cd662a2816bb2bac19b2d1f9721db8ddd2f13cb504668a2700334e09866e', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-14 23:57:11', '2020-05-14 23:57:11', '2021-05-15 07:57:11'),
('6c47c8889898f1a0fe5273530552ce0f4880f9258771e9951d420b58ba5f6b68129234510c373f75', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 06:25:55', '2020-05-16 06:25:55', '2021-05-16 14:25:55'),
('6cddd4fb8d935dab8acc4c23badea9407d004ac347a45b7e001360a8142f7528249d6aed5d5bf5f5', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-20 08:33:39', '2020-05-20 08:33:39', '2021-05-20 16:33:39'),
('6cf9c8da61e5fdcc265b368ba4dbf97cf4347e93abc747fc60a7d25d1f07e787a3d799fb1fb312e6', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-17 05:48:48', '2020-05-17 05:48:48', '2021-05-17 13:48:48'),
('6d83f56fcdb09bbb9022caffae613f1a642b857daf84a68a89aae241756cd2aaaa0a0420443091e8', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 03:58:36', '2020-05-15 03:58:36', '2021-05-15 11:58:36'),
('6d9b31bcc76943fccd91d8376ed14cd746676e57e5011a04e5cc9ac85fa0c3f5fb01f5a7ecbf06e8', 4, 1, 'Personal Access Token', '[]', 0, '2020-06-01 20:45:27', '2020-06-01 20:45:27', '2021-06-02 04:45:27'),
('6dcde23a245effc6f03f149029a6dfbe6dc24f551edb57bc830f900255584909badacbe8ce7675d1', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 07:56:04', '2020-05-15 07:56:04', '2021-05-15 15:56:04'),
('6de89d8092bc40b6265350829e259d47a9e198cbbd99f4e77cda5570b6e3b0de85da20ffb7dc9472', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-17 04:50:29', '2020-05-17 04:50:29', '2021-05-17 12:50:29'),
('6dff4fec586a553ae059d2b33b3040added272277ba6ebb3a8dc65b60f5c0d927a8712e5ac305d38', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 06:14:34', '2020-05-16 06:14:34', '2021-05-16 14:14:34'),
('6f20a0efdba945697790bef501e4effc51fae0bbd496d34ae0765dcfbaca3c120bcd35ab526a837a', 4, 1, 'Personal Access Token', '[]', 0, '2020-06-01 20:40:13', '2020-06-01 20:40:13', '2021-06-02 04:40:13'),
('7252becdbd44a480b77d10e1d720e2aee5770d42ffc4e1b100b1200fab411b80067053506fb3106b', 4, 1, 'Personal Access Token', '[]', 0, '2020-06-01 20:52:01', '2020-06-01 20:52:01', '2021-06-02 04:52:01'),
('73c33df5b98ff7206f15086204ac1aae3ee3caee46657a80c707e6c76cba4b06f616765be0f12ce3', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 07:39:53', '2020-05-15 07:39:53', '2021-05-15 15:39:53'),
('744266ee8306a80673d58ca82e23fa1fbe9723305137aaf304da0e30633a6eec217b93b87332b79f', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 05:59:47', '2020-05-16 05:59:47', '2021-05-16 13:59:47'),
('74c9d80de7701d1629d856bf7d7b39426f68d06ef62225d8f8e61268848d421c81da7f2118b75a30', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 07:42:48', '2020-05-16 07:42:48', '2021-05-16 15:42:48'),
('7575e80fbcd69ec63596243c714f6699bec8c35bd2d4e090f929ef1a11f69643cb15774dbff96157', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-20 08:26:06', '2020-05-20 08:26:06', '2021-05-20 16:26:06'),
('75c5e04f8d1b0b715d6b7b13986853f4d1a70e2ccaf30c456e1c6336638a93919da18986718dc6c1', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-20 08:49:12', '2020-05-20 08:49:12', '2021-05-20 16:49:12'),
('764e2379bb6be7c234cbbdd04cc09e511b43507ad504f62c6d545b36b075db59879f47cc5ac28c06', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-14 23:54:54', '2020-05-14 23:54:54', '2021-05-15 07:54:54'),
('777133c02be2790f8fd2e531f07a16ff62714bd28ce28192e56f8ed2c633b11ce5705597b8562fda', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 08:13:41', '2020-05-16 08:13:41', '2021-05-16 16:13:41'),
('78229e2cf899989aed62d9201e19fe8cf0d2bf4518744e2b55599d49b63cb4e1457c51233053c106', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 05:39:22', '2020-05-16 05:39:22', '2021-05-16 13:39:22'),
('794df391af4f6d26ca097089a65dd7d0264c11e2d861bb9b85b4a59e2b8dc1eb1448c5919707f4dd', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-17 06:05:53', '2020-05-17 06:05:53', '2021-05-17 14:05:53'),
('796124b4311e04b284d916357d006916539125cf0f4f69b27d708c3d6f0627ea786fcd5e64278b99', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 22:26:43', '2020-05-15 22:26:43', '2021-05-16 06:26:43'),
('79f8b85c9f2dda10ffedaa590303f24135f1340db9cb44dc7a1b900d0f4cca57af1965e4dcf57dd0', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 01:00:56', '2020-05-15 01:00:56', '2021-05-15 09:00:56'),
('7a058ba02acc091159572391d29f99491b91ae28ad57eaa5c4421c7ab725a5cce710e400c37687f2', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 07:40:04', '2020-05-16 07:40:04', '2021-05-16 15:40:04'),
('7dbcd8a074327bbb2fe258390540d4d73d9b9a6734ec83a09a70920c2948259d7711f6a9e43df70b', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-17 06:07:49', '2020-05-17 06:07:49', '2021-05-17 14:07:49'),
('7dfb4a66f4ab62076038e571861dd0fadef8e888b8a9c656d18105a923d8306375c656112b2a425d', 4, 1, 'Personal Access Token', '[]', 0, '2020-06-01 20:44:23', '2020-06-01 20:44:23', '2021-06-02 04:44:23'),
('7e23719763b8b555b4a330274f745eb8cf5eed5999251705f0d5aa235708639feaa4c6e0f6528aa7', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-17 07:39:22', '2020-05-17 07:39:22', '2021-05-17 15:39:22'),
('7e615d8753f50d7e6f4a6bb07f36581efdedc9f0300db9134e3e4f398c185dd51143ccbfd486771c', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 06:23:16', '2020-05-15 06:23:16', '2021-05-15 14:23:16'),
('7e6b7ab441600a06c1a69b20ddf275414fa2104c133a72454434984721ff35309d6c47c1cca3a3b9', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 06:15:46', '2020-05-16 06:15:46', '2021-05-16 14:15:46'),
('7f35d911c00a5ed1cd951ececba34f28962dbb8e979d3c12e3b95fc8a832f096d959849c043da075', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 07:18:19', '2020-05-16 07:18:19', '2021-05-16 15:18:19'),
('7fbc47d5487d4de729e7a0c717f9ae15216e57bcce4bc1eb5a419347208c03b28bc4cdfa2215cbba', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-16 04:54:24', '2020-05-16 04:54:24', '2021-05-16 12:54:24'),
('80cc5100024e34e97083c52d959a1dfe9608482cec6c9eb5b8563add01c3e18c8fd924cd1a1b9e15', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 05:26:39', '2020-05-16 05:26:39', '2021-05-16 13:26:39'),
('81fd8718443cc2a265ce9a5491466b83e99a2a91634b29fb9b191caf77e190609d139fe59b6c54bd', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 06:44:15', '2020-05-16 06:44:15', '2021-05-16 14:44:15'),
('827b97ce0483030b1b5976b6c7aefaad46095cf0aec4efe964990310c525174f022d07b43db5a805', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 06:19:53', '2020-05-16 06:19:53', '2021-05-16 14:19:53'),
('82ffbb7339027f65332cedefece1a1b0bbe7deda899ede080ab81b6102117dc0a44ec9c7618452e4', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-17 23:13:46', '2020-05-17 23:13:46', '2021-05-18 07:13:46'),
('844162d2e314d3792c8ded92f4678acb78028ddf4a902e2eb0641e3e441e00e3d86c78c6e5d37262', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 05:29:57', '2020-05-16 05:29:57', '2021-05-16 13:29:57'),
('85f488a4f4515bab211cd37248bdc636172cea472d76578500de0c54d6d261b5c6de7558e0cb5455', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-18 00:19:54', '2020-05-18 00:19:54', '2021-05-18 08:19:54'),
('86396caabd721c7f2f18b69a2515456d912570c7b1db65e04eda5e61e5dea5fb801f3cc29148ddff', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 01:09:17', '2020-05-15 01:09:17', '2021-05-15 09:09:17'),
('86673cea2d9e076018f6214ae79623b7bf168fcdd93c27a4cee4b1c3970a9695f7945d9e0c0886ee', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 06:23:42', '2020-05-16 06:23:42', '2021-05-16 14:23:42'),
('86a8d201a185ea0342d4960fdb93e14791e7e80580aa50262f717d50f406b206dc79100b6246f067', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-17 23:46:50', '2020-05-17 23:46:50', '2021-05-18 07:46:50'),
('86e12517224ca8370341f8f865169b2c3f1760906d8b8bbb13ec3bce59b1480fa4deef439d1c431e', 4, 1, 'Personal Access Token', '[]', 0, '2020-06-01 20:46:30', '2020-06-01 20:46:30', '2021-06-02 04:46:30'),
('879823074fcbadcfeac90baeb903b7bac66ee34ce975f878fc7b3035831e4de2a5ba15a3aa5cbb0b', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-20 08:51:12', '2020-05-20 08:51:12', '2021-05-20 16:51:12'),
('87d708812d446a72e20493d99e0bccd96f5ee04bd629ea5ee7a14440c152d50f2ec1c346218ad9f5', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 06:00:48', '2020-05-15 06:00:48', '2021-05-15 14:00:48'),
('8cdb2a97a038b2f42661667686467589d4ea4b29b40b6e7f3002261f28e34ff0891056b6f025b759', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 05:59:11', '2020-05-16 05:59:11', '2021-05-16 13:59:11'),
('8d9bcba8c61a36b25cbb43fc1f796f578a83127a06afe11dc31bce2081db7af556f664beb9203ad4', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 03:52:10', '2020-05-15 03:52:10', '2021-05-15 11:52:10'),
('8e14f4eb0b68373c53fbfa63912e8f13c3fa91b98641759e5a86ad0a718de3b4bcee2f1bde22d29f', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-17 06:24:11', '2020-05-17 06:24:11', '2021-05-17 14:24:11'),
('8e1c31bddee85e87676780b9c5b869a5c0226f4c5879423d0766c9ab7fa6deec3e59e44034166534', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 06:27:11', '2020-05-15 06:27:11', '2021-05-15 14:27:11'),
('8e40da6b156a005e8bf16e5b325132b24e6c8e3fb198465c58bb04702a6c78082ee80c3b7e4155f6', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-17 06:53:24', '2020-05-17 06:53:24', '2021-05-17 14:53:24'),
('8ead11f7b9edc90031fa533377d9f082643e85bdb7b9f142e7d645aca0008ae06fe9a081d6101a42', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 05:24:09', '2020-05-16 05:24:09', '2021-05-16 13:24:09'),
('9259d429c2ea2b83746a56bea49385c0fdf48b77c8c3be6302d94f7aa7b7555848836e726afef24e', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 07:35:28', '2020-05-16 07:35:28', '2021-05-16 15:35:28'),
('92a3d4c00106eb461c071ba088c6d1b55723db01f0a73f3c8611914274ff2b74b0a080fa952c0f41', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-16 04:53:04', '2020-05-16 04:53:04', '2021-05-16 12:53:04'),
('9300f7f00fbc04bbfc7efcbf31582483949b11b0c2e1252236347e332fd69d32920ab07f079ec6e6', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 05:50:26', '2020-05-16 05:50:26', '2021-05-16 13:50:26'),
('936ce4e5ac82c015551194f3c4d6170475b63bbb34a539d0016bd589a6cc7797fb5d2f4d129d5b9e', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-20 08:54:01', '2020-05-20 08:54:01', '2021-05-20 16:54:01'),
('937b97fb57f9ed1702cc6bbca5e92f7a946c08b6e9423f2e092c5255bf4e1118c11940ee7d6cd502', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 05:36:41', '2020-05-16 05:36:41', '2021-05-16 13:36:41'),
('9525ae2c52a459258867d9f841cd3ff08c5ff2401ae98a3473ca9f61c15e7e1cdd85a9e7007107d4', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-20 08:43:39', '2020-05-20 08:43:39', '2021-05-20 16:43:39'),
('956ded5c3834f0bf74c6ff584bf80cc0e5be5ccc65c8cfd2af67dff4284b608dc7ec13608cc6b6d6', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-20 08:14:48', '2020-05-20 08:14:48', '2021-05-20 16:14:48'),
('9805c0b2c274465d13bc727fc55c643c48ea01d44f9e8ac592375690b7d458238cf4d6ea047d337a', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 00:52:07', '2020-05-15 00:52:07', '2021-05-15 08:52:07'),
('981e5d40196b453fd706725ef8b06ce2022cebfc6556e5cf6b8c28c1c2ad3c28553b58cd434e7ca4', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-17 06:09:55', '2020-05-17 06:09:55', '2021-05-17 14:09:55'),
('98fdf8a060cbfdf024f71d9ddb5c8fa9ff8bfef14038acd647b6f9481afa5ee5c861409d6a8f2579', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 00:57:42', '2020-05-15 00:57:42', '2021-05-15 08:57:42'),
('99279c31a39b6d6a1fd16cc8ec2d97da2522c0231aa36ab4ad00a81658ddc0191f036c60f1ebf062', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-17 07:47:53', '2020-05-17 07:47:53', '2021-05-17 15:47:53'),
('9a11808084593a1fac510412edfe293c22a98cd66e3ae399346221d45934a724eb507616af1bc090', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 05:38:12', '2020-05-16 05:38:12', '2021-05-16 13:38:12'),
('9a5faa476447d04ec7e64960637b1609d09503cff3c076fdc67c2cdfeb515b5d4fce7e243d930e5d', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-16 04:57:21', '2020-05-16 04:57:21', '2021-05-16 12:57:21'),
('9a8a4b2516199fdfc94e98e2d94994531b8065e704183642d72a02673d26f0505e35e3c15aef1178', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 05:43:22', '2020-05-16 05:43:22', '2021-05-16 13:43:22'),
('9afa84ea4aaa7b449e3aa2e15c703b26c4bb25734c22546884d17a059988af81aee35790bcd01e71', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-20 04:44:02', '2020-05-20 04:44:02', '2021-05-20 12:44:02'),
('9b02f3da2875052371a5bef518ed6621ba6d027d351ee36b57784e5f08e70cd4e481ab48b3a763be', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 05:42:40', '2020-05-15 05:42:40', '2021-05-15 13:42:40'),
('9b830650212f69892f918cc4de5bf58e9701a294d6fea3f5060f8f05a7c2d87ac8628953a53d6c53', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 06:18:26', '2020-05-16 06:18:26', '2021-05-16 14:18:26'),
('9baabbef589f4f41f2667ba1af85d725cdc6ea1199dfc7d66bca2cde4701c6e8d86983d099b526ff', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 06:36:50', '2020-05-16 06:36:50', '2021-05-16 14:36:50'),
('9bb957d8a0d11f101d8cd5702e36ade9843eddcc733e8f7f1356ef59291266cd5d6c6909460a4426', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-20 08:32:50', '2020-05-20 08:32:50', '2021-05-20 16:32:50'),
('9bce7a90e3053c9026824009d4f2acb02876439ab00ed4e5d1f9c43a546c6b7f51beeb19b6758231', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 05:42:40', '2020-05-15 05:42:40', '2021-05-15 13:42:40'),
('9ddd9b7d16a81a8c16a98b76f149ca7965e765ac9c627f50fd7b65fb660cffcd7df335925a7bfa30', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 07:51:15', '2020-05-16 07:51:15', '2021-05-16 15:51:15'),
('9ed5328914bad9c9fe71df692522308da0623ac714c93b411d949a3cf229880e4189714b321f1408', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 00:50:18', '2020-05-15 00:50:18', '2021-05-15 08:50:18'),
('a1769a20e891e5b5cfa9eada19c34e945ec9aaa385bad5b2780ac52a5e816b6d0e878341275b18aa', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 06:26:05', '2020-05-16 06:26:05', '2021-05-16 14:26:05');
INSERT INTO `oauth_access_tokens` (`id`, `user_id`, `client_id`, `name`, `scopes`, `revoked`, `created_at`, `updated_at`, `expires_at`) VALUES
('a24d82fe9816d12a5135bb49489758b5ddc4ac5731f6fafbba20a4be8607e71a07a51197a4db5e00', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 06:41:08', '2020-05-16 06:41:08', '2021-05-16 14:41:08'),
('a29debcf2f7b2247783634826fd1e295e1197396b017fd9365d3728e765a35b16ebc1838e9bfd9dc', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 07:52:03', '2020-05-15 07:52:03', '2021-05-15 15:52:03'),
('a2b3abb5e412b3b6ae961dc64c9485060e3fd5dfd5d9c7b0afe9108595716b789d3b2f0914c5a3f1', 4, 1, 'Personal Access Token', '[]', 0, '2020-06-01 20:38:33', '2020-06-01 20:38:33', '2021-06-02 04:38:33'),
('a3fd353d3123ba77fdbbc6b89f3bd6e21ba3efe68690a5ba739399cc648151631e56f73ba653ae67', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 06:48:38', '2020-05-16 06:48:38', '2021-05-16 14:48:38'),
('a5a30b4ca3de985a4a63e0d836fbc24472acff9431c35ab98529e0602783298ed0cc71bc7f8e9324', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 05:51:01', '2020-05-15 05:51:01', '2021-05-15 13:51:01'),
('a5c39d2f0d1cf306cc5eb9abb351ca1c0da2a67af4f79f47b8330c17a0f3486b489e72a7b0225731', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 06:10:07', '2020-05-15 06:10:07', '2021-05-15 14:10:07'),
('a6af98c2b85ec49ddc85ffef7ebf68f126051e0152fba9cdda486b2f6c3e230779a1a2f7e771d576', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-20 08:54:17', '2020-05-20 08:54:17', '2021-05-20 16:54:17'),
('a6b08023567752c9ddad6cb2b9081e241fd62bf1a8c863cc2c88d4233290836e96c19a9e27541e1e', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 06:41:54', '2020-05-15 06:41:54', '2021-05-15 14:41:54'),
('a7d3732027893bf85a67637ced9991e11e07d0cc24c22fad59d0f598c9b78139bd3f83079cdcff85', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 06:32:23', '2020-05-16 06:32:23', '2021-05-16 14:32:23'),
('a85561371fa187f16e3f2f1efcdf8ea3da8fe406ac312555f4fde280e8f5bb88fd2ac36162b7a04e', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-17 07:45:43', '2020-05-17 07:45:43', '2021-05-17 15:45:43'),
('a87dd49e003778cb6aeb4f93d7a8361b42a779ee5813110992dab8eff4dd8538133dee15ca6c207b', 4, 1, 'Personal Access Token', '[]', 0, '2020-06-01 19:51:48', '2020-06-01 19:51:48', '2021-06-02 03:51:48'),
('a8ec09a46ecc2b9f90707bccefcc1c063485dc95f8b16949d0bb1f95f2621103c035ca9d4b0c6837', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 06:33:26', '2020-05-16 06:33:26', '2021-05-16 14:33:26'),
('a91183249d1572e689ea0cb04f01f60eaa1b6641474c02c6ba9663099a12c10ef338a9a1e3fe54de', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-17 23:35:40', '2020-05-17 23:35:40', '2021-05-18 07:35:40'),
('aa226ce5741b7ca270f8ada3b47f37b2734c867f0de2f53690158bf43a03239512d3e5cb11450ec7', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-17 05:49:45', '2020-05-17 05:49:45', '2021-05-17 13:49:45'),
('aa257c70cd6769d75c7ec851a3d6e12108d7fe49beaa17892263dfac7b88304c708b0dfc23919c1b', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 22:19:08', '2020-05-15 22:19:08', '2021-05-16 06:19:08'),
('aa39385c4306dda3f57d659c35e07103b1fdb1034dce3ef8a93c70b747d73889188dc19a47ac2e05', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 05:41:18', '2020-05-15 05:41:18', '2021-05-15 13:41:18'),
('ab1db6fb1eece14c25f43672c47f2807e8cb4d758b17a86fed8e8240223fdbcb4a47ac224d4f9586', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 00:40:12', '2020-05-15 00:40:12', '2021-05-15 08:40:12'),
('abb4fd54d1fc8721c180791194a5e29532012ff05ca29a34110e337243c6286cf3213f45e23f7160', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 00:56:31', '2020-05-15 00:56:31', '2021-05-15 08:56:31'),
('abd046e189e2578e5dfff7e9de881491a1eb5db0ec41b030d7143870af7722ab8bf27ac1b5c22fb3', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 07:58:57', '2020-05-15 07:58:57', '2021-05-15 15:58:57'),
('abfa02012b1f7acfb160e1fe03b5637a696e83bec96fe9fef51e01aea32fcf0646fa8b3c58714f98', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 05:43:40', '2020-05-16 05:43:40', '2021-05-16 13:43:40'),
('ac811d97fb8b8a84f368d797d95b80c6716c75a9fe80a5e510ab67115f69d0b5299018f6bd3387d4', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-17 05:10:55', '2020-05-17 05:10:55', '2021-05-17 13:10:55'),
('adb4d75efa1920c945d97d939f893539d65a1b1eb76604dda7320b8b8ad8882443a5e99fa9a0c870', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-16 04:35:51', '2020-05-16 04:35:51', '2021-05-16 12:35:51'),
('add12987ce8485d5b8cc639d2073a7b1564c91db802977113e7260de0aad02fb94e6fcfb3c250476', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 08:12:37', '2020-05-16 08:12:37', '2021-05-16 16:12:37'),
('af1f4b1769f6e84efd3fc0120dfa66f66543f57b647e31568048a0a84581e83cb7579be7f5ee8f2d', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-16 04:22:11', '2020-05-16 04:22:11', '2021-05-16 12:22:11'),
('b0424273667d386994d000eabdb77c2c210240f348fea3cba89ae599b54ae5d35f0941f2f0ac51ea', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-20 08:10:47', '2020-05-20 08:10:47', '2021-05-20 16:10:47'),
('b13e0dd9e5592b7888cf63416ee443e1b29526852e080e983ad55df3fac25e02f0cd3f95dd133eaf', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 08:11:29', '2020-05-16 08:11:29', '2021-05-16 16:11:29'),
('b19008b7a8d1cd2adebd9cf12f0cac337bc7dc39d0208293560c8442c92ae02da91a72bfc23e8780', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-16 03:30:03', '2020-05-16 03:30:03', '2021-05-16 11:30:03'),
('b1f83cc8e0aa6e5d26a17075652a712f0d944239a8e0d55b3739797758bceaa2f389ad517303223d', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 08:17:07', '2020-05-16 08:17:07', '2021-05-16 16:17:07'),
('b215369bf60e4388b6b678fc8853f56eba777d0ec8133db786f8bf8be45518fac99081e5f08e5a1b', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-17 23:51:53', '2020-05-17 23:51:53', '2021-05-18 07:51:53'),
('b245c83ae7fca9072ea7fef5a1e68b7affaad70b269bf87869938b907bdaf4085a2636a7745d0a13', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-16 03:42:25', '2020-05-16 03:42:25', '2021-05-16 11:42:25'),
('b3de8184323c9289a89affb604b00e85ccb52ff1dc0138d7a9fd298ecf2c7d1d63ac09bd39babcec', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 03:28:05', '2020-05-15 03:28:05', '2021-05-15 11:28:05'),
('b41612d5d1682bfddedc57c659b01ae58714d6f7780a141f60ce330774f2e38b01346badb6eaf737', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 03:47:24', '2020-05-15 03:47:24', '2021-05-15 11:47:24'),
('b43896ccc5623e992e8f676850f5a99648ea33a5647cfe8b0d3dadf2e54cf5797e99be5df89000a9', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 07:07:04', '2020-05-15 07:07:04', '2021-05-15 15:07:04'),
('b456d8df2e69a203a78a875514988121d0c6937bfd247d78238db86f0c659aea357e578b174cb2da', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-14 23:49:27', '2020-05-14 23:49:27', '2021-05-15 07:49:27'),
('b48dda82481627c9b9c6b94f130b1c9317aa5e3a3dae8f2245d3c0c3e05ebce0ae82d2a047ad56c8', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 06:09:08', '2020-05-15 06:09:08', '2021-05-15 14:09:08'),
('b520bde84504294fbe52bebb69fdd1c3b180c65b512dd6a4892fa9404f500802305a422f8a374fa3', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-17 06:25:05', '2020-05-17 06:25:05', '2021-05-17 14:25:05'),
('b5c440acf5c710af2e6e02108a18fa51e3ca17787b00628438db536a26c893f3109cea69cf5cb2fd', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-20 08:11:03', '2020-05-20 08:11:03', '2021-05-20 16:11:03'),
('b5e002d64e4cb20ba743d2f8e2c2ded5e2f6187b92c42bd734174c4bb168c31d164f485a462baddb', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 06:26:11', '2020-05-16 06:26:11', '2021-05-16 14:26:11'),
('b6816c59fe3e980432bd40acf6515ed2b05c6ca02e2c8d33a6c2f66df1b6dca5789b736d4c0043c8', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-17 05:53:46', '2020-05-17 05:53:46', '2021-05-17 13:53:46'),
('b78e47b4bcad7c7e9551f8b12648bff28da6587d5c3b7afe7e8af5f66f55e0ddf709857f7e7db2e1', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 01:13:42', '2020-05-15 01:13:42', '2021-05-15 09:13:42'),
('b84faafbb5816772c5197900db3e8f9b335d089915502dbaedec280c5898f8f111d978639d640ca1', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 06:19:20', '2020-05-15 06:19:20', '2021-05-15 14:19:20'),
('ba211a8128a8d2ab1deb493f625c2e6c373af9bf7e1a7e44fedafc38d9cbb0318aa9b1b311d71773', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 03:41:58', '2020-05-15 03:41:58', '2021-05-15 11:41:58'),
('baa47fd04ab9121a3379d37c57144de6ab89b04556cd2e8bd09e6f668b1595877021de76fd6b62c9', 4, 1, 'Personal Access Token', '[]', 0, '2020-06-01 20:07:52', '2020-06-01 20:07:52', '2021-06-02 04:07:52'),
('bae86f1ef5b01c574bbc0e656762e3cfea472e3beb87d450f99c9539a473cc11eb9444954f9a73af', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 07:49:48', '2020-05-15 07:49:48', '2021-05-15 15:49:48'),
('bbf5982c76a535ee84e6b6bdcb999b6efd69368c0e9a7fe370113ec4257377cefad85acf232bce07', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 06:13:31', '2020-05-16 06:13:31', '2021-05-16 14:13:31'),
('bc9b71817ca2c627c39230619a40e8d603070dd6ac0e4e5e1fac7f970497a93b9df7253f6a1f7b86', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 05:24:45', '2020-05-16 05:24:45', '2021-05-16 13:24:45'),
('bca52c910fe52641eb506547b6fd4689279459ac8d6d2aad8a9a8afdf62b1d6f78c025b5ae92367e', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 06:30:34', '2020-05-15 06:30:34', '2021-05-15 14:30:34'),
('bdf9b827552b99c87749489ccccf6ef7cc1e638ff27277099300e922080c65bd5f437ae63d7e9f46', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-20 08:14:17', '2020-05-20 08:14:17', '2021-05-20 16:14:17'),
('be52aae75fc162b5b717a7cff44913814cbec3a84004cd6c9e0fafeea1059083b26281ae392ff4db', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 07:03:27', '2020-05-16 07:03:27', '2021-05-16 15:03:27'),
('be77a8f17e42404669664efb43d50415f5ccc64226882c1a8f5fe051f41c1ca29344f3ce15381ce7', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-17 06:49:48', '2020-05-17 06:49:48', '2021-05-17 14:49:48'),
('bf2350c0279c3ed69bb688c6cb4dffc1f9040e59ec34b882112b49400ef7dc4abb281f8d316e5d9d', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 05:24:59', '2020-05-16 05:24:59', '2021-05-16 13:24:59'),
('c188183b39831d27cf0de2b06a685fcc5291533fb7b872a9d10d8e9050699426dcc979fe2a0bfaa4', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 07:19:50', '2020-05-16 07:19:50', '2021-05-16 15:19:50'),
('c26f09e47b4822f276cb153d53e92e7e310ad381fad841c5339eb5596a65aa5418ac61ff8bf69c1c', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-14 23:52:46', '2020-05-14 23:52:46', '2021-05-15 07:52:46'),
('c2b4371bf5a6fa0fcbf59cad36593ec703b8361e63032cf089c15db3110a65e274269aab9e59aacb', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-16 04:49:10', '2020-05-16 04:49:10', '2021-05-16 12:49:10'),
('c3af4ac4ca67a3c4fb9f0cfe2cecd45b17a7b701451e69ffa8ca82031da3619a27230ac868a3a68a', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 06:16:01', '2020-05-16 06:16:01', '2021-05-16 14:16:01'),
('c4d6e6136d5c3ddd7ae9a949017edffc821230825eaf48b6afb30929c074a2df9e9bae628491d281', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 00:02:44', '2020-05-15 00:02:44', '2021-05-15 08:02:44'),
('c4de4bad1a0458c57066afd184f96bf9557baa0c417b9f2c6511a8ab4db2717be3fee0699856940a', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-17 23:50:41', '2020-05-17 23:50:41', '2021-05-18 07:50:41'),
('c6586878b931d5b4b4f1c0d96e93ba1230645e6d63cf79a1df0e809c6f1abe4da90b0dc0b9ed7ece', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 03:28:56', '2020-05-15 03:28:56', '2021-05-15 11:28:56'),
('c681093fdaea7d2f736d7fb36fa31f65491fb24e57b85f1fea0c440116e0439432de2904f1a2691f', 4, 1, 'Personal Access Token', '[]', 0, '2020-06-01 20:05:50', '2020-06-01 20:05:50', '2021-06-02 04:05:50'),
('c690d8405f478e2fc1337f9db32333b7848d561f409618e31ec8d00c6d790ba89c4d18611a5e2988', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 06:08:10', '2020-05-15 06:08:10', '2021-05-15 14:08:10'),
('c70cb90cc7577e9f08680c417a0f51b86a35dcb144106344d6acd968f5722a337dc619d9d108f102', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-17 05:52:50', '2020-05-17 05:52:50', '2021-05-17 13:52:50'),
('c7556ee9314ac8393607f5f8e0d6f28807d87d025735a38650da0a519b0c856c3965b8c231b67bee', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-17 06:47:31', '2020-05-17 06:47:31', '2021-05-17 14:47:31'),
('c85bc0d7abda01257da65fc57c760b4f62478e0685de6d8cf84936621860fbafeeb5be51a10a434f', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-16 04:58:50', '2020-05-16 04:58:50', '2021-05-16 12:58:50'),
('c8e10b38b61f3ef00356853a169e1dfe7c46670768402610eaaa485b88a50389b1d95ad0e8e9ac19', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-20 08:16:30', '2020-05-20 08:16:30', '2021-05-20 16:16:30'),
('c9b507327e0b91551ad47de78e7d6a1c113a2b47bfb133c00bce791a0265728daa012cdceec13baa', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 05:39:12', '2020-05-16 05:39:12', '2021-05-16 13:39:12'),
('ca188d34916c66540abcb6d95b3b78f18daaee0a9e1769a76b4616c0b25167c0d26f0c716e70ca78', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 06:07:50', '2020-05-16 06:07:50', '2021-05-16 14:07:50'),
('cb756847887f3578582bf29420448d30ecd5ca99e8eee8663313db7d0591c9cd260ad0466d3722ca', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 05:19:25', '2020-05-16 05:19:25', '2021-05-16 13:19:25'),
('ccad1a7b427ddfe277063f000e7ef5fe9f998b3cea67493b921debc2386ee6a7de2f0c330345b778', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-16 04:38:35', '2020-05-16 04:38:35', '2021-05-16 12:38:35'),
('ccb0b67aed88e024009ee4be3ace630f4afebc16e9472a04d290997722ad7066d008f151f6d4a7e1', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 07:58:10', '2020-05-15 07:58:10', '2021-05-15 15:58:10'),
('cd41997fde0a5da2caa8e4b41d569172ce4f1d2f5e776a1509091d2af41f036989b6468624d15f2f', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 05:41:36', '2020-05-16 05:41:36', '2021-05-16 13:41:36'),
('ce2c3560d467fb0788fe354df2881930bc1bf042a5f453d34f938b858b08650d1eb57d0880694767', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 05:57:59', '2020-05-16 05:57:59', '2021-05-16 13:57:59'),
('ce6ff7659078044f03e40698a5aa07bfaf8624ce0d992a405921b291fae1f7fdeeb5328dcd890d29', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 06:29:52', '2020-05-15 06:29:52', '2021-05-15 14:29:52'),
('cf22a2912ea0c5770455366ade4918a6083fccbc8acae396afce6e1834b1fcb677dc464eb9bda562', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 08:16:15', '2020-05-16 08:16:15', '2021-05-16 16:16:15'),
('cf5878719b8961ef90d71ba8ecad09c020fbec2ec29f8061822f59a1a21650484f0ac94d48851047', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 08:36:09', '2020-05-16 08:36:09', '2021-05-16 16:36:09'),
('cfbe97dff34d0dd55d81a526c49ca9e9b6fb66fe7083d3281b6165fdadd96e5878d54883e1d977a9', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-20 08:36:34', '2020-05-20 08:36:34', '2021-05-20 16:36:34'),
('cfe88e95c8e15465d06fccf59215f2e8a2b1944e3ed6a95456f0abd06bc3832e763902c595181cc3', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 07:41:51', '2020-05-16 07:41:51', '2021-05-16 15:41:51'),
('d055a31c1dc56cb6d2e05e932ff7168e3adb4b8e05330edde0f64000b167b9e103ce5866f9b2766f', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-17 23:38:48', '2020-05-17 23:38:48', '2021-05-18 07:38:48'),
('d07b3fb1b2c1ff5dfdd88f5578d2067dd54bfb5631cf9e302961ee1219f6487a2179db8cb80ec827', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 06:14:33', '2020-05-16 06:14:33', '2021-05-16 14:14:33'),
('d18e397613d784a317658f5f48f013211e48f7974f0785d1bca636321692f5c25be3fcf884c691e8', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 03:33:20', '2020-05-15 03:33:20', '2021-05-15 11:33:20'),
('d2af285619a7471254e227ca7bd165b32d2add63820d620d386df017df7873cbc0f803fbff993560', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-17 23:17:07', '2020-05-17 23:17:07', '2021-05-18 07:17:07'),
('d3794144f475cef85c452f5df3cb6f79df23a3661f746f7df85105a52b7a3e011736ef34330a4a21', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 05:44:34', '2020-05-15 05:44:34', '2021-05-15 13:44:34'),
('d4919d889fd2c3466546a43d571ab1db7d09bec5660f78065353b5642e7cadd59448dc0b23585eb3', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-16 05:04:29', '2020-05-16 05:04:29', '2021-05-16 13:04:29'),
('d4b1a0e9c7dcd3ede9038201f16f2d1044ae19de642721c6e530d12c25a7c66e773d8d5b2a0bad4f', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 06:52:44', '2020-05-16 06:52:44', '2021-05-16 14:52:44'),
('d5106decb82c8d205bb5cbc7d62748bc2353fd773e419b8e5e25b238af1851dc7a3391ce2f18f100', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 00:57:24', '2020-05-15 00:57:24', '2021-05-15 08:57:24'),
('d5ef9f4ab244e5bc123333b887eb812f2171537d716b30578ebae9329446cf2007431af67f2df28b', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 06:06:09', '2020-05-15 06:06:09', '2021-05-15 14:06:09'),
('d717c67dadb822de5b0734380e4ef71fdca5555c9a54519b05562fc6c7c43cf49019f8813263f64f', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-16 05:10:52', '2020-05-16 05:10:52', '2021-05-16 13:10:52'),
('d71ada75c4538d85fe17e26b65640470a4f85175995df97a72332d714ad62701aab333c2cfc8a106', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-17 23:29:52', '2020-05-17 23:29:52', '2021-05-18 07:29:52'),
('d74f25b82c5203d5f2676a19a73758cf234082ddf6366c3320e230bb4605ab216238d0b3351d08a3', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-17 05:50:28', '2020-05-17 05:50:28', '2021-05-17 13:50:28'),
('d7d3c8c9afdc5963281b309d626253ef53acaf8cca7b37a5bd65d4b1cafba0048659b90be03213c0', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-20 08:26:31', '2020-05-20 08:26:31', '2021-05-20 16:26:31'),
('d874e6050f62e634881c085061ecfc628d8295cc8a98f750faee027943e082c9f7a32910cbd65b5a', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-16 03:43:23', '2020-05-16 03:43:23', '2021-05-16 11:43:23'),
('d8b7bbadc9df23a34b3b0f34adf08d5939e105f971820da93339f01e6342921e1115ea7e9bd99728', 4, 1, 'Personal Access Token', '[]', 0, '2020-06-01 20:57:33', '2020-06-01 20:57:33', '2021-06-02 04:57:33'),
('d9b35b278386532f5389dce4d6e79ce042aa74a0af9d273afb6f20c8e898b73c030e9a4e48f86b0e', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 06:32:34', '2020-05-16 06:32:34', '2021-05-16 14:32:34'),
('da460f6bf449388741b419cfb9e09c52e15ddb2964e3b03f1ff41f10188d3b02b7ff4475559aa78f', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 00:24:25', '2020-05-15 00:24:25', '2021-05-15 08:24:25'),
('da5d09ddb973bd801ec9b065f74d76fcedfcdd4187e8753cf2fa20fe235dfb66dfc096b021515a47', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-17 06:37:45', '2020-05-17 06:37:45', '2021-05-17 14:37:45'),
('db3716e7e0c4db36dc774947453b84aa93094356a10216ec770cfc6e22e73b61d58a20f3119e4abc', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 07:39:12', '2020-05-15 07:39:12', '2021-05-15 15:39:12'),
('dbc12ac3661ea85849bcc92ec7d3f7c658e62dbdbef04e24b9b4521a01e21ef99a276f46a682c5e5', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 05:43:22', '2020-05-15 05:43:22', '2021-05-15 13:43:22'),
('dc321ea7d2cea5ff080ebf7c8584c7f6263f88e0577a72b20fbb45e8f29786164b12f0aef03a1555', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-17 23:49:41', '2020-05-17 23:49:41', '2021-05-18 07:49:41'),
('dca5c52b06c018b9df15cb4bb0e82be820c79b5a13ef7e4964a3d8895f11ad5c72b7b9999f854787', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 07:22:20', '2020-05-16 07:22:20', '2021-05-16 15:22:20'),
('dd93d11bc5ebdd4e8e9e6fbf835946243a1ec3bc93a5458e1d619031c9bc1f67481d365ae07d82b0', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-16 04:22:47', '2020-05-16 04:22:47', '2021-05-16 12:22:47'),
('ddccabc8b279d40de6d391e0b75dc3ba3020f621f62f20346c99823dfff2bea6504590234eae29ba', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-17 06:03:42', '2020-05-17 06:03:42', '2021-05-17 14:03:42'),
('ddefe8a0bb630c86d3c3de6fe2947d3250299d370024643f43cc5c69420b9c6b31c79c2a1bd05829', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-17 04:16:18', '2020-05-17 04:16:18', '2021-05-17 12:16:18'),
('ddfc17ccb6c151b8131bd6fa82bb3cb4f16daf558a7c2c90e614fdb9afa1b7b6f543ae661f072214', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 06:32:33', '2020-05-16 06:32:33', '2021-05-16 14:32:33'),
('de1cff6b677ea7690df912a92db9970c1f156caf1d1d4ca13c5080202bb97dec425b09942c53f542', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-16 04:38:49', '2020-05-16 04:38:49', '2021-05-16 12:38:49'),
('deb559b09c9241d09cfd48f2a30358c3bab7358bbaab9d25e1fa264002a4d19a6929baaeb2f9c876', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-16 04:52:28', '2020-05-16 04:52:28', '2021-05-16 12:52:28'),
('e078eb0a51f2f4f5599954afa21b06d623b3b6687f27e40df5518b1d9e163e100ff9110f85decf42', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-14 23:39:34', '2020-05-14 23:39:34', '2021-05-15 07:39:34'),
('e0e69ad49279fbf338f29875cc985d48a164dcb2f484c841c0d42b9fa54e8b5bfd02229a6ca3de8b', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 03:52:43', '2020-05-15 03:52:43', '2021-05-15 11:52:43'),
('e11aebc41c06b597d71f2695c206170576bba65ae5138479645568eff2fbe89b8d071e6f3dc438e6', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-20 08:52:21', '2020-05-20 08:52:21', '2021-05-20 16:52:21'),
('e1791e959a9fd7745753804ad8ebbfdd22cd7f8cb1abb78f85e49edda2a162895cf224c13926a733', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 03:47:06', '2020-05-15 03:47:06', '2021-05-15 11:47:06'),
('e2116e3272c945d5c77a90e92e1228bdfa0aa8334431023cc7fe8d45df81bb5bd4fa88943e0a251b', 4, 1, 'Personal Access Token', '[]', 0, '2020-06-01 19:50:59', '2020-06-01 19:50:59', '2021-06-02 03:50:59'),
('e3c7e7305b4c73fb23a3be90a17b686fdaa6527eb91312499ff0df89e011137c41cea65e80cb2c38', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 03:30:51', '2020-05-15 03:30:51', '2021-05-15 11:30:51'),
('e40b6d9d2944881d3476d8401a865300a43f4f9d4658eaaf4804b1be06bbcc447a1b8de627e04150', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 00:05:31', '2020-05-15 00:05:31', '2021-05-15 08:05:31'),
('e4861bba8fae0eb0c29391a31e803171e9cd760671f630578b22e5b13313807fb13bde063f150183', 4, 1, 'Personal Access Token', '[]', 0, '2020-06-01 20:09:27', '2020-06-01 20:09:27', '2021-06-02 04:09:27'),
('e4d886108bb6297931100601a1ee4a8470d5e7506bcf562196c95862beaa33bee3e0e1b244cc8c63', 4, 1, 'Personal Access Token', '[]', 0, '2020-06-01 20:33:14', '2020-06-01 20:33:14', '2021-06-02 04:33:14'),
('e6361bceba761c86f5c86bee0182e8dfc6e39d487da3976d84cf02f8856ce1b99e77bab7c295bfa4', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-16 04:09:48', '2020-05-16 04:09:48', '2021-05-16 12:09:48'),
('e638fa8f8a72b5fc0c10217cc75f0febd706610738c40f298601ec6fb99289a4c05b18a8f5a48429', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-17 05:56:11', '2020-05-17 05:56:11', '2021-05-17 13:56:11'),
('e78bf6deb2b9e7777853f8674ec5174ca2bad38e85a68d9a5f92b2ac61b12c717dffd23949c8eae9', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 06:32:44', '2020-05-15 06:32:44', '2021-05-15 14:32:44'),
('e8f1a1b969b740511af2e13f76b0859ceeed57713931d5706471fb7f5c33204ffdc6077aebf85d4f', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-16 04:03:11', '2020-05-16 04:03:11', '2021-05-16 12:03:11'),
('e9e42859b8d42b07e88b17c0e641d2734fde455ea4a42b4b8ed55d0235e3317735dd043e63a4dc3b', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 07:46:41', '2020-05-15 07:46:41', '2021-05-15 15:46:41'),
('ec4c80ad1ff9e1990e7fb257727c7f8e75140c6130734d162ad6793caaf45269c8abc68d7e790354', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 22:14:54', '2020-05-15 22:14:54', '2021-05-16 06:14:54'),
('ec660025771d48ef059410841030b8b9a8e8b60414525bcc33aaa9fd708a47cffa53655848e7f982', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 07:39:48', '2020-05-16 07:39:48', '2021-05-16 15:39:48'),
('ecbe813c632c329a7fe7796933f1e1d29927de6cbf1f97022ef659ad9a070b45b9239d897fea7cca', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-17 05:32:34', '2020-05-17 05:32:34', '2021-05-17 13:32:34'),
('ed016c91d1d7bafd746320c17a1a7c96bb42f486ab909f4357965bcf0a051338c1a4c4a85edc608d', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 07:43:34', '2020-05-16 07:43:34', '2021-05-16 15:43:34'),
('ed18afe6f6fb22560c8ee1746f031e8d149a9aef31ce170a0a6c01071643253dd35ecfc41caeebb7', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 05:40:10', '2020-05-15 05:40:10', '2021-05-15 13:40:10'),
('ed2e5742b55ad2272ebe40b722bfeb8f269fc52f56e8f21deb6e9290fd3d6a6fdc165b18e09e663c', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-16 03:44:43', '2020-05-16 03:44:43', '2021-05-16 11:44:43'),
('edbd144479964661b34576d5c916eacd1cc44b90f51dfb10c8788c73d2f99102d1d17c0d94c6050c', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 07:30:58', '2020-05-16 07:30:58', '2021-05-16 15:30:58'),
('eea6a9e191a64ea3d1c24cbdb7df694942d67a87a57cf9f60b179d9ea5f6ac288014a82f8ca85b81', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 05:35:28', '2020-05-16 05:35:28', '2021-05-16 13:35:28'),
('efad91e2d71e85d9a21bf806dda638ad11c6a33f8fed714e18853b46b628b8c485ac6e5af2ab8d9e', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 05:40:34', '2020-05-16 05:40:34', '2021-05-16 13:40:34'),
('f04fc07df8593cea95be43adaecc68e4b8c199b4ebc5ed6f7dc42e9b384d858ec567ce4ae6ab31ab', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-16 04:10:46', '2020-05-16 04:10:46', '2021-05-16 12:10:46'),
('f0abdf6b3b60fd3a09ea3c71ed675ef40dabb9c41f276bfea5fcc93652eec61210177568377b14fb', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 07:48:48', '2020-05-16 07:48:48', '2021-05-16 15:48:48'),
('f0ddacad023870769a53f12812c0f16361ffaa8735ebd4dafc96857f8befd308cfb9ce179eb3c7f6', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 06:12:50', '2020-05-15 06:12:50', '2021-05-15 14:12:50'),
('f1c41958cba7ea4bef8957e189050382cb0ed1853f9e11ac39ee8b2e6699bc648bec20dc954e5d36', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 05:56:34', '2020-05-16 05:56:34', '2021-05-16 13:56:34'),
('f2b2f9b34f35020391f58764b5a1cf0fc734d182e975ee54e1695450df9e5b4896264f12143f7415', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-16 04:29:49', '2020-05-16 04:29:49', '2021-05-16 12:29:49'),
('f372a6530d17bce7aa42be5dcc06ad9c5d18db37fd7b3df8c61058e8808c36ce7c68556cdda3f3ea', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 07:26:39', '2020-05-16 07:26:39', '2021-05-16 15:26:39'),
('f3a7ff2b2cb5c65e0410fdbaef4cbb929464c593c79820bdd0c8e5ac43b1c60111ffad3509498cd2', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-17 06:06:51', '2020-05-17 06:06:51', '2021-05-17 14:06:51'),
('f4a57bccfd05425a5f0a28173e387a9be63e4b62721d71596acc5a3043bd117adfe855bd9db31c82', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 06:06:43', '2020-05-16 06:06:43', '2021-05-16 14:06:43'),
('f66e0bfd2cee5839d3766d2a1865b1908629f2a005e9ecc72fbacc2910df2bb97d52408455952dbc', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 06:22:45', '2020-05-15 06:22:45', '2021-05-15 14:22:45'),
('f68f58a22d1dcb50f33813e3341e2e2bf13a9db199a53a12b5ab6f774ed59f4673284298a9068f85', 4, 1, 'Personal Access Token', '[]', 0, '2020-06-01 20:16:23', '2020-06-01 20:16:23', '2021-06-02 04:16:23'),
('f6d60258e2787c403255ab515ed0e96f6cf67eceb552c43e6d327cff75adcb246de7f36b61174e2e', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 03:40:29', '2020-05-15 03:40:29', '2021-05-15 11:40:29'),
('f7907f6a7da1ae1838f82197ead028f5560aed6c821edd0ad75173d5bab58c7b97bc348b606cc534', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 06:18:10', '2020-05-16 06:18:10', '2021-05-16 14:18:10'),
('f88a63faeda7bf7399eb88bf33d98bef9a675e2362901e42ca5ed2ed3d8b0b6dcd00c4f386db72f1', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 08:12:11', '2020-05-16 08:12:11', '2021-05-16 16:12:11'),
('f923c3dcc95233a2a5b35fe82ad825d76fc5b6cde781a0af1ba467bd2d7d68821d0de94549112351', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 05:51:02', '2020-05-15 05:51:02', '2021-05-15 13:51:02'),
('fa4012b59d7f8a68c1670f7c7b9c6ca2c5d24aeaf899c576c4834637f9b27ef384b3d8445d6ae217', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 07:31:14', '2020-05-16 07:31:14', '2021-05-16 15:31:14'),
('fac0205e243819b3d18f622f3bff161f44bf0e036432fae2031fc4b007b3f6c50c3999113ea6e7ea', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 08:15:52', '2020-05-16 08:15:52', '2021-05-16 16:15:52'),
('faf2abf074d762e51f2f52d61e2fb251ee05f6c5fed7101a4544429a7d87411278a5b02b59fba281', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-17 07:44:19', '2020-05-17 07:44:19', '2021-05-17 15:44:19'),
('fb27fcdd597c1a3b1e44898e02e0ed44bc04ca5eb104a9a7c488702761ddda9e83128ee1b2c02645', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 06:52:29', '2020-05-16 06:52:29', '2021-05-16 14:52:29'),
('fb5a9b6db8fd57b92010f246fab253c954c0c345e58cef52ec87b6c2b8885092a05c7e0343d39401', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 07:34:35', '2020-05-16 07:34:35', '2021-05-16 15:34:35'),
('fc9a3c35a98ffeca4410ae04427ef67e16104f57e3ceae1cef17dbd5a1c0c0b93e32e468a0f0bcca', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 03:44:59', '2020-05-15 03:44:59', '2021-05-15 11:44:59'),
('fd9eaaf7da38f796640727db8ba4be657e927acaa44bd42989c015e68724f8dfcb6cba905e9168ca', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 06:09:48', '2020-05-16 06:09:48', '2021-05-16 14:09:48'),
('fe407bbe9d32ec34dd9f5757b2ffaeb6b660b40ed8c86bc9ebb9d45102d4c2afdd233523597a1e2d', 2, 1, 'Personal Access Token', '[]', 0, '2020-05-15 22:27:53', '2020-05-15 22:27:53', '2021-05-16 06:27:53'),
('fe4ebde1db2b8c2ec2ba6bcf81634bbdc5d1c10c2f01b5aa69d2b1a801f92e1a7a2a5be6846e8fcf', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-16 07:27:40', '2020-05-16 07:27:40', '2021-05-16 15:27:40'),
('fefee651cb917f1ba1ff63529714b1093cff0e58f042ba35a46fa6b4aa9a7af472bb6ddc510c97dd', 4, 1, 'Personal Access Token', '[]', 0, '2020-05-17 23:41:45', '2020-05-17 23:41:45', '2021-05-18 07:41:45');

-- --------------------------------------------------------

--
-- Struktur dari tabel `oauth_auth_codes`
--

CREATE TABLE `oauth_auth_codes` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `client_id` int(10) UNSIGNED NOT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `oauth_clients`
--

CREATE TABLE `oauth_clients` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `secret` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `redirect` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `personal_access_client` tinyint(1) NOT NULL,
  `password_client` tinyint(1) NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `oauth_clients`
--

INSERT INTO `oauth_clients` (`id`, `user_id`, `name`, `secret`, `redirect`, `personal_access_client`, `password_client`, `revoked`, `created_at`, `updated_at`) VALUES
(1, NULL, 'LapakPeduli Personal Access Client', '81egzKy10THO2Y9dwWoIs6ls6K2bDa29ED4n9VLG', 'http://localhost', 1, 0, 0, '2020-05-11 22:53:26', '2020-05-11 22:53:26'),
(2, NULL, 'LapakPeduli Password Grant Client', 'NtbvFxAIxWoDzPHp1Ki4diVd3r4cE3KSQlKbKGU3', 'http://localhost', 0, 1, 0, '2020-05-11 22:53:26', '2020-05-11 22:53:26');

-- --------------------------------------------------------

--
-- Struktur dari tabel `oauth_personal_access_clients`
--

CREATE TABLE `oauth_personal_access_clients` (
  `id` int(10) UNSIGNED NOT NULL,
  `client_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `oauth_personal_access_clients`
--

INSERT INTO `oauth_personal_access_clients` (`id`, `client_id`, `created_at`, `updated_at`) VALUES
(1, 1, '2020-05-11 22:53:26', '2020-05-11 22:53:26');

-- --------------------------------------------------------

--
-- Struktur dari tabel `oauth_refresh_tokens`
--

CREATE TABLE `oauth_refresh_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `access_token_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `ongkirs`
--

CREATE TABLE `ongkirs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `lapak_id` int(11) NOT NULL,
  `kecamatan_id` int(11) NOT NULL,
  `besar_ongkir` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `ongkirs`
--

INSERT INTO `ongkirs` (`id`, `lapak_id`, `kecamatan_id`, `besar_ongkir`, `created_at`, `updated_at`) VALUES
(5, 7, 3, 10000, '2020-05-10 03:44:22', '2020-05-10 03:44:22'),
(6, 7, 1, 5000, '2020-05-10 03:44:44', '2020-05-10 03:44:44'),
(7, 4, 1, 5000, '2020-05-11 06:51:30', '2020-05-11 06:51:30');

-- --------------------------------------------------------

--
-- Struktur dari tabel `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `produks`
--

CREATE TABLE `produks` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `kode_produk` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lapak_id` int(11) NOT NULL,
  `nama_produk` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `qty` int(11) NOT NULL,
  `satuan` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `harga_jual` int(11) NOT NULL,
  `kategori_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gambar_produk` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deskripsi_produk` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `metode_bayar` int(11) NOT NULL,
  `status_produk` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `priority` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `produks`
--

INSERT INTO `produks` (`id`, `kode_produk`, `lapak_id`, `nama_produk`, `qty`, `satuan`, `harga_jual`, `kategori_id`, `gambar_produk`, `deskripsi_produk`, `metode_bayar`, `status_produk`, `priority`, `created_at`, `updated_at`) VALUES
(19, '4.5-1', 4, 'Baju Covid', 6, 'buah', 150000, '5', '1588680205_1587627950_a57c9bdf81a4f625f517051902b635ab.jpg', 'Tersedia ukuran S, M, L, XL dan warna Hitam, Putih, Merah dan Grey', 1, 'tersedia', 0, '2020-05-05 04:03:25', '2020-05-20 07:09:06'),
(20, '4.5-2', 4, 'Kaos Helter Skelter', 10, 'Buah', 130000, '5', '1588748049_1587628021_Helter Skelter_scaled.jpg', 'Tersedia ukuran M, L, XL\r\nwarna Hitam, Putih, Merah', 1, 'tersedia', 0, '2020-05-05 22:54:09', '2020-05-05 22:54:09'),
(21, '4.5-3', 4, 'Kaos Youtuber', 10, 'buah', 130000, '5', '1588748097_1587628251_155193873_65230961-0829-49f7-8afe-e7bb11df0c32_946_946.jpg', 'Tersedia ukuran S, M, L, XL\r\nwarna Merah, Putih, Hitam', 1, 'tersedia', 0, '2020-05-05 22:54:57', '2020-05-05 22:54:57'),
(22, '7.5-1', 7, 'Jilbab anak 1', 25, 'Buah', 60000, '5', '1588943787_45436396_0e90a135-39d3-4712-9622-39e345460699_600_600.jpg', 'Tersedia warna Pink, Tosca, Biru, Putih, Hijau', 1, 'tersedia', 0, '2020-05-08 05:16:27', '2020-05-08 05:16:27'),
(23, '7.5-2', 7, 'Jilbab anak arsyila', 25, 'Buah', 65000, '5', '1589113531_BBH-Jilbab-Anak-Arsyila-Pink-500x500.jpg', 'Tersedia warna Pink, Merah, Putih, Hijau, Hitam', 1, 'tersedia', 0, '2020-05-10 04:25:31', '2020-05-10 04:25:31'),
(24, '5.9-1', 5, 'Jalangkote Special', 50, 'Biji', 1500, '9', '1589790308_b7826568-4713-47d3-81f0-e45bae086076.jpeg', 'Jalangkote spesial', 1, 'tersedia', 0, '2020-05-18 00:25:08', '2020-05-18 00:25:08');

-- --------------------------------------------------------

--
-- Struktur dari tabel `superadmins`
--

CREATE TABLE `superadmins` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nama` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `superadmins`
--

INSERT INTO `superadmins` (`id`, `nama`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'aswik', 'kolakawee@gmail.com', NULL, '$2y$10$lNeQkJUicOSiysWRt265AOdEiMAOko179BihLLphp7YRlKAgkJfEG', NULL, '2020-04-28 16:32:28', NULL);

-- --------------------------------------------------------

--
-- Struktur dari tabel `transaksis`
--

CREATE TABLE `transaksis` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `no_transaksi` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tanggal_order` date NOT NULL,
  `tanggal_transaksi` date NOT NULL,
  `tgl_expired` date DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `produk_id` int(11) NOT NULL,
  `lapak_id` int(11) NOT NULL,
  `qty_produk` int(11) NOT NULL,
  `kecamatan_id` int(11) NOT NULL,
  `alamat_pengantaran` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `request_khusus` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `metode_bayar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bukti_bayar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status_transaksi` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `transaksis`
--

INSERT INTO `transaksis` (`id`, `no_transaksi`, `tanggal_order`, `tanggal_transaksi`, `tgl_expired`, `user_id`, `produk_id`, `lapak_id`, `qty_produk`, `kecamatan_id`, `alamat_pengantaran`, `request_khusus`, `metode_bayar`, `bukti_bayar`, `status_transaksi`, `created_at`, `updated_at`) VALUES
(45, 'LapakPeduli-202005092000001', '2020-05-07', '2020-05-07', '2020-05-12', 2, 22, 7, 1, 3, 'Jl. Nanggomba No. 24 Kel. Silea', 'warna pink', 'cod', NULL, 'konfirm', '2020-05-09 07:15:25', '2020-05-09 07:25:45'),
(47, 'LapakPeduli-202005094000002', '2020-05-10', '2020-05-09', '2020-05-12', 4, 22, 7, 1, 3, 'Jl. Nanggomba No. 26 Kel. Silea', 'warna tosca', 'transfer', NULL, 'pending', '2020-05-09 08:13:45', '2020-05-09 08:13:45'),
(48, 'LapakPeduli-202005094000002', '2020-05-10', '2020-05-09', '2020-05-12', 4, 19, 4, 1, 3, 'Jl. Nanggomba No. 26 Kel. Silea', 'ukuran S, warna hitam', 'transfer', '1589092209_WhatsApp Image 2019-06-17 at 11.46.29.jpg', 'konfirm', '2020-05-09 08:13:45', '2020-05-11 09:07:35'),
(55, 'LapakPeduli-202005112000001', '2020-05-11', '2020-05-11', '2020-05-14', 2, 23, 7, 1, 3, 'Jl. Nanggomba No. 24 Kel. Silea', 'warna hitam', 'cod', NULL, 'konfirm', '2020-05-11 07:30:01', '2020-05-11 07:30:19'),
(56, 'LapakPeduli-202005112000001', '2020-05-11', '2020-05-11', '2020-05-14', 2, 19, 4, 1, 3, 'Jl. Nanggomba No. 24 Kel. Silea', 'ukuran L, warna hitam', 'cod', NULL, 'konfirm', '2020-05-11 07:30:01', '2020-05-11 07:31:09');

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `kode_user` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nama` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `no_kontak` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `kecamatan_id` int(11) NOT NULL,
  `alamat` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `foto_selfi` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pin` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `konfirm_pin` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status_user` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`id`, `kode_user`, `nama`, `email`, `email_verified_at`, `password`, `no_kontak`, `kecamatan_id`, `alamat`, `foto_selfi`, `pin`, `konfirm_pin`, `status_user`, `remember_token`, `created_at`, `updated_at`) VALUES
(2, '202005040000001', 'aswik', 'kolakawee@gmail.com', NULL, '$2y$10$657qq.AD6HPsON4nN/YvceNraH1bhnS7UYK6825QgHCyr/UBKqwaG', '081242912994', 3, 'Jl. Nanggomba No. 24 Kel. Silea', NULL, 'oSTml', 'konfirm', 'aktif', NULL, '2020-05-04 07:35:14', '2020-05-04 07:56:30'),
(3, '202005040000002', 'bara', 'bara.zaafarani@gmail.com', NULL, '$2y$10$grGvqOREa6JA7sFcPwGi3eqIzv.dVya1EgJsyPDvqKAuT9XgVwcc.', '65656232', 1, 'Jl. Ahmad Mustin I No. 187', NULL, 'YJhvU', 'konfirm', 'aktif', NULL, '2020-05-04 07:58:08', '2020-05-04 07:59:32'),
(4, '202005090000003', 'kiking', 'kiking@mail.com', NULL, '$2y$10$LZHFYEh/REM2C8gksfTHFezNkLc4Ih2Lg50wLcbucgqWd40ivh4bS', '3323232323', 3, 'Jl. Nanggomba No. 26 Kel. Silea', NULL, 'tEKQP', 'konfirm', 'aktif', NULL, '2020-05-09 08:07:47', '2020-05-09 08:08:13'),
(12, '202005140000004', 'khalid zeyn', 'newmeamboidea@gmail.com', NULL, '$2y$10$iEmQ3sataHJjRuTcgbPRneISml9AeUSTfenIC8iN9a368zI5c./PG', '08528229116523', 3, 'jl. nanggomba kel. silea', NULL, '2a3LT', 'konfirm', 'aktif', NULL, '2020-05-14 08:10:31', '2020-05-14 08:27:05');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `advertises`
--
ALTER TABLE `advertises`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `banks`
--
ALTER TABLE `banks`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `carts`
--
ALTER TABLE `carts`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `kategoris`
--
ALTER TABLE `kategoris`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `kecamatans`
--
ALTER TABLE `kecamatans`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `lapaks`
--
ALTER TABLE `lapaks`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `notifications_notifiable_type_notifiable_id_index` (`notifiable_type`,`notifiable_id`);

--
-- Indeks untuk tabel `oauth_access_tokens`
--
ALTER TABLE `oauth_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_access_tokens_user_id_index` (`user_id`);

--
-- Indeks untuk tabel `oauth_auth_codes`
--
ALTER TABLE `oauth_auth_codes`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `oauth_clients`
--
ALTER TABLE `oauth_clients`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_clients_user_id_index` (`user_id`);

--
-- Indeks untuk tabel `oauth_personal_access_clients`
--
ALTER TABLE `oauth_personal_access_clients`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_personal_access_clients_client_id_index` (`client_id`);

--
-- Indeks untuk tabel `oauth_refresh_tokens`
--
ALTER TABLE `oauth_refresh_tokens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_refresh_tokens_access_token_id_index` (`access_token_id`);

--
-- Indeks untuk tabel `ongkirs`
--
ALTER TABLE `ongkirs`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indeks untuk tabel `produks`
--
ALTER TABLE `produks`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `superadmins`
--
ALTER TABLE `superadmins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `superadmins_email_unique` (`email`);

--
-- Indeks untuk tabel `transaksis`
--
ALTER TABLE `transaksis`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `advertises`
--
ALTER TABLE `advertises`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `banks`
--
ALTER TABLE `banks`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT untuk tabel `carts`
--
ALTER TABLE `carts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `kategoris`
--
ALTER TABLE `kategoris`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT untuk tabel `kecamatans`
--
ALTER TABLE `kecamatans`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT untuk tabel `lapaks`
--
ALTER TABLE `lapaks`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT untuk tabel `messages`
--
ALTER TABLE `messages`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT untuk tabel `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT untuk tabel `oauth_clients`
--
ALTER TABLE `oauth_clients`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `oauth_personal_access_clients`
--
ALTER TABLE `oauth_personal_access_clients`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `ongkirs`
--
ALTER TABLE `ongkirs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT untuk tabel `produks`
--
ALTER TABLE `produks`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT untuk tabel `superadmins`
--
ALTER TABLE `superadmins`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `transaksis`
--
ALTER TABLE `transaksis`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;

--
-- AUTO_INCREMENT untuk tabel `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
