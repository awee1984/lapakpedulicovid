<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Kecamatan extends Model
{
    protected $table = 'kecamatans';

    public function ongkir()
    {
    	return $this->hasOne('App\Ongkir');
    }

    public function user()
    {
    	return $this->hasOne('App\User');
    }
}
