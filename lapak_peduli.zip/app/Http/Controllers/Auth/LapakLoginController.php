<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Http\Request;

class LapakLoginController extends Controller
{
    use AuthenticatesUsers;

    protected $guard = 'lapak';

    protected $redirectTo = '/lapak_home';

    public function __construct()
    {
        $this->middleware('guest')->except('logout');
    }

    public function guard()
    {
        return auth()->guard('lapak');
    }

    public function login(Request $request)
    {
        if (auth()->guard('lapak')->attempt(['email' => $request->email, 'password' => $request->password ])) {
            return redirect()->route('lapak_home');
        }


        return back()->withErrors(['email' => 'Email atau password tidak ada yang sesuai']);
    }
}
