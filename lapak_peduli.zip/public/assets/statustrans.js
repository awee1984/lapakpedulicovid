$(document).ready(function () {
    Echo.private(`user.{{Auth::id()}}`)
        // .listen('StatustransNotif', (e) => {
        .listen('StatustransNotif', (e) => {
            // console.log(e);
            $("#notif_status_order").show();
        });



    setInterval(function () {
        $(".berkedip").toggle();
    }, 600);

});
