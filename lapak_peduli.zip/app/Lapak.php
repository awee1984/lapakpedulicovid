<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;

class Lapak extends Authenticatable
{
    use Notifiable;

    protected $fillable = [
        'kode_lapak','nama_lapak','nama_owner', 'email', 'password', 'no_kontak','alamat', 'status'
    ];

    protected $hidden = [
        'password', 'remember_token',
    ];

    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    public function produk()
    {
    	return $this->hasOne('App\Produk');
    }

    public function bank()
    {
    	return $this->belongsTo('App\Bank');
    }

    public function cart()
    {
    	return $this->hasOne('App\Cart');
    }

    public function transaksi()
    {
    	return $this->hasOne('App\Transaksi');
    }
}
