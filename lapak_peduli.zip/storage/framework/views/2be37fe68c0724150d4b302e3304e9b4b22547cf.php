<!DOCTYPE html>
<html lang="zxx">
<head>
	<!-- Meta Tag -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name='copyright' content=''>
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<!-- Title Tag  -->
    <title>Lapak Peduli Covid19</title>
	<!-- Favicon -->
	<link rel="icon" type="image/png" href="images/favicon.png">
	<!-- Web Font -->
	<link href="https://fonts.googleapis.com/css?family=Poppins:200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&display=swap" rel="stylesheet">
	
	<!-- StyleSheet -->
	
	<!-- Bootstrap -->
	<link rel="stylesheet" href="<?php echo e(url('/')); ?>/assets/css/bootstrap.css">
	<!-- Magnific Popup -->
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/assets/css/magnific-popup.min.css">
	<!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/assets/css/font-awesome.css">
	<!-- Fancybox -->
	<link rel="stylesheet" href="<?php echo e(url('/')); ?>/assets/css/jquery.fancybox.min.css">
	<!-- Themify Icons -->
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/assets/css/themify-icons.css">
	<!-- Nice Select CSS -->
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/assets/css/niceselect.css">
	<!-- Animate CSS -->
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/assets/css/animate.css">
	<!-- Flex Slider CSS -->
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/assets/css/flex-slider.min.css">
	<!-- Owl Carousel -->
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/assets/css/owl-carousel.css">
	<!-- Slicknav -->
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/assets/css/slicknav.min.css">
	
	<!-- Eshop StyleSheet -->
	<link rel="stylesheet" href="<?php echo e(url('/')); ?>/assets/css/reset.css">
	<link rel="stylesheet" href="<?php echo e(url('/')); ?>/assets/style.css">
	<link rel="stylesheet" href="<?php echo e(url('/')); ?>/assets/mystyle.css">
  <link rel="stylesheet" href="<?php echo e(url('/')); ?>/assets/css/responsive.css">

	
	
</head>
<body class="js">
	
	<!-- Preloader -->
	<div class="preloader">
		<div class="preloader-inner">
			<div class="preloader-icon">
				<span></span>
				<span></span>
			</div>
		</div>
	</div>
	<!-- End Preloader -->
	
	
	<!-- Header -->
	<header class="header shop" style="background:#ef0000">
		<div class="middle-inner" style="background:#ef0000">
			<div class="container">
				<div class="row row justify-content-between">
					<div class="col-lg-2 col-md-2 col-12">
						<div class="logo">
							<a href="<?php echo e(route('index')); ?>"><img src="<?php echo e(url('/')); ?>/assets/images/lapakpeduli.png" alt="logo" width="200px"></a>
            </div>
          </div>
        </div>
			</div>
		</div>
	</header>
  <!--/ End Header -->
  
  <!-- content -->
  <div class="contact-us section">
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-lg-6 col-12">
          <div class="form-main" style="background-color:white;margin-top:50px;">
            <div class="title text-center">
              <h5>Daftarkan akun costumer</h5>
            </div>
            <form class="form" action="<?php echo e(url('/daftar_user')); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
              <div class="row">
                <div class="col-lg-12 col-12">
                  <div class="form-group">
                    <label style="font-size:10pt">Nama<span>*</span></label>
                    <input style="font-size:10pt" name="nama" type="text" placeholder="Nama" value="<?php echo e(old('nama')); ?>">
                    <?php if ($errors->has('nama')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nama'); ?>
                    <span class="help-block text-danger">Wajib diisi</span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                  </div>	
                </div>
                <div class="col-lg-12 col-12">
                  <div class="form-group">
                    <label style="font-size:10pt">Email<span>*</span></label>
                    <input style="font-size:10pt" name="email" type="email" placeholder="Email" value="<?php echo e(old('email')); ?>">
                    <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                    <span class="help-block text-danger">Wajib diisi</span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                  </div>	
                </div>
                <div class="col-lg-12 col-12">
                  <div class="form-group">
                    <label style="font-size:10pt">Nomor Handphone<span>*</span></label>
                    <input style="font-size:10pt" name="no_kontak" type="text" placeholder="Nomor Handphone" value="<?php echo e(old('no_kontak')); ?>">
                    <?php if ($errors->has('no_kontak')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('no_kontak'); ?>
                    <span class="help-block text-danger">Wajib diisi</span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                  </div>	
                </div>
                <div class="col-lg-12 col-12">
                  <div class="form-group">
                    <label style="font-size:10pt">Alamat<span>*</span></label>
                    <input style="font-size:10pt" name="alamat" type="text" placeholder="Alamat" value="<?php echo e(old('alamat')); ?>">
                    <?php if ($errors->has('alamat')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('alamat'); ?>
                    <span class="help-block text-danger">Wajib diisi</span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                  </div>	
                </div>
                <div class="col-lg-12 col-12">
                  <div class="form-group">
                    <label for="kecamatan_id" style="font-size:10pt">Kecamatan<span>*</span></label>
                    <br>
                    <select name="kecamatan_id" id="kecamatan_id" class="form-control">
                      <option value="">-- Pilih Kecamatan --</option>
                      <?php $__currentLoopData = $kecamatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kecamatan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($kecamatan->id); ?>" ><?php echo e($kecamatan->nama_kecamatan); ?></option>    
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php if ($errors->has('kecamatan_id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('kecamatan_id'); ?>
                    <span class="help-block text-danger">Wajib diisi</span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                  </div>	
                </div>
              
                
                <div class="col-lg-12 col-12">
                  <div class="form-group">
                    <label style="font-size:10pt">Password<span>*</span></label>
                    <input style="font-size:10pt" name="password" type="password" id="password" placeholder="Masukan kata sandi">
                    <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                    <span class="help-block text-danger">Wajib diisi</span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                  </div>	
                </div>
                <div class="form-check" style="margin-left:35px;">
                  <input class="form-check-input" type="checkbox" value="" id="check_password">
                  <label class="form-check-label" style="padding-left:0px;" for="check_password">
                    Tampilkan 
                  </label>
                </div>
                <div class="col-lg-12 col-12">
                  <div class="form-group">
                    <label style="font-size:10pt">Konfirmasi Password<span>*</span></label>
                    <input style="font-size:10pt" name="konfirmpassword" type="password" id="konfirmpassword" placeholder="Masukan kata sandi">
                    <?php if ($errors->has('konfirmpassword')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('konfirmpassword'); ?>
                    <span class="help-block text-danger">Wajib diisi</span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                  </div>	
                </div>
                <div class="form-check" style="margin-left:35px;">
                  <input class="form-check-input" type="checkbox" value="" id="check_konfirm_password">
                  <label class="form-check-label" style="padding-left:0px;" for="check_konfirm_password">
                    Tampilkan 
                  </label>
                </div>
                <div class="col-lg-12 col-12">
                  <div class="form-group">
                    <button type="submit" id="pendaftaran_user" class="btn btn-block btn-warning btn-md">Daftar</button>
                  </div>	
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- end content -->
  
  <!-- Start Footer Area -->
  
  <!-- /End Footer Area -->

  <!-- Jquery -->
  <script src="<?php echo e(url('/')); ?>/assets/js/jquery.min.js"></script>
  <script src="<?php echo e(url('/')); ?>/assets/js/jquery-migrate-3.0.0.js"></script>
  <script src="<?php echo e(url('/')); ?>/assets/js/jquery-ui.min.js"></script>
  <!-- Popper JS -->
  <script src="<?php echo e(url('/')); ?>/assets/js/popper.min.js"></script>
  <!-- Bootstrap JS -->
  <script src="<?php echo e(url('/')); ?>/assets/js/bootstrap.min.js"></script>
  <!-- Color JS -->
  <script src="<?php echo e(url('/')); ?>/assets/js/colors.js"></script>
  <!-- Slicknav JS -->
  <script src="<?php echo e(url('/')); ?>/assets/js/slicknav.min.js"></script>
  <!-- Owl Carousel JS -->
  <script src="<?php echo e(url('/')); ?>/assets/js/owl-carousel.js"></script>
  <!-- Magnific Popup JS -->
  <script src="<?php echo e(url('/')); ?>/assets/js/magnific-popup.js"></script>
  <!-- Waypoints JS -->
  <script src="<?php echo e(url('/')); ?>/assets/js/waypoints.min.js"></script>
  <!-- Countdown JS -->
  <script src="<?php echo e(url('/')); ?>/assets/js/finalcountdown.min.js"></script>
  <!-- Nice Select JS -->
  <script src="<?php echo e(url('/')); ?>/assets/js/nicesellect.js"></script>
  <!-- Flex Slider JS -->
  <script src="<?php echo e(url('/')); ?>/assets/js/flex-slider.js"></script>
  <!-- ScrollUp JS -->
  <script src="<?php echo e(url('/')); ?>/assets/js/scrollup.js"></script>
  <!-- Onepage Nav JS -->
  <script src="<?php echo e(url('/')); ?>/assets/js/onepage-nav.min.js"></script>
  <!-- Easing JS -->
  <script src="<?php echo e(url('/')); ?>/assets/js/easing.js"></script>
  <!-- Active JS -->
  <script src="<?php echo e(url('/')); ?>/assets/js/active.js"></script>
  <script src="<?php echo e(url('/')); ?>/assets/myscript.js"></script>
</body>
</html>
  <?php /**PATH C:\xampp\htdocs\lapak_peduli\lapak_peduli\resources\views/user/daftar.blade.php ENDPATH**/ ?>