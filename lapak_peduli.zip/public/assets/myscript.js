$(document).ready(function () {
    $('#check_password').click(function () {

        if ($(this).prop('checked')) {
            $('#password').attr('type', 'text');
        } else {
            $('#password').attr('type', 'password');
        }
    });

    $('#check_konfirm_password').click(function () {
        if ($(this).prop('checked')) {
            $('#konfirmpassword').attr('type', 'text');
        } else {
            $('#konfirmpassword').attr('type', 'password');
        }
    });

    $('#lihat_password').click(function () {
        if ($(this).prop('checked')) {
            $('#password_masuk').attr('type', 'text');
        } else {
            $('#password_masuk').attr('type', 'password');
        }
    });

    // menampilkan gambar produk upload
    $("#gambar_produk").change(function () {
        $("#pesan_gambar_produk").empty(); // To remove the previous error pesan_gambar_produk
        var file = this.files[0];
        var imagefile = file.type;
        var match = ["image/jpeg", "image/png", "image/jpg"];

        if (!((imagefile == match[0]) || (imagefile == match[1]) || (imagefile == match[2]))) {
            $("#pesan_gambar_produk").html("<p style='color:red'><strong>Jenis file tidak mendukung</strong>, silahkan pilih jpg, jpeg dan png</p>");
            return false;
        } else {
            var reader = new FileReader();
            reader.onload = imageIsLoaded;
            reader.readAsDataURL(this.files[0]);
            $("#pesan_gambar_produk").html("<p style='color:red'></p>");

        }
    });

    // menampilkan gambar edit produk upload
    $("#gambar_edit").change(function () {
        $("#pesan_gambar_edit").empty(); // To remove the previous error pesan_gambar_edit
        var file = this.files[0];
        var imagefile = file.type;
        var match = ["image/jpeg", "image/png", "image/jpg"];
        // var filename = $('#gambar_edit').val();

        if (!((imagefile == match[0]) || (imagefile == match[1]) || (imagefile == match[2]))) {
            $("#pesan_gambar_edit").html("<p style='color:red'><strong>Jenis file tidak mendukung</strong>, silahkan pilih jpg, jpeg dan png</p>");
            return false;
        } else {
            var reader = new FileReader();
            reader.onload = function (e) {
                $('#previewing_edit').attr('src', e.target.result);
                // $('#nama_gambar').val(filename);
                // $('#image_file').change(function() {
                //     var filename = $('#image_file').val();
                //     $('#select_file').html(filename);
                // });
            };
            reader.readAsDataURL(this.files[0]);
            $("#pesan_gambar_edit").html("<p style='color:red'></p>");

        }
    });



    // menampilkan gambar backdrop upload
    $("#file_backdrop").change(function () {
        $("#message_backdrop").empty(); // To remove the previous error message_backdrop
        var file = this.files[0];
        var imagefile = file.type;
        var match = ["image/jpeg", "image/png", "image/jpg"];

        if (!((imagefile == match[0]) || (imagefile == match[1]) || (imagefile == match[2]))) {
            $("#message_backdrop").html("<p style='color:red'><strong>Jenis file tidak mendukung</strong>, silahkan pilih jpg, jpeg dan png</p>");
            return false;
        } else {
            var reader = new FileReader();
            reader.onload = imageIsLoaded;
            reader.readAsDataURL(this.files[0]);
            $("#message_backdrop").html("<p style='color:red'></p>");

        }
    });

    // menampilkan upload bukti bayar
    $("#file_bukti_transfer").change(function () {
        $("#message_transfer").empty(); // To remove the previous error message_transfer
        var file = this.files[0];
        var imagefile = file.type;
        var match = ["image/jpeg", "image/png", "image/jpg"];

        if (!((imagefile == match[0]) || (imagefile == match[1]) || (imagefile == match[2]))) {
            $("#message_transfer").html("<p style='color:red'><strong>Jenis file tidak mendukung</strong>, silahkan pilih jpg, jpeg dan png</p>");
            $('#tombol_upload').hide();
            return false;
        } else {
            var reader = new FileReader();
            reader.onload = imageIsLoaded;
            reader.readAsDataURL(this.files[0]);
            $("#message_transfer").html("<p style='color:red'></p>");
            $('#tombol_upload').show();

        }
    });

    // menampilkan gambar selfie upload
    // $("#fotoselfie").change(function () {
    //     $("#pesanfoto").empty(); // To remove the previous error pesanfoto
    //     var file = this.files[0];
    //     var imagefile = file.type;
    //     var match = ["image/jpeg", "image/png", "image/jpg"];

    //     if (!((imagefile == match[0]) || (imagefile == match[1]) || (imagefile == match[2]))) {
    //         $("#pesanfoto").html("<p style='color:red'><strong>Jenis file tidak mendukung</strong>, silahkan pilih jpg, jpeg dan png</p>");
    //         return false;
    //     } else {
    //         var reader = new FileReader();
    //         reader.onload = imageIsLoaded;
    //         reader.readAsDataURL(this.files[0]);
    //         $("#pesanfoto").html("<p style='color:red'></p>");

    //     }
    // });

    // menampilkan gambar selfie
    function imageIsLoaded(e) {
        $('#previewing').attr('src', e.target.result);
        $('#previewing').attr('width', '300px');
    };



    // menampilkan detail produk di form edit produk
    $('#editprodukModal').on('show.bs.modal', function (event) {
        var button = $(event.relatedTarget)
        var id = button.data('id')
        var nama_produk = button.data('nama_produk')
        var kategori = button.data('kategori')
        var satuan = button.data('satuan')
        var qty = button.data('qty')
        var gambar_produk = button.data('gambar_produk')
        var harga_jual = button.data('harga_jual')
        var deskripsi = button.data('deskripsi')
        var metode_bayar = button.data('metodebayar')
        // var metodebayarcheck = $('#check_cod_edit').val();
        // var Url = '{{ URL::asset(' / assets / produk / ') }}' + gambar_produk
        var SourceImage = 'assets/produk/' + gambar_produk
        // var harga_jual = xharga_jual.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,');
        var modal = $(this)
        modal.find('#produk_id').val(id)
        modal.find('#nama_produk').val(nama_produk)
        modal.find('#kategori').val(kategori)
        modal.find('#satuan').val(satuan)
        modal.find('#stok').val(qty)
        modal.find('#harga').val(harga_jual)
        modal.find('#deskripsi_produk').val(deskripsi)
        modal.find('#nama_gambar').val(gambar_produk)
        modal.find('#check_cod_edit').val(metode_bayar)

        if ($('#check_cod_edit').val() == 1) {
            modal.find('#check_cod_edit').prop('checked', true);
        }
        // modal.find('#gambar_edit').val(gambar_produk)
        modal.find('#previewing_edit').attr('src', SourceImage)
        // var metodebayarcheck = $('#check_cod_edit').val()
        // console.log(metodebayarcheck);

    });

    // menampilkan detail ongkir di form edit ongkir
    $('#editongkirModal').on('show.bs.modal', function (event) {
        var button = $(event.relatedTarget)
        var id = button.data('id')
        var kecamatan_id = button.data('kecamatan_id')
        var besar_ongkir = button.data('besar_ongkir')

        var modal = $(this)
        modal.find('#ongkir_id').val(id)
        modal.find('#kecamatan').val(kecamatan_id)
        modal.find('#besar_ongkir').val(besar_ongkir)
    });

    // check COD
    $('#check_cod').click(function () {
        if ($(this).prop('checked') == true) {
            $('#check_cod').val('1');
        } else {
            $('#check_cod').val('0');
        }
    });

    // check COD edit
    $('#check_cod_edit').click(function () {
        if ($(this).prop('checked') == true) {
            $('#check_cod_edit').val('1');
        } else {
            $('#check_cod_edit').val('0');
        }
    });

    $('#tombol_tambah').click(function () {
        var kuantitas = $('#kuantitas').val();
        var stok = $('#sisastok').text();
        // console.log(stok);
        nilaitambah = 1;
        hasil = parseInt(kuantitas) + nilaitambah;
        // stokahkir = parseInt(stok) - nilaitambah - 1
        // console.log(stokahkir);
        $('#kuantitas').val(parseInt(hasil));
        if (kuantitas >= parseInt(stok) - 1) {
            $('#tombol_tambah').prop("disabled", true);
            $('#tombol_kurang').prop("disabled", false);
        } else {
            $('#tombol_tambah').prop("disabled", false);
            $('#tombol_kurang').prop("disabled", false);
        }
        // $('#sisastok').text(stokahkir);
        // console.log(parseInt(hasil));
        // if (stokakhir == 0) {
        //     $('#tombol_tambah').prop("disabled", true);
        // }

    });

    $('#tombol_kurang').click(function () {
        var kuantitas = $('#kuantitas').val();
        // var stok = $('#sisastok').text();
        nilaikurang = 1;
        hasil = parseInt(kuantitas) - nilaikurang;
        // stokahkir = parseInt(stok) + nilaitambah
        $('#kuantitas').val(parseInt(hasil));
        // $('#sisastok').text(stokahkir);
        // console.log(parseInt(hasil));
        if ($('#kuantitas').val() == 1) {
            // $('#kuantitas').val(1)
            $('#tombol_kurang').prop("disabled", true);
            $('#tombol_tambah').prop("disabled", false);
        } else {
            $('#tombol_kurang').prop("disabled", false);
            $('#tombol_tambah').prop("disabled", false);
        }
    });
    // $('#numberbox').keyup(function () {
    //     if ($(this).val() > 100) {
    //         alert("Maksimal 100");
    //         $(this).val('100');
    //     }
    // });

    // noitifikasi pendafataran user baru
    // Enable pusher logging - don't include this in production
    // Pusher.logToConsole = true;

    // var pusher = new Pusher('1e02441f4d8132566d69', {
    //     cluster: 'ap1'
    // });

    // var channel = pusher.subscribe('userbaru');
    // channel.bind('notif', function (data) {
    //     // var jmlpendaftar = data.length;
    //     // console.log(jmlpendaftar);
    //     $("#notif").text("Pendaftaran User Baru");
    // });

    // var channel2 = pusher.subscribe('lapakbaru');
    // channel2.bind('notif_lapak', function (data) {
    //     // var jmlpendaftar = data.length;
    //     // console.log(jmlpendaftar);
    //     $("#notif_lapak").text("Pendaftaran Lapak Baru");
    //     $("#lapaknotification").text("*");
    // });


    // var channel_transaksi = pusher.subscribe('transaksibaru');
    // channel_transaksi.bind('notif_transaksi', function (data) {

    //     // var datas = JSON.parse(data);
    //     var notrans = data.event_transaksi['no_transaksi'];
    //     // console.log(data.event_transaksi['no_transaksi']);
    //     // no_trans = data.event_tranasksi['no_transaksi'] ;
    //     // $("#notif_lapak").text("Pendaftaran Lapak Baru");
    //     $("#transnotif").text("*");
    //     $("#transnotif1").text("*");
    //     $("#notransnya").text("" + notrans + "");
    // });

    // Echo.private('user.{{ $user_id }}')
    //     .listen('StatustransNotif', (e) => {
    //         alert(e);
    //     });

    $('#detail_tabel tbody .notrans').click(function () {
        // $("#tombol_detail_transaksi").click(function () {
        var table = $('#detail_tabel').DataTable();
        var data_row = table.row($(this).closest('tr')).data();
        var no_transaksi = data_row[1];
        // var no_transaksi = $(this).val();
        // console.log(no_transaksi);

        $.ajax({
            url: '/get_transaksi/' + no_transaksi,
            type: 'get',
            data: {
                id: no_transaksi
            },
            dataType: 'json',
            success: function (response) {
                // console.log(response)

                var len = response.length;
                // console.log(len)
                var html = '';
                var i;
                var notransnya = response[0].no_transaksi;
                var customer = response[0].nama;
                var satuan = response[0].satuan;
                var total = 0;
                var tot_qty = 0;
                // console.log(notransnya);
                for (i = 0; i < len; i++) {
                    // var num_harga = response[i].harga_jual.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,');
                    html += '<tr>' +
                        '<td width="15%"><img src="/assets/produk/' + response[i].gambar_produk + '" alt="" width="100px"></td> <td>' + response[i].kode_produk + ' <br>' + response[i].nama_produk + '<br>' + response[i].request_khusus + ' <br>' + '</td> ' +
                        '<td class="text-right"> Rp. ' + response[i].harga_jual.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,') + ',-</td>' +
                        '<td>' + response[i].qty_produk + ' ' + response[i].satuan + '</td>' + '<td class="text-right"> Rp. ' + (response[i].qty_produk * response[i].harga_jual).toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,') + ',-</td>' +
                        '</tr>';

                    total += parseInt(response[i].qty_produk * response[i].harga_jual);
                    // tot_qty += parseInt(response[i].qty_produk);
                }
                // console.log(total);
                $('#show_data').html(html);
                $('#labelnotransaksi').text("" + notransnya + "");
                $('#labelnamacustomer').text("" + customer + "");
                $('#grand_total').text("Rp. " + total.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,') + ",-");
                // $('#tot_kuantitas').text("" + tot_qty.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,') + " " + satuan + "");
            }
        });
    });

    $("#notrans_kirim_bukti").change(function () {
        var notrans = $(this).val();
        // console.log(notrans);
        $('#id_pelapak').find('option').not(':first').remove();
        $('#id_pelapak').niceSelect('destroy');
        $.ajax({
            url: '/get_pelapak/' + notrans,
            type: 'get',
            data: {
                id: notrans
            },
            dataType: 'json',
            success: function (response) {
                // console.log(response)

                var len = response.length;
                for (var i = 0; i < len; i++) {
                    var id = response[i]['lapak_id'];
                    var nama_lapak = response[i]['nama_lapak'];
                    // $('#seluser').niceSelect();
                    $("#id_pelapak").append("<option value='" + id + "'> " + nama_lapak + "</option>");
                    $('#id_pelapak').niceSelect('update');

                }
                // console.log(len)
            }
        });
    });


    $("#id_pelapak").change(function () {
        var id_lapak = $(this).val();
        // console.log(id_lapak);
        $.ajax({
            url: '/get_norek/' + id_lapak,
            type: 'get',
            data: {
                id: id_lapak
            },
            dataType: 'json',
            success: function (response) {
                // console.log(response)
                $("#bank").text(response.nama_bank + '  ' + response.no_rekening);
                // $("#no_rekening").text(response.no_rekening);
            }
        });
        // }
    });

    $("#kecamatan_pengantaran").change(function () {
        var id_kec_antar = $(this).val();
        var customer = $('#customer_id').val();
        $('#tampil_data1').hide();
        // console.log(id_kec_antar);
        $.ajax({
            url: '/get_ongkir_ke/' + id_kec_antar + '/' + customer,
            type: 'get',
            data: {
                id: id_kec_antar,
                cust: customer
            },
            dataType: 'json',
            success: function (response) {
                console.log(response)
                var len = response.length;
                var html = '';
                var i;
                var total = 0;
                for (i = 0; i < len; i++) {
                    html += '<tr>' +
                        '<td>' + response[i].nama_lapak + '</td> <td class="text-right">' + 'Rp. ' + Number(response[i].besar_ongkir).toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,') + ',- </td> ' +
                        '</tr>';

                    total += parseInt(Number(response[i].besar_ongkir));
                }
                // parseInt('') || 0;
                $('#tampil_data2').html(html);
                $('#totongkir').text("Rp. " + total.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,') + ",-");
                $("#ongkirnya").text('Rp. ' + total.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,') + ',-');
                var jml_transaksi = $('#jml_transaksi').val();
                // // console.log(jml_transaksi);
                var grand_total_belanja = parseInt(jml_transaksi) + parseInt(total);
                $("#grand_total_belanja").text('Rp. ' + grand_total_belanja.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,') + ',-');

            }
        });

    });





});
