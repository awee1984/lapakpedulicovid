<?php

namespace App\Http\Controllers\Backend;

use App\User;
use App\Lapak;
use App\Produk;
use App\Kategori;
use App\Bank;
use App\Ongkir;
use App\Kecamatan;
use App\Transaksi;
use App\Message;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use App\Events\StatustransNotif;


class HomelapakController extends Controller
{
    public $pathproduk;
    public $pathlapak;

    public function __construct()
    {
        $this->pathproduk = 'assets/produk';
        $this->pathlapak = 'assets/lapak';
    }

    public function index()
    {
        $lapak = Auth::user()->nama_lapak;
        $produk = Produk::where('lapak_id',Auth::user()->id)->get();
        $countproduk = $produk->count();
        $transaksi = Transaksi::where('lapak_id',Auth::user()->id)->get();
        $counttransaksi = $transaksi->count();
        // return ($countproduk);

        // data grafik
        $bulanini = date('m');
        // $x = '1,2';
        $transbulanini  = Transaksi::where('status_transaksi','konfirm')
            ->whereMonth('tanggal_transaksi',$bulanini)
            ->where('lapak_id',Auth::user()->id)
            ->groupBy('tanggal_transaksi')
            ->pluck('tanggal_transaksi');

        // $arraytanggal = [
        //     'tanggal' => $transbulanini, 
        // ];

        $jmltransbulanini = DB::table('transaksis')
            ->select(DB::raw('count(id) as jmltrans'))
            ->where('status_transaksi','konfirm')
            ->where('lapak_id',Auth::user()->id)
            ->whereMonth('tanggal_transaksi',$bulanini)
            // ->whereIn('tanggal_transaksi',[$transbulanini])
            ->groupBy('tanggal_transaksi')
            ->pluck('jmltrans');
        
        $jmltrans_tertinggi = collect($jmltransbulanini)->max();

        // return ($max);

        return view('dashboard.lapak',compact('lapak','countproduk','counttransaksi','transbulanini','jmltransbulanini','jmltrans_tertinggi'));
    }

    public function profil()
    {
        $lapak_id = Auth::user()->id;
        $datalapak = Lapak::where('id',$lapak_id)->first();
        $bank = Bank::orderBy('nama_bank')->get();  
        
        return view('dashboard.profil_lapak',compact('lapak_id','datalapak','bank'));
    }

    public function update_profil(Request $request, $id)
    {
        $request->validate([
            'nama_lapak'    => 'required',
            'nama_owner'    => 'required',
            'no_kontak'     => 'required',
            'alamat'        => 'required',
        ]);

        if($request->gambar){
            // menyimpan data file yang diupload ke variabel $file
            $file = $request->file('gambar');

            $nama_file = time()."_".$file->getClientOriginalName();

            // isi dengan nama folder tempat kemana file diupload
            $tujuan_upload = $this->pathlapak;
            $file->move($tujuan_upload,$nama_file);
        }else{
            $nama_file = null;
        }

        $lapak = Lapak::find($id);

        $lapak->nama_lapak  = $request->nama_lapak;
        $lapak->nama_owner  = $request->nama_owner;
        $lapak->no_kontak   = $request->no_kontak;
        $lapak->alamat      = $request->alamat;
        $lapak->waktu_buka  = $request->waktu_buka;
        $lapak->waktu_tutup = $request->waktu_tutup;
        $lapak->bank_id     = $request->bank;
        $lapak->no_rekening = $request->no_rekening;
        $lapak->backdrop    = $nama_file;

        $lapak->save();

        return redirect ('/profil_lapak')->with('status', 'Update profil berhasil!');

    }

    public function produk()
    {
        $lapak_id = Auth::user()->id;
        $kategori = Kategori::orderBy('nama_kategori')->get();
        $kategori2 = Kategori::orderBy('nama_kategori')->get();
        $produk = Produk::where('lapak_id',$lapak_id)->get();

        return view('dashboard.lapak_produk',compact('lapak_id','kategori','kategori2','produk'));
    }

    public function simpan(Request $request)
    {
        $request->validate([
            'nama_produk'       => 'required',
            'satuan'            => 'required',
            'kategori_id'       => 'required',
            'stok'              => 'required',
            'harga'             => 'required',
            'deskripsi_produk'  => 'required',
            'gambar_produk'     => 'required|max:1024',
        ]);

        if($request->gambar_produk){
            // menyimpan data file yang diupload ke variabel $file
            $file = $request->file('gambar_produk');

            $nama_file = time()."_".$file->getClientOriginalName();

            // isi dengan nama folder tempat kemana file diupload
            $tujuan_upload = $this->pathproduk;
            $file->move($tujuan_upload,$nama_file);
        }else{
            $nama_file = null;
        }
        
        // generate kode produk
        $lapak_id = \Auth::user()->id;
        $countproduk = Produk::where('lapak_id',$lapak_id)->count();
        $no_last = $countproduk+1;

        $kode_produk = $lapak_id.'.'.$request->kategori_id.'-'.$no_last;
        
        $produk = new Produk;
        $produk->kode_produk        = $kode_produk;
        $produk->lapak_id           = $lapak_id;
        $produk->nama_produk        = $request->nama_produk;
        $produk->qty                = $request->stok;
        $produk->harga_jual         = $request->harga;
        $produk->kategori_id        = $request->kategori_id;
        $produk->satuan             = $request->satuan;
        $produk->gambar_produk      = $nama_file;
        $produk->deskripsi_produk   = $request->deskripsi_produk;
        $produk->metode_bayar       = $request->check_cod;
        $produk->status_produk      = 'tersedia';
        
        $produk->save();

        return redirect ('/lapak_produk')->with('status', 'Simpan produk berhasil!');
    }

    public function update(Request $request)
    {
        // $produk = Produk::where('id',$request->produk_id)->get();
        // return($produk);
        $request->validate([
            'kategori_id_edit'       => 'required',
            'nama_produk_edit'       => 'required',
            'satuan_edit'            => 'required',
            'stok_edit'              => 'required',
            'harga_edit'             => 'required',
            'deskripsi_produk_edit'  => 'required',
        ]);

        if($request->gambar_edit){

            // menyimpan data file yang diupload ke variabel $file
            $file = $request->file('gambar_edit');

            $nama_file_edit = time()."_".$file->getClientOriginalName();
            // isi dengan nama folder tempat kemana file diupload
            $tujuan_upload = $this->pathproduk;
            $file->move($tujuan_upload,$nama_file_edit);

            // insert ke tabel
            $produk_edit = Produk::find($request->produk_id);
            
            $produk_edit->nama_produk        = $request->nama_produk_edit;
            $produk_edit->qty                = $request->stok_edit;
            $produk_edit->harga_jual         = $request->harga_edit;
            $produk_edit->kategori_id        = $request->kategori_id_edit;
            $produk_edit->satuan             = $request->satuan_edit;
            $produk_edit->deskripsi_produk   = $request->deskripsi_produk_edit;
            $produk_edit->gambar_produk      = $nama_file_edit;
            $produk_edit->metode_bayar       = $request->check_cod_edit;
            $produk_edit->status_produk      = 'tersedia';
            
            $produk_edit->save();

            return redirect ('/lapak_produk')->with('status', 'Update produk berhasil!');
        }else{

            $produk_edit = Produk::find($request->produk_id);

            $produk_edit->nama_produk        = $request->nama_produk_edit;
            $produk_edit->qty                = $request->stok_edit;
            $produk_edit->harga_jual         = $request->harga_edit;
            $produk_edit->kategori_id        = $request->kategori_id_edit;
            $produk_edit->satuan             = $request->satuan_edit;
            $produk_edit->deskripsi_produk   = $request->deskripsi_produk_edit;
            $produk_edit->metode_bayar       = $request->check_cod_edit;
            $produk_edit->status_produk      = 'tersedia';
            
            $produk_edit->save();

            return redirect ('/lapak_produk')->with('status', 'Update produk berhasil!');
        }
            
    }

    public function nonaktif_produk($id)
    {
        $produk = Produk::find($id);

        $produk->status_produk  = 'tidak tersedia';
        
        $produk->save();

        return redirect ('/lapak_produk')->with('status', 'Update produk berhasil!');
    }

    public function aktif_produk($id)
    {
        $produk = Produk::find($id);

        $produk->status_produk  = 'tersedia';
        
        $produk->save();

        return redirect ('/lapak_produk')->with('status', 'Update produk berhasil!');
    }

    public function ongkir()
    {
        $lapak_id = Auth::user()->id;  
        $ongkir = Ongkir::where('lapak_id',$lapak_id)->get();
        $kecamatan = Kecamatan::orderBy('nama_kecamatan')->get();
        $kecamatan2 = Kecamatan::orderBy('nama_kecamatan')->get();
       
        return view('dashboard.ongkir',compact('lapak_id','ongkir','kecamatan','kecamatan2'));
    }

    public function simpan_ongkir(Request $request)
    {
        $request->validate([
            'kecamatan_id'  => 'required',
            'besar_ongkir'  => 'required',
        ]);
            
        $lapak_id = Auth::user()->id;

        $ongkir = new Ongkir;
        $ongkir->lapak_id       = $lapak_id;
        $ongkir->kecamatan_id   = $request->kecamatan_id;
        $ongkir->besar_ongkir   = $request->besar_ongkir;
        
        $ongkir->save();

        return redirect ('/ongkir')->with('status', 'Simpan ongkos kirim berhasil!');
    }

    public function update_ongkir(Request $request)
    {
        $request->validate([
            'kecamatan_id_edit'  => 'required',
            'besar_ongkir_edit'  => 'required',
        ]);

        $ongkir_edit = Ongkir::find($request->ongkir_id);

        $ongkir_edit->kecamatan_id  = $request->kecamatan_id_edit;
        $ongkir_edit->besar_ongkir  = $request->besar_ongkir_edit;
        
        $ongkir_edit->save();

        return redirect ('/ongkir')->with('status', 'Update ongkos kirim berhasil!');
        
            
    }

    public function transaksi()
    {
        $lapak_id = Auth::user()->id;
        $transaksi = DB::table('transaksis')
            ->join('users','transaksis.user_id','users.id')
            ->join('produks','transaksis.produk_id','produks.id')
            ->join('lapaks','produks.lapak_id','lapaks.id')
            ->join('kecamatans','transaksis.kecamatan_id','kecamatans.id')
            ->join('ongkirs','transaksis.kecamatan_id','ongkirs.kecamatan_id')
            ->select('transaksis.*','produks.gambar_produk','users.kode_user','users.nama','users.no_kontak','produks.kode_produk','produks.harga_jual','produks.nama_produk','produks.satuan','nama_kecamatan','ongkirs.besar_ongkir',DB::raw('(produks.harga_jual*transaksis.qty_produk) as totharga'))
            ->where('lapaks.id',$lapak_id)
            ->groupBy('transaksis.no_transaksi')
            ->orderBy('tanggal_transaksi','desc')
            ->get();

        return view('dashboard.transaksi',compact('lapak_id','transaksi'));
    }

    public function get_transaksi($notrans)
    {
        $lapak_id = Auth::user()->id;
        $transaksi = DB::table('transaksis')
            ->join('users','transaksis.user_id','users.id')
            ->join('produks','transaksis.produk_id','produks.id')
            ->join('lapaks','produks.lapak_id','lapaks.id')
            ->join('kecamatans','transaksis.kecamatan_id','kecamatans.id')
            ->select('transaksis.*','produks.gambar_produk','users.kode_user','users.nama','users.no_kontak','produks.kode_produk','produks.harga_jual','produks.nama_produk','produks.satuan','kecamatans.nama_kecamatan')
            ->where('lapaks.id',$lapak_id)
            ->where('no_transaksi',$notrans)
            // ->groupBy('transaksis.no_transaksi')
            ->get();
            

        
        return $transaksi;
        // return view('dashboard.detail_transaksi',compact('lapak_id','transaksi'));
    }

    public function konfirm_order($notrans)
    {
        $notransaksi = Transaksi::where('no_transaksi',$notrans)->first();
        $lapak_id = Auth::user()->id;
        
        // broadcast notifikasi
        event(new StatustransNotif(User::find($notransaksi->user_id),'cek status transaksimu'));

        Transaksi::where('no_transaksi',$notrans)->where('lapak_id',$lapak_id)
          ->update(['status_transaksi' => 'konfirm']);

        return back()->with('sukses','Transaksi dikonfirmasi'); 

        // return redirect ('/lapak_produk')->with('status', 'Update produk berhasil!');
    }
}
