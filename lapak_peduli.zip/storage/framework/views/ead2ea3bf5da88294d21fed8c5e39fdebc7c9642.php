<!DOCTYPE html>
<html lang="zxx">
<head>
	<!-- Meta Tag -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name='copyright' content=''>
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
	<!-- Title Tag  -->
  <title>Lapak Peduli Covid19</title>
	<!-- Favicon -->
	<link rel="icon" type="image/png" href="images/favicon.png">
	<!-- Web Font -->
	<link href="https://fonts.googleapis.com/css?family=Poppins:200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&display=swap" rel="stylesheet">
	
	<!-- StyleSheet -->
	
	<!-- Bootstrap -->
	<link rel="stylesheet" href="<?php echo e(url('/')); ?>/assets/css/bootstrap.css">
	
	<!-- Magnific Popup -->
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/assets/css/magnific-popup.min.css">
	<!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/assets/css/font-awesome.css">
	<!-- Fancybox -->
	<link rel="stylesheet" href="<?php echo e(url('/')); ?>/assets/css/jquery.fancybox.min.css">
	<!-- Themify Icons -->
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/assets/css/themify-icons.css">
	<!-- Nice Select CSS -->
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/assets/css/niceselect.css">
	<!-- Animate CSS -->
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/assets/css/animate.css">
	<!-- Flex Slider CSS -->
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/assets/css/flex-slider.min.css">
	<!-- Owl Carousel -->
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/assets/css/owl-carousel.css">
	<!-- Slicknav -->
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/assets/css/slicknav.min.css">
	
	<!-- Eshop StyleSheet -->
	<link rel="stylesheet" href="<?php echo e(url('/')); ?>/assets/css/reset.css">
	<link rel="stylesheet" href="<?php echo e(url('/')); ?>/assets/style.css">
	<link rel="stylesheet" href="<?php echo e(url('/')); ?>/assets/css/responsive.css">
	<script src="https://code.jquery.com/jquery-3.3.1.js" integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60=" crossorigin="anonymous"></script>
	<script src="https://js.pusher.com/6.0/pusher.min.js"></script>
	
	
	<script src="https://cdnjs.cloudflare.com/ajax/libs/vue/1.0.18/vue.min.js"></script>
	<script src="<?php echo e(asset('js/app.js')); ?>"></script>

	
	
</head>
<body class="js">
	
	<!-- Preloader -->
	<div class="preloader">
		<div class="preloader-inner">
			<div class="preloader-icon">
				<span></span>
				<span></span>
			</div>
		</div>
	</div>
	<!-- End Preloader -->
	
	
	<!-- Header -->
	<header class="header shop" style="background:#ef0000">
		
		
		<div class="middle-inner" style="background:#ef0000">
			<div class="container">
				<div class="row">
					<div class="col-lg-2 col-md-2 col-12">
						<!-- Logo -->
						<div class="logo">
							<a href="<?php echo e(route('landingpage_user')); ?>"><img src="<?php echo e(url('/')); ?>/assets/images/lapakpeduli.png" alt="logo" width="200px"></a>
						</div>
						<!--/ End Logo -->
						<!-- Search Form -->
						<div class="search-top">
							<div class="top-search"><a href="#0"><i class="ti-search"></i></a></div>
							<!-- Search Form -->
							<div class="search-top">
								<form class="search-form" action="<?php echo e(route('landingpage_user')); ?>" >
									<input type="text"  name="cari" value="<?php echo e(request('cari')); ?>" placeholder="coba cari Masker ">
									<button type="submit"><i class="ti-search"></i></button>
								</form>
							</div>
							<!--/ End Search Form -->
						</div>
						<!--/ End Search Form -->
						<div class="mobile-nav"></div>
					</div>
					<div class="col-lg-7 col-md-7 col-12">
						
						<div class="search-bar-top">
							<form action="<?php echo e(route('landingpage_user')); ?>" >
								<div class="search-bar">
									<select name="kategori" >
										<option value="">Semua Kategori</option>
										<?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<?php if($term_kategori == $kategori->id): ?>
											<option value="<?php echo e($kategori->id); ?>" style="text-transform:capitalize" selected><?php echo e($kategori->nama_kategori); ?></option>
											<?php else: ?>		
											<option value="<?php echo e($kategori->id); ?>" style="text-transform:capitalize"><?php echo e($kategori->nama_kategori); ?></option>	
											<?php endif; ?>	
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</select>
								
									<input name="cari" placeholder="coba cari Masker " type="search" value="<?php echo e(request('cari')); ?>" style="padding-left:5px;">
									<button type="submit" class="btnn"><i class="ti-search"></i></button>
								</div>
							</form>
						</div>
					</div>
					<div class="col-lg-3 col-md-3 col-12" >
            <ul class="nav justify-content-end">
              <li class="nav-item">
                <a style="padding:20px 5px;" class="nav-link active" href="<?php echo e(url('/cart')); ?>">Cart</a>
							</li>
							<li class="nav-item">
                <a style="padding:20px 5px;" class="nav-link active" href="<?php echo e(url('/order_status')); ?>">Status Order</a>
              </li>
              <li class="nav-item">
								<a style="padding:20px 5px;" class="nav-link" onclick="event.preventDefault(); document.getElementById('logout-form').submit();" href="<?php echo e(url('/logout')); ?>">Keluar</a>

								
								<form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" >
									<?php echo e(csrf_field()); ?>

								</form>
              </li>
            </ul>
					</div>
				</div>
				<div class="row justify-content-md-end ">
					<div class="col-12 text-light text-right">
						<h5 style="font-size:11pt;font-weight:normal"><a id="notif_status_order" style="display: none" href="<?php echo e(url('/order_status')); ?>"><i style="position: relative;bottom:10px;"   class="ti-email berkedip" data-toggle="tooltip" data-placement="top" title="Cek Status Order"></i></a>  Hello, <?php echo e($userlogin); ?></h5> 
						
							
							
							
						
						
					</div>
					
				</div>
			</div>
		</div>
		
	</header>
	
	<!--/ End Header --><?php /**PATH C:\xampp\htdocs\lapak_peduli\lapak_peduli\resources\views/web/header.blade.php ENDPATH**/ ?>